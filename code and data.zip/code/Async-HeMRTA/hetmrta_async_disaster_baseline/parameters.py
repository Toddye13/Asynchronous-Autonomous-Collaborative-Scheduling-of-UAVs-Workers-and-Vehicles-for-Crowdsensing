class EnvParams:
    TRAIT_DIM = 5
    MAX_TIME = 180.0


class TrainParams:
    AGENT_INPUT_DIM = 6 + EnvParams.TRAIT_DIM
    TASK_INPUT_DIM = 5 + 2 * EnvParams.TRAIT_DIM
    EMBEDDING_DIM = 128
    LR = 1e-4
    GAMMA = 1.0


class DisasterParams:
    RADIUS = 8.0
    HOVER_POWER = 0.5
    SEED = 42
