from __future__ import annotations

import argparse
import csv
import json
import random
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import torch
from torch.distributions import Categorical

from algorithm import ChargePoint, Mode, TaskPoint, UAV, Vehicle, Worker, dis, scheduler


ROOT = Path(__file__).resolve().parent
BASELINE_DIR = ROOT / "hetmrta_async_disaster_baseline"
if str(BASELINE_DIR) not in sys.path:
    sys.path.insert(0, str(BASELINE_DIR))

from attention import AttentionNet  # noqa: E402


AGENT_FEATURE_DIM = 18
CANDIDATE_FEATURE_DIM = 18
EMBEDDING_DIM = 128


def default_data_dir() -> Path:
    return ROOT / "data"


def mode_code(agent) -> int:
    modes = [Mode.IDLE, Mode.MOVE, Mode.WAIT, Mode.EXEC, Mode.OFFLINE]
    return modes.index(agent.mode) if agent.mode in modes else 0


class AttentionDecisionPolicy(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.net = AttentionNet(AGENT_FEATURE_DIM, CANDIDATE_FEATURE_DIM, EMBEDDING_DIM)

    def forward(
        self,
        candidate_features: torch.Tensor,
        agent_features: torch.Tensor,
        action_mask: torch.Tensor,
        current_agent_index: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return self.net(candidate_features, agent_features, action_mask, current_agent_index)


class AttentionScheduler(scheduler):
    def __init__(
        self,
        *args,
        policy: Optional[AttentionDecisionPolicy] = None,
        device: Optional[torch.device] = None,
        sample_actions: bool = False,
        record_log_probs: bool = False,
        **kwargs,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.policy = policy
        self.device = device or torch.device("cpu")
        self.sample_actions = sample_actions
        self.record_log_probs = record_log_probs
        self.log_probs: List[torch.Tensor] = []
        self.entropies: List[torch.Tensor] = []
        self.action_counts: Dict[str, int] = {"task": 0, "charge": 0, "idle": 0}
        self._max_speed = max((a.speed for a in self.uavs + self.workers + self.vehicles), default=1.0)
        self._max_power = max((u.full_power for u in self.uavs), default=1.0)
        self._max_task_cost = max((t.cost_power for t in self.tasks), default=1.0)

    def _candidate_list(self, agent) -> List[Tuple[str, int]]:
        candidates: List[Tuple[str, int]] = []
        if isinstance(agent, UAV):
            for task in self.tasks:
                if task.completed:
                    continue
                if dis(agent.x, agent.y, task.x, task.y) <= agent.radius and self._uav_task_feasible(agent, task):
                    candidates.append(("task", task.id))
            for charge in self.charges:
                if dis(agent.x, agent.y, charge.x, charge.y) <= agent.radius and self._uav_charge_feasible(agent, charge):
                    candidates.append(("charge", charge.id))
        elif isinstance(agent, Worker):
            for task in self.tasks:
                if task.completed:
                    continue
                if dis(agent.x, agent.y, task.x, task.y) <= agent.radius and self._worker_task_feasible(agent, task):
                    candidates.append(("task", task.id))
        elif isinstance(agent, Vehicle):
            for charge in self.charges:
                if dis(agent.x, agent.y, charge.x, charge.y) <= agent.radius and self._vehicle_charge_feasible(agent, charge):
                    candidates.append(("charge", charge.id))
        return candidates

    def _agent_feature(self, observer, agent, is_current: bool) -> List[float]:
        dist_norm = dis(observer.x, observer.y, agent.x, agent.y) / self.D_max
        rel_x = (agent.x - observer.x) / self.D_max
        rel_y = (agent.y - observer.y) / self.D_max
        is_uav = 1.0 if isinstance(agent, UAV) else 0.0
        is_worker = 1.0 if isinstance(agent, Worker) else 0.0
        is_vehicle = 1.0 if isinstance(agent, Vehicle) else 0.0
        power_norm = agent.power / max(agent.full_power, 1.0) if isinstance(agent, UAV) else 0.0
        speed_norm = agent.speed / max(self._max_speed, 1.0)
        online = 1.0 if self._is_online(agent) else 0.0
        target_task = 1.0 if agent.target_type == "task" else 0.0
        target_charge = 1.0 if agent.target_type == "charge" else 0.0
        t_on_norm = max(0.0, agent.t_on - self.sys_time) / max(self.limit_time, 1.0)
        t_off_norm = max(0.0, agent.t_off - self.sys_time) / max(self.limit_time, 1.0)
        mode_norm = mode_code(agent) / 4.0
        wait_norm = 0.0
        if agent.wait_deadline < float("inf"):
            wait_norm = max(0.0, agent.wait_deadline - self.sys_time) / max(self.limit_time, 1.0)
        exec_norm = 0.0
        if agent.exec_finish_time < float("inf"):
            exec_norm = max(0.0, agent.exec_finish_time - self.sys_time) / max(self.limit_time, 1.0)
        return [
            1.0 if is_current else 0.0,
            is_uav,
            is_worker,
            is_vehicle,
            online,
            mode_norm,
            rel_x,
            rel_y,
            dist_norm,
            speed_norm,
            power_norm,
            t_on_norm,
            t_off_norm,
            target_task,
            target_charge,
            wait_norm,
            exec_norm,
            1.0,
        ]

    def _target_counts(self, action_type: str, action_id: int, agents: Sequence) -> Tuple[float, float, float]:
        uavs = workers = vehicles = 0
        for agent in agents:
            if agent.target_type != action_type or agent.target != action_id:
                continue
            if isinstance(agent, UAV):
                uavs += 1
            elif isinstance(agent, Worker):
                workers += 1
            elif isinstance(agent, Vehicle):
                vehicles += 1
        return float(uavs), float(workers), float(vehicles)

    def _candidate_feature(
        self,
        observer,
        action_type: str,
        action_id: int,
        local_agents: Sequence,
    ) -> List[float]:
        if action_type == "task":
            target = self.tasks[action_id]
            is_task = 1.0
            is_charge = 0.0
            completed = 1.0 if target.completed else 0.0
            occupied = 0.0
            cost_norm = target.cost_power / max(self._max_task_cost, 1.0)
            reward_norm = target.reward
        else:
            target = self.charges[action_id]
            is_task = 0.0
            is_charge = 1.0
            completed = 0.0
            occupied = 1.0 if target.occupied else 0.0
            cost_norm = 0.0
            reward_norm = 0.0

        d = dis(observer.x, observer.y, target.x, target.y)
        eta = self._arrival_time(observer, target.x, target.y)
        slack = max(0.0, observer.t_off - eta)
        target_uavs, target_workers, target_vehicles = self._target_counts(action_type, action_id, local_agents)
        return [
            is_task,
            is_charge,
            (target.x - observer.x) / self.D_max,
            (target.y - observer.y) / self.D_max,
            d / self.D_max,
            eta / max(self.limit_time, 1.0),
            slack / max(self.limit_time, 1.0),
            completed,
            occupied,
            cost_norm,
            reward_norm,
            1.0 if d <= observer.radius else 0.0,
            target_uavs / 10.0,
            target_workers / 10.0,
            target_vehicles / 10.0,
            observer.power / max(observer.full_power, 1.0) if isinstance(observer, UAV) else 0.0,
            self.sys_time / max(self.limit_time, 1.0),
            1.0,
        ]

    def _build_local_observation(
        self,
        agent,
        candidates: Sequence[Tuple[str, int]],
        p_uavs: Sequence[UAV],
        p_workers: Sequence[Worker],
        p_vehicles: Sequence[Vehicle],
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        local_agents = [agent] + list(p_uavs) + list(p_workers) + list(p_vehicles)
        candidate_features = [
            self._candidate_feature(agent, action_type, action_id, local_agents)
            for action_type, action_id in candidates
        ]
        agent_features = [
            self._agent_feature(agent, local_agent, idx == 0)
            for idx, local_agent in enumerate(local_agents)
        ]
        candidates_t = torch.tensor([candidate_features], dtype=torch.float32, device=self.device)
        agents_t = torch.tensor([agent_features], dtype=torch.float32, device=self.device)
        action_mask = torch.zeros((1, 1, len(candidates)), dtype=torch.bool, device=self.device)
        current_index = torch.tensor([[[0]]], dtype=torch.long, device=self.device)
        return candidates_t, agents_t, action_mask, current_index

    def _select_action(
        self,
        agent,
        candidates: Sequence[Tuple[str, int]],
        p_uavs: Sequence[UAV],
        p_workers: Sequence[Worker],
        p_vehicles: Sequence[Vehicle],
    ) -> Optional[Tuple[str, int]]:
        if not candidates:
            return None
        if self.policy is None:
            return random.choice(list(candidates))

        obs = self._build_local_observation(agent, candidates, p_uavs, p_workers, p_vehicles)
        candidates_t, agents_t, action_mask, current_index = obs
        if self.record_log_probs:
            probs, _ = self.policy(candidates_t, agents_t, action_mask, current_index)
        else:
            with torch.no_grad():
                probs, _ = self.policy(candidates_t, agents_t, action_mask, current_index)
        probs = torch.nan_to_num(probs, nan=0.0, posinf=0.0, neginf=0.0)
        if probs.sum().item() <= 0:
            idx = 0
        elif self.sample_actions:
            dist = Categorical(probs)
            action = dist.sample()
            idx = int(action.item())
            if self.record_log_probs:
                self.log_probs.append(dist.log_prob(action).squeeze())
                self.entropies.append(dist.entropy().squeeze())
        else:
            idx = int(torch.argmax(probs, dim=1).item())
        return candidates[idx]

    def _commit_action(self, agent, action: Optional[Tuple[str, int]]) -> None:
        if action is None:
            self.action_counts["idle"] += 1
            return
        action_type, action_id = action
        agent.target = action_id
        agent.target_type = action_type
        agent.mode = Mode.MOVE
        target = self.tasks[action_id] if action_type == "task" else self.charges[action_id]
        agent.arrival_time = self._arrival_time(agent, target.x, target.y)
        if isinstance(agent, UAV) and action_type == "task":
            agent.wait_deadline = agent.arrival_time + self._max_wait_uav_task(agent, self.tasks[action_id])
        elif isinstance(agent, UAV) and action_type == "charge":
            agent.wait_deadline = agent.arrival_time + self._max_wait_uav_charge(agent, self.charges[action_id])
        elif isinstance(agent, Worker):
            agent.wait_deadline = agent.arrival_time + self._max_wait_worker(agent, self.tasks[action_id])
        elif isinstance(agent, Vehicle):
            agent.wait_deadline = agent.arrival_time + self._max_wait_vehicle(agent, self.charges[action_id])
        self.action_counts[action_type] += 1

    def _attention_decide(self, agent) -> None:
        n_uavs, n_workers, n_vehicles = self._get_neighbors(agent)
        p_uavs, p_workers, p_vehicles = self._perceived_neighbors(agent, n_uavs, n_workers, n_vehicles)

        if self._is_locked(agent):
            return

        agent.mode = Mode.IDLE
        agent.target = None
        agent.target_type = None

        candidates = self._candidate_list(agent)
        action = self._select_action(agent, candidates, p_uavs, p_workers, p_vehicles)
        self._commit_action(agent, action)

        agent.tau = self.event_k
        self.total_decisions += 1
        self._broadcast_state(agent)

    def _decide_uav(self, uav: UAV) -> None:
        self._attention_decide(uav)

    def _decide_worker(self, worker: Worker) -> None:
        self._attention_decide(worker)

    def _decide_vehicle(self, vehicle: Vehicle) -> None:
        self._attention_decide(vehicle)


def make_scheduler(args: argparse.Namespace, seed: int, policy=None, sample_actions=False, record_log_probs=False) -> AttentionScheduler:
    data_dir = Path(args.data_dir)
    return AttentionScheduler(
        uav_file=str(data_dir / "uavMap.csv"),
        worker_file=str(data_dir / "workerMap.csv"),
        vehicle_file=str(data_dir / "carMap.csv"),
        task_file=str(data_dir / "taskMap.csv"),
        charge_file=str(data_dir / "chargeMap.csv"),
        radius=args.radius,
        hover_power=args.hover_power,
        limit_time=args.limit_time,
        seed=seed,
        activation_scale=args.activation_scale,
        policy=policy,
        device=args.device,
        sample_actions=sample_actions,
        record_log_probs=record_log_probs,
    )


def metrics_from_scheduler(env: AttentionScheduler, completed: int, total: int, seed: int) -> Dict[str, float]:
    return {
        "completed": float(completed),
        "total": float(total),
        "completion_rate": float(completed / total if total else 0.0),
        "current_time": float(env.sys_time),
        "decision_count": float(env.total_decisions),
        "event_count": float(env.event_k),
        "failed_waits": float(env.failed_waits),
        "task_actions": float(env.action_counts.get("task", 0)),
        "charge_actions": float(env.action_counts.get("charge", 0)),
        "idle_actions": float(env.action_counts.get("idle", 0)),
        "seed": float(seed),
    }


def episode_reward(args: argparse.Namespace, metrics: Dict[str, float]) -> float:
    return (
        args.completed_reward * metrics["completed"]
        - args.failed_wait_penalty * metrics["failed_waits"]
        - args.decision_penalty * metrics["decision_count"]
    )


def run_episode(
    args: argparse.Namespace,
    policy: AttentionDecisionPolicy,
    seed: int,
    sample_actions: bool,
    record_log_probs: bool,
) -> Tuple[Dict[str, float], List[torch.Tensor], List[torch.Tensor]]:
    env = make_scheduler(args, seed, policy, sample_actions, record_log_probs)
    completed, total = env.run_event_driven(verbose=False)
    metrics = metrics_from_scheduler(env, completed, total, seed)
    return metrics, env.log_probs, env.entropies


def average_metrics(rows: Sequence[Dict[str, float]]) -> Dict[str, float]:
    if not rows:
        return {}
    keys = rows[0].keys()
    return {key: float(sum(row[key] for row in rows) / len(rows)) for key in keys}


def evaluate(args: argparse.Namespace, policy: AttentionDecisionPolicy, episodes: int, seed: int) -> Dict[str, float]:
    policy.eval()
    rows = []
    for idx in range(episodes):
        metrics, _, _ = run_episode(args, policy, seed + idx, sample_actions=False, record_log_probs=False)
        rows.append(metrics)
    return average_metrics(rows)


def save_checkpoint(path: Path, policy: AttentionDecisionPolicy, optimizer: torch.optim.Optimizer, episode: int, best: Dict[str, float]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "model_state_dict": policy.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "episode": episode,
            "best": best,
        },
        path,
    )


def load_checkpoint(path: Path, policy: AttentionDecisionPolicy, optimizer: Optional[torch.optim.Optimizer], device: torch.device) -> int:
    checkpoint = torch.load(path, map_location=device)
    policy.load_state_dict(checkpoint["model_state_dict"])
    if optimizer is not None and "optimizer_state_dict" in checkpoint:
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
    return int(checkpoint.get("episode", 0))


def append_history(path: Path, row: Dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        if not exists:
            writer.writeheader()
        writer.writerow(row)


def train(args: argparse.Namespace) -> None:
    torch.manual_seed(args.seed)
    random.seed(args.seed)
    np.random.seed(args.seed)
    policy = AttentionDecisionPolicy().to(args.device)
    optimizer = torch.optim.Adam(policy.parameters(), lr=args.lr)
    start_episode = 0
    best: Dict[str, float] = {"completion_rate": -1.0, "completed": -1.0}
    if args.resume:
        start_episode = load_checkpoint(Path(args.resume), policy, optimizer, args.device)

    baseline: Optional[float] = None
    for episode in range(start_episode + 1, start_episode + args.episodes + 1):
        policy.train()
        metrics, log_probs, entropies = run_episode(
            args,
            policy,
            args.seed + episode,
            sample_actions=True,
            record_log_probs=True,
        )
        reward = episode_reward(args, metrics)
        baseline = reward if baseline is None else args.baseline_beta * baseline + (1.0 - args.baseline_beta) * reward
        advantage = reward - baseline

        if log_probs:
            log_prob_sum = torch.stack(log_probs).sum()
            entropy_sum = torch.stack(entropies).sum() if entropies else torch.tensor(0.0, device=args.device)
            loss = -log_prob_sum * float(advantage) - args.entropy_coef * entropy_sum
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(policy.parameters(), args.grad_clip)
            optimizer.step()
            loss_value = float(loss.detach().cpu().item())
        else:
            loss_value = 0.0

        eval_metrics: Optional[Dict[str, float]] = None
        is_best = False
        if episode % args.eval_every == 0 or episode == start_episode + 1:
            eval_metrics = evaluate(args, policy, args.eval_episodes, args.eval_seed)
            is_best = (
                eval_metrics["completion_rate"] > best["completion_rate"]
                or (
                    eval_metrics["completion_rate"] == best["completion_rate"]
                    and eval_metrics["completed"] > best["completed"]
                )
            )
            if is_best:
                best = dict(eval_metrics)
                save_checkpoint(Path(args.best_model), policy, optimizer, episode, best)

        save_checkpoint(Path(args.last_model), policy, optimizer, episode, best)
        if args.save_every > 0 and episode % args.save_every == 0:
            save_checkpoint(Path(args.checkpoint_dir) / f"episode_{episode}.pt", policy, optimizer, episode, best)

        history_row: Dict[str, object] = {
            "episode": episode,
            "reward": reward,
            "baseline": baseline,
            "advantage": advantage,
            "loss": loss_value,
            "completed": metrics["completed"],
            "total": metrics["total"],
            "completion_rate": metrics["completion_rate"],
            "failed_waits": metrics["failed_waits"],
            "decision_count": metrics["decision_count"],
            "is_best": int(is_best),
            "eval_completed": "" if eval_metrics is None else eval_metrics["completed"],
            "eval_completion_rate": "" if eval_metrics is None else eval_metrics["completion_rate"],
            "best_completed": best["completed"],
            "best_completion_rate": best["completion_rate"],
        }
        append_history(Path(args.history), history_row)
        print(json.dumps({"progress": history_row, "eval": eval_metrics, "best": best}, ensure_ascii=False), flush=True)


def run_eval(args: argparse.Namespace) -> None:
    policy = AttentionDecisionPolicy().to(args.device)
    if not args.model:
        raise ValueError("--model is required in eval mode")
    load_checkpoint(Path(args.model), policy, optimizer=None, device=args.device)
    summary = evaluate(args, policy, args.eval_episodes, args.eval_seed)
    print(json.dumps({"summary": summary}, ensure_ascii=False, indent=2))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["train", "eval"], default="train")
    parser.add_argument("--data-dir", type=Path, default=default_data_dir())
    parser.add_argument("--radius", type=float, default=8.0)
    parser.add_argument("--hover-power", type=float, default=0.5)
    parser.add_argument("--limit-time", type=float, default=180.0)
    parser.add_argument("--activation-scale", type=float, default=0.05)
    parser.add_argument("--episodes", type=int, default=500)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--eval-seed", type=int, default=42)
    parser.add_argument("--eval-every", type=int, default=20)
    parser.add_argument("--eval-episodes", type=int, default=3)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--baseline-beta", type=float, default=0.9)
    parser.add_argument("--entropy-coef", type=float, default=0.01)
    parser.add_argument("--grad-clip", type=float, default=1.0)
    parser.add_argument("--completed-reward", type=float, default=10.0)
    parser.add_argument("--failed-wait-penalty", type=float, default=0.02)
    parser.add_argument("--decision-penalty", type=float, default=0.001)
    parser.add_argument("--best-model", type=str, default="model/algorithm_attention_best.pt")
    parser.add_argument("--last-model", type=str, default="model/algorithm_attention_last.pt")
    parser.add_argument("--checkpoint-dir", type=str, default="model/algorithm_attention_checkpoints")
    parser.add_argument("--history", type=str, default="results/algorithm_attention_history.csv")
    parser.add_argument("--save-every", type=int, default=50)
    parser.add_argument("--resume", type=str, default="")
    parser.add_argument("--model", type=str, default="")
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    args.device = torch.device(args.device)
    return args


def main() -> None:
    args = parse_args()
    if args.mode == "train":
        train(args)
    else:
        run_eval(args)


if __name__ == "__main__":
    main()
