from __future__ import annotations

import argparse
import json
import random
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import torch

from algorithm_attention_baseline import (
    AttentionDecisionPolicy,
    append_history,
    average_metrics,
    default_data_dir,
    evaluate,
    load_checkpoint,
    run_episode,
    save_checkpoint,
)


def stable_reward(args: argparse.Namespace, metrics: Dict[str, float]) -> float:
    total = max(metrics["total"], 1.0)
    return (
        args.completed_reward * metrics["completion_rate"]
        - args.failed_wait_penalty * metrics["failed_waits"] / total
        - args.decision_penalty * metrics["decision_count"] / total
    )


def grouped_advantages(
    rewards: List[float],
    seed_groups: List[int],
    rollouts_per_seed: int,
    device: torch.device,
) -> torch.Tensor:
    if rollouts_per_seed > 1:
        centered = []
        for group_idx, reward in zip(seed_groups, rewards):
            group_rewards = [
                other_reward
                for other_reward, other_group_idx in zip(rewards, seed_groups)
                if other_group_idx == group_idx
            ]
            centered.append(reward - float(sum(group_rewards) / len(group_rewards)))
        return torch.tensor(centered, dtype=torch.float32, device=device)

    reward_tensor = torch.tensor(rewards, dtype=torch.float32, device=device)
    return reward_tensor - reward_tensor.mean()


def normalize_advantages(advantages: torch.Tensor, enabled: bool) -> torch.Tensor:
    if not enabled or advantages.numel() <= 1:
        return advantages
    std = advantages.std(unbiased=False)
    if std.item() <= 1e-8:
        return advantages - advantages.mean()
    return (advantages - advantages.mean()) / (std + 1e-8)


def print_progress_bar(
    episode: int,
    start_episode: int,
    total_episode: int,
    reward: float,
    completion_rate: float,
    best_completion_rate: float,
) -> None:
    completed = episode - start_episode
    total = max(total_episode - start_episode, 1)
    ratio = min(max(completed / total, 0.0), 1.0)
    bar_width = 30
    filled = int(round(ratio * bar_width))
    bar = "#" * filled + "-" * (bar_width - filled)
    message = (
        f"Training [{bar}] {completed}/{total} "
        f"({ratio * 100:5.1f}%) | episode={episode} "
        f"reward={reward:.4f} completion={completion_rate:.3f} "
        f"best={best_completion_rate:.3f}"
    )
    print(message, end="\r", flush=True)


def train(args: argparse.Namespace) -> None:
    torch.manual_seed(args.seed)
    random.seed(args.seed)
    np.random.seed(args.seed)

    policy = AttentionDecisionPolicy().to(args.device)
    optimizer = torch.optim.Adam(policy.parameters(), lr=args.lr)
    start_episode = 0
    best: Dict[str, float] = {"completion_rate": -1.0, "completed": -1.0}
    if args.resume:
        start_episode = load_checkpoint(Path(args.resume), policy, optimizer, args.device)

    ema_baseline: Optional[float] = None
    for episode in range(start_episode + 1, start_episode + args.episodes + 1):
        policy.train()
        rollout_metrics: List[Dict[str, float]] = []
        all_rewards: List[float] = []
        loss_rewards: List[float] = []
        seed_groups: List[int] = []
        log_prob_means: List[torch.Tensor] = []
        entropy_means: List[torch.Tensor] = []

        for seed_idx in range(args.batch_episodes):
            rollout_seed = args.seed + (episode - 1) * args.batch_episodes + seed_idx + 1
            for _ in range(args.rollouts_per_seed):
                metrics, log_probs, entropies = run_episode(
                    args,
                    policy,
                    rollout_seed,
                    sample_actions=True,
                    record_log_probs=True,
                )
                rollout_metrics.append(metrics)
                reward = stable_reward(args, metrics)
                all_rewards.append(reward)

                if log_probs:
                    loss_rewards.append(reward)
                    seed_groups.append(seed_idx)
                    log_prob_means.append(torch.stack(log_probs).mean())
                    if entropies:
                        entropy_means.append(torch.stack(entropies).mean())
                    else:
                        entropy_means.append(torch.tensor(0.0, device=args.device))

        metrics = average_metrics(rollout_metrics)
        reward = float(sum(all_rewards) / len(all_rewards)) if all_rewards else 0.0
        reward_std = float(np.std(all_rewards)) if len(all_rewards) > 1 else 0.0
        ema_baseline = (
            reward
            if ema_baseline is None
            else args.baseline_beta * ema_baseline + (1.0 - args.baseline_beta) * reward
        )
        logged_advantage = reward - ema_baseline

        if log_prob_means and loss_rewards:
            advantages = grouped_advantages(loss_rewards, seed_groups, args.rollouts_per_seed, args.device)
            advantages = normalize_advantages(advantages, args.normalize_advantage)
            log_prob_tensor = torch.stack(log_prob_means)
            entropy_tensor = torch.stack(entropy_means) if entropy_means else torch.tensor([0.0], device=args.device)
            loss = -(log_prob_tensor * advantages).mean() - args.entropy_coef * entropy_tensor.mean()

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(policy.parameters(), args.grad_clip)
            optimizer.step()
            loss_value = float(loss.detach().cpu().item())
            train_advantage_std = float(advantages.detach().std(unbiased=False).cpu().item())
        else:
            loss_value = 0.0
            train_advantage_std = 0.0

        eval_metrics: Optional[Dict[str, float]] = None
        is_best = False
        if episode % args.eval_every == 0 or episode == start_episode + 1:
            eval_metrics = evaluate(args, policy, args.eval_episodes, args.eval_seed)
            is_best = (
                eval_metrics["completion_rate"] > best["completion_rate"]
                or (
                    eval_metrics["completion_rate"] == best["completion_rate"]
                    and eval_metrics["completed"] > best["completed"]
                )
            )
            if is_best:
                best = dict(eval_metrics)
                save_checkpoint(Path(args.best_model), policy, optimizer, episode, best)

        save_checkpoint(Path(args.last_model), policy, optimizer, episode, best)
        if args.save_every > 0 and episode % args.save_every == 0:
            save_checkpoint(Path(args.checkpoint_dir) / f"episode_{episode}.pt", policy, optimizer, episode, best)

        history_row: Dict[str, object] = {
            "episode": episode,
            "reward": reward,
            "reward_std": reward_std,
            "baseline": ema_baseline,
            "advantage": logged_advantage,
            "train_advantage_std": train_advantage_std,
            "loss": loss_value,
            "batch_episodes": args.batch_episodes,
            "rollouts_per_seed": args.rollouts_per_seed,
            "completed": metrics["completed"],
            "total": metrics["total"],
            "completion_rate": metrics["completion_rate"],
            "failed_waits": metrics["failed_waits"],
            "decision_count": metrics["decision_count"],
            "is_best": int(is_best),
            "eval_completed": "" if eval_metrics is None else eval_metrics["completed"],
            "eval_completion_rate": "" if eval_metrics is None else eval_metrics["completion_rate"],
            "best_completed": best["completed"],
            "best_completion_rate": best["completion_rate"],
        }
        append_history(Path(args.history), history_row)
        print_progress_bar(
            episode,
            start_episode,
            start_episode + args.episodes,
            reward,
            metrics["completion_rate"],
            best["completion_rate"],
        )
        should_log = (
            args.log_every > 0
            and (
                episode % args.log_every == 0
                or episode == start_episode + args.episodes
            )
        )
        if should_log:
            print()
            print(json.dumps({"progress": history_row, "eval": eval_metrics, "best": best}, ensure_ascii=False), flush=True)
    print()


def run_eval(args: argparse.Namespace) -> None:
    policy = AttentionDecisionPolicy().to(args.device)
    if not args.model:
        raise ValueError("--model is required in eval mode")
    load_checkpoint(Path(args.model), policy, optimizer=None, device=args.device)
    summary = evaluate(args, policy, args.eval_episodes, args.eval_seed)
    print(json.dumps({"summary": summary}, ensure_ascii=False, indent=2))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["train", "eval"], default="train")
    parser.add_argument("--data-dir", type=Path, default=default_data_dir())
    parser.add_argument("--radius", type=float, default=8.0)
    parser.add_argument("--hover-power", type=float, default=0.5)
    parser.add_argument("--limit-time", type=float, default=180.0)
    parser.add_argument("--activation-scale", type=float, default=0.05)
    parser.add_argument("--episodes", type=int, default=500)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--eval-seed", type=int, default=900000)
    parser.add_argument("--eval-every", type=int, default=20)
    parser.add_argument("--eval-episodes", type=int, default=5)
    parser.add_argument("--batch-episodes", type=int, default=4)
    parser.add_argument("--rollouts-per-seed", type=int, default=1)
    parser.add_argument("--no-normalize-advantage", action="store_false", dest="normalize_advantage")
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--baseline-beta", type=float, default=0.9)
    parser.add_argument("--entropy-coef", type=float, default=0.002)
    parser.add_argument("--grad-clip", type=float, default=5.0)
    parser.add_argument("--completed-reward", type=float, default=1.0)
    parser.add_argument("--failed-wait-penalty", type=float, default=0.02)
    parser.add_argument("--decision-penalty", type=float, default=0.001)
    parser.add_argument("--best-model", type=str, default="model/algorithm_attention_stable_best.pt")
    parser.add_argument("--last-model", type=str, default="model/algorithm_attention_stable_last.pt")
    parser.add_argument("--checkpoint-dir", type=str, default="model/algorithm_attention_stable_checkpoints")
    parser.add_argument("--history", type=str, default="results/algorithm_attention_stable_history.csv")
    parser.add_argument("--log-every", type=int, default=10)
    parser.add_argument("--save-every", type=int, default=50)
    parser.add_argument("--resume", type=str, default="")
    parser.add_argument("--model", type=str, default="")
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    parser.set_defaults(normalize_advantage=True)
    args = parser.parse_args()
    args.device = torch.device(args.device)
    return args


def main() -> None:
    args = parse_args()
    if args.mode == "train":
        train(args)
    else:
        run_eval(args)


if __name__ == "__main__":
    main()
