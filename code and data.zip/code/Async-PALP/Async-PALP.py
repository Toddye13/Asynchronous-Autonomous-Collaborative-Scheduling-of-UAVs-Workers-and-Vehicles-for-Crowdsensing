import numpy as np
import pandas as pd
import math
import random
import argparse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, List, Dict, Tuple, Set
from enum import Enum
import copy

class AgentType(Enum):
    UAV = "UAV"
    WORKER = "Worker"
    VEHICLE = "Vehicle"

class Mode(Enum):
    IDLE = "IDLE"
    MOVE = "MOVE"
    WAIT = "WAIT"
    EXEC = "EXEC"
    OFFLINE = "OFFLINE"

@dataclass
class UAV:
    id: int
    x: float
    y: float
    speed: float          # r_i^u
    full_power: float     # E_i^max
    power: float          # E_i(t)
    hover_power: float    # P_i^hov
    radius: float         # R_i^u
    t_on: float           # T_i^on
    t_off: float          # T_i^off
    mode: Mode = Mode.OFFLINE
    target: Optional[int] = None      # 目标点ID (正数=任务, 负数=充电)
    target_type: Optional[str] = None # "task" or "charge"
    tau: int = 0                      # 上次决策事件编号
    arrival_time: float = float('inf')
    wait_deadline: float = float('inf')
    exec_finish_time: float = float('inf')
    partner_id: Optional[int] = None  # 配对的Worker/Vehicle ID

@dataclass
class Worker:
    id: int
    x: float
    y: float
    speed: float
    radius: float
    t_on: float
    t_off: float
    mode: Mode = Mode.OFFLINE
    target: Optional[int] = None
    target_type: Optional[str] = None
    tau: int = 0
    arrival_time: float = float('inf')
    wait_deadline: float = float('inf')
    exec_finish_time: float = float('inf')
    partner_id: Optional[int] = None

@dataclass
class Vehicle:
    id: int
    x: float
    y: float
    speed: float
    radius: float
    charge_power: float   # P_r^chg
    t_on: float
    t_off: float
    mode: Mode = Mode.OFFLINE
    target: Optional[int] = None
    target_type: Optional[str] = None
    tau: int = 0
    arrival_time: float = float('inf')
    wait_deadline: float = float('inf')
    exec_finish_time: float = float('inf')
    partner_id: Optional[int] = None

@dataclass
class TaskPoint:
    id: int
    x: float
    y: float
    cost_power: float
    reward: float = 1.0
    completed: bool = False

@dataclass
class ChargePoint:
    id: int
    x: float
    y: float
    occupied: bool = False  # 当前是否有配对在充电

@dataclass(frozen=True)
class BroadcastState:   # 智能体某时刻广播出去的一份状态快照
    agent_type: AgentType
    agent_id: int
    x: float
    y: float
    mode: Mode
    target: Optional[int]
    target_type: Optional[str]
    tau: int    #上次决策事件编号
    arrival_time: float
    wait_deadline: float
    exec_finish_time: float
    power: Optional[float]

@dataclass(frozen=True)
class AblationConfig:
    """Switches used to isolate each Async-PALP component in ablation runs."""
    name: str = "Async-PALP"
    use_state_aware_activation: bool = True
    use_action_locking: bool = True
    use_reservation_table: bool = True
    use_predictive_fifo: bool = True
    use_pairing_reward: bool = True
    use_crowding_penalty: bool = True


ABLATION_VARIANTS: Dict[str, AblationConfig] = {
    "full": AblationConfig(name="Async-PALP"),
    "no_state_aware_activation": AblationConfig(
        name="w/o State-aware Activation",
        use_state_aware_activation=False,
    ),
    "no_action_locking": AblationConfig(
        name="w/o Action Locking",
        use_action_locking=False,
    ),
    "no_reservation_table": AblationConfig(
        name="w/o Reservation Table",
        use_reservation_table=False,
    ),
    "no_predictive_fifo": AblationConfig(
        name="w/o Predictive FIFO Matching",
        use_predictive_fifo=False,
    ),
    "no_pairing_reward": AblationConfig(
        name="w/o Pairing Reward",
        use_pairing_reward=False,
    ),
    "no_crowding_penalty": AblationConfig(
        name="w/o Crowding Penalty",
        use_crowding_penalty=False,
    ),
}

def dis(x1, y1, x2, y2) -> float:
    return math.sqrt((x1 - x2)**2 + (y1 - y2)**2)   # 两点间欧式距离

def clip01(z: float) -> float:
    return min(max(z, 0.0), 1.0)    # 归一化

class scheduler:
    def __init__(self, uav_file, worker_file, vehicle_file, task_file, charge_file,
                 radius=8.0, hover_power=0.5, limit_time=180, seed=42,
                 activation_scale=0.05, ablation: Optional[AblationConfig] = None):
        """
        参数:
            radius: 所有智能体的通信半径
            hover_power: UAV单位时间悬停能耗
            limit_time: 仿真总时长
            seed: 随机种子
        """
        random.seed(seed)
        np.random.seed(seed)

        self.radius = radius
        self.hover_power = hover_power
        self.limit_time = limit_time
        self.activation_scale = max(1e-6, float(activation_scale))
        self.ablation = ablation or ABLATION_VARIANTS["full"]
        self.event_k = 0          # 异步决策事件索引
        self.sys_time = 0.0       # 当前物理时间

        # 加载数据
        self._load_data(uav_file, worker_file, vehicle_file, task_file, charge_file)

        # 计算场景最大距离D_max
        all_x = [t.x for t in self.tasks] + [c.x for c in self.charges]
        all_y = [t.y for t in self.tasks] + [c.y for c in self.charges]
        if all_x and all_y:
            self.D_max = dis(min(all_x), min(all_y), max(all_x), max(all_y))    #斜对角线长度
        else:
            self.D_max = 1.0
        if self.D_max < 1.0:
            self.D_max = 1.0

        # 统计
        self.completed_tasks: List[int] = []    # 完成的任务列表
        self.total_decisions = 0    # 决策次数
        self.failed_waits = 0   # 等超时的次数
        self.successful_task_matches = 0
        self.successful_charge_matches = 0
        self.target_switches = 0
        self.total_travel_distance = 0.0
        self.state_history: Dict[Tuple[str, int], List[BroadcastState]] = {}    # 智能体广播快照的历史
        self._broadcast_all_states()    # 一开始先给所有智能体建立初始广播状态

    def _load_data(self, uav_f, worker_f, vehicle_f, task_f, charge_f):
        # 加载数据并创建智能体和目标点
        # UAV
        df = pd.read_csv(uav_f)
        self.uavs: List[UAV] = []
        for _, row in df.iterrows():
            self.uavs.append(UAV(
                id=int(row['ID']), x=float(row['x']), y=float(row['y']),
                speed=float(row['uavRge']), full_power=float(row['Fullpower']),
                power=float(row['uPow']), hover_power=self.hover_power,
                radius=self.radius,
                t_on=float(row['U_uptime']), t_off=float(row['U_downtime'])
            ))

        # Worker
        df = pd.read_csv(worker_f)
        self.workers: List[Worker] = []
        for _, row in df.iterrows():
            self.workers.append(Worker(
                id=int(row['ID']), x=float(row['x']), y=float(row['y']),
                speed=float(row['workerRge']), radius=self.radius,
                t_on=float(row['W_uptime']), t_off=float(row['W_downtime'])
            ))

        # Vehicle
        df = pd.read_csv(vehicle_f)
        self.vehicles: List[Vehicle] = []
        for _, row in df.iterrows():
            self.vehicles.append(Vehicle(
                id=int(row['ID']), x=float(row['x']), y=float(row['y']),
                speed=float(row['carRge']), radius=self.radius,
                charge_power=float(row['C_chargePow']),
                t_on=float(row['C_uptime']), t_off=float(row['C_downtime'])
            ))

        # Task
        df = pd.read_csv(task_f)
        self.tasks: List[TaskPoint] = []
        for _, row in df.iterrows():
            self.tasks.append(TaskPoint(
                id=int(row['ID']), x=float(row['x']), y=float(row['y']),
                cost_power=float(row['T_costPow'])
            ))

        # Charge
        df = pd.read_csv(charge_f)
        self.charges: List[ChargePoint] = []
        for _, row in df.iterrows():
            self.charges.append(ChargePoint(
                id=int(row['ID']), x=float(row['x']), y=float(row['y'])
            ))

    # 给每个智能体生成一个唯一键，用这个键做索引
    def _agent_key(self, agent) -> Tuple[str, int]:
        if isinstance(agent, UAV):
            return ("uav", agent.id)
        if isinstance(agent, Worker):
            return ("worker", agent.id)
        return ("vehicle", agent.id)

    # “快照”记录智能体当前的状态用于广播
    def _snapshot(self, agent) -> BroadcastState:
        return BroadcastState(
            agent_type=AgentType.UAV if isinstance(agent, UAV) else AgentType.WORKER if isinstance(agent, Worker) else AgentType.VEHICLE,
            agent_id=agent.id,
            x=agent.x,
            y=agent.y,
            mode=agent.mode,
            target=agent.target,
            target_type=agent.target_type,
            tau=agent.tau,
            arrival_time=agent.arrival_time,
            wait_deadline=agent.wait_deadline,
            exec_finish_time=agent.exec_finish_time,
            power=agent.power if isinstance(agent, UAV) else None,
        )
    # 把某个智能体当前状态保存到它自己的广播历史
    def _broadcast_state(self, agent) -> None:
        key = self._agent_key(agent)
        self.state_history.setdefault(key, []).append(self._snapshot(agent))    # 把该智能体的当前状态快照加入自己的广播历史中
        if len(self.state_history[key]) > 64:
            self.state_history[key] = self.state_history[key][-64:] # 最多只保存前64次历史快照
    # 让所有智能体广播一次当前状态
    def _broadcast_all_states(self) -> None:
        for agent in self.uavs + self.workers + self.vehicles:
            self._broadcast_state(agent)
    # 当前智能体（observer）读取邻居最近一次的广播快照
    def _perceived_snapshot(self, observer, neighbor) -> BroadcastState:
        history = self.state_history.get(self._agent_key(neighbor), [])
        if not history:
            return self._snapshot(neighbor)
        return history[-1]
    # 根据快照复制一个当前的邻居对象
    def _copy_with_snapshot(self, agent, snapshot: BroadcastState):
        cloned = copy.copy(agent)
        cloned.x = snapshot.x
        cloned.y = snapshot.y
        cloned.mode = snapshot.mode
        cloned.target = snapshot.target
        cloned.target_type = snapshot.target_type
        cloned.tau = snapshot.tau
        cloned.arrival_time = snapshot.arrival_time
        cloned.wait_deadline = snapshot.wait_deadline
        cloned.exec_finish_time = snapshot.exec_finish_time
        if isinstance(cloned, UAV):
            cloned.power = cloned.power if snapshot.power is None else snapshot.power
        return cloned
    # 给当前决策的智能体构造当前看到的全部邻居集合
    def _perceived_neighbors(self, observer, neighbor_uavs, neighbor_workers, neighbor_vehicles):
        delayed_uavs = [self._copy_with_snapshot(u, self._perceived_snapshot(observer, u)) for u in neighbor_uavs]
        delayed_workers = [self._copy_with_snapshot(w, self._perceived_snapshot(observer, w)) for w in neighbor_workers]
        delayed_vehicles = [self._copy_with_snapshot(v, self._perceived_snapshot(observer, v)) for v in neighbor_vehicles]
        return delayed_uavs, delayed_workers, delayed_vehicles

    # 通信与邻居
    # 智能体当前是否在线
    def _is_online(self, agent) -> bool:
        return self.sys_time >= agent.t_on and self.sys_time <= agent.t_off and agent.mode != Mode.OFFLINE
    # 获取通信范围内的邻居，排除自己与不在线的智能体
    def _get_neighbors(self, agent) -> Tuple[List[UAV], List[Worker], List[Vehicle]]:
        neighbor_uavs = []
        neighbor_workers = []
        neighbor_vehicles = []

        for u in self.uavs:
            if u.id == agent.id and isinstance(agent, UAV):
                continue
            if not self._is_online(u):
                continue
            if dis(agent.x, agent.y, u.x, u.y) <= min(agent.radius, u.radius):
                neighbor_uavs.append(u)

        for w in self.workers:
            if w.id == agent.id and isinstance(agent, Worker):
                continue
            if not self._is_online(w):
                continue
            if dis(agent.x, agent.y, w.x, w.y) <= min(agent.radius, w.radius):
                neighbor_workers.append(w)

        for v in self.vehicles:
            if v.id == agent.id and isinstance(agent, Vehicle):
                continue
            if not self._is_online(v):
                continue
            if dis(agent.x, agent.y, v.x, v.y) <= min(agent.radius, v.radius):
                neighbor_vehicles.append(v)

        return neighbor_uavs, neighbor_workers, neighbor_vehicles

    # 局部预约表
    def _build_local_reservation(self, agent, neighbor_uavs, neighbor_workers, neighbor_vehicles):
        """
        task_res={}
        {
            3: {"uavs": [u1, u2], "workers": [w5]},
            7: {"uavs": [u3], "workers": [w1, w4]}
        }
        charge_res={}
        {
            1: {"uavs": [u7], "vehicles": [v2, v3]},
            4: {"uavs": [u5, u6], "vehicles": [v1]}
        }
        """

        task_res = {}
        charge_res = {}

        if not self.ablation.use_reservation_table:
            neighbor_uavs = []
            neighbor_workers = []
            neighbor_vehicles = []

        # 收集所有相关智能体(含自己)的动作
        all_agents = []
        if isinstance(agent, UAV):
            all_agents.append(("uav", agent))
        elif isinstance(agent, Worker):
            all_agents.append(("worker", agent))
        elif isinstance(agent, Vehicle):
            all_agents.append(("vehicle", agent))

        for u in neighbor_uavs:
            all_agents.append(("uav", u))
        for w in neighbor_workers:
            all_agents.append(("worker", w))
        for v in neighbor_vehicles:
            all_agents.append(("vehicle", v))

        for atype, a in all_agents:
            if a.target is None or a.mode == Mode.IDLE or a.mode == Mode.OFFLINE:
                continue
            if a.target_type == "task":
                tid = a.target
                if tid not in task_res:
                    task_res[tid] = {"uavs": [], "workers": []}
                if atype == "uav":
                    task_res[tid]["uavs"].append(a)
                elif atype == "worker":
                    task_res[tid]["workers"].append(a)
            elif a.target_type == "charge":
                cid = a.target
                if cid not in charge_res:
                    charge_res[cid] = {"uavs": [], "vehicles": []}
                if atype == "uav":
                    charge_res[cid]["uavs"].append(a)
                elif atype == "vehicle":
                    charge_res[cid]["vehicles"].append(a)

        return task_res, charge_res

    # 可行性检查
    def _nearest_charge(self, x, y) -> Tuple[float, int]:
        # 找到最近的充电点及距离
        best_dist = float('inf')
        best_id = -1
        for c in self.charges:
            d = dis(x, y, c.x, c.y)
            if d < best_dist:
                best_dist = d
                best_id = c.id
        return best_dist, best_id

    def _uav_task_feasible(self, uav: UAV, task: TaskPoint) -> bool:
        # UAV选择的任务点的可行性
        if task.completed:
            return False
        d_to_task = dis(uav.x, uav.y, task.x, task.y)
        d_return, _ = self._nearest_charge(task.x, task.y)
        total_energy = d_to_task + task.cost_power + d_return
        if total_energy > uav.power:
            return False
        # 时间窗
        eta = self.sys_time + d_to_task / uav.speed
        if eta > uav.t_off:
            return False
        return True

    def _uav_charge_feasible(self, uav: UAV, charge: ChargePoint) -> bool:
        #UAV选择的充电点的可行性
        d = dis(uav.x, uav.y, charge.x, charge.y)
        if d > uav.power:
            return False
        eta = self.sys_time + d / uav.speed
        if eta > uav.t_off:
            return False
        return True

    def _worker_task_feasible(self, worker: Worker, task: TaskPoint) -> bool:
        #工人选择任务点的可行性
        if task.completed:
            return False
        d = dis(worker.x, worker.y, task.x, task.y)
        eta = self.sys_time + d / worker.speed
        if eta > worker.t_off:
            return False
        return True

    def _vehicle_charge_feasible(self, vehicle: Vehicle, charge: ChargePoint) -> bool:
        #小车选择充电点的可行性
        d = dis(vehicle.x, vehicle.y, charge.x, charge.y)
        eta = self.sys_time + d / vehicle.speed
        if eta > vehicle.t_off:
            return False
        return True

    # 到达时间
    def _arrival_time(self, agent, px, py) -> float:
        d = dis(agent.x, agent.y, px, py)
        return self.sys_time + d / agent.speed
    # UAV在任务点的最大等待时间
    def _max_wait_uav_task(self, uav: UAV, task: TaskPoint) -> float:
        d_to_task = dis(uav.x, uav.y, task.x, task.y)
        eta = self.sys_time + d_to_task / uav.speed
        time_slack = max(0, uav.t_off - eta)
        d_return, _ = self._nearest_charge(task.x, task.y)
        energy_after = uav.power - d_to_task - task.cost_power - d_return
        if uav.hover_power > 0:
            energy_slack = max(0, energy_after / uav.hover_power)
        else:
            energy_slack = time_slack
        return max(0, min(time_slack, energy_slack))
    # UAV在充电点的最大等待时间
    def _max_wait_uav_charge(self, uav: UAV, charge: ChargePoint) -> float:
        d = dis(uav.x, uav.y, charge.x, charge.y)
        eta = self.sys_time + d / uav.speed
        time_slack = max(0, uav.t_off - eta)
        energy_after = uav.power - d
        if uav.hover_power > 0:
            energy_slack = max(0, energy_after / uav.hover_power)
        else:
            energy_slack = time_slack
        return max(0, min(time_slack, energy_slack))
    # 工人最大等待时间
    def _max_wait_worker(self, worker: Worker, task: TaskPoint) -> float:
        d = dis(worker.x, worker.y, task.x, task.y)
        eta = self.sys_time + d / worker.speed
        return max(0, worker.t_off - eta)
    # 小车最大等待时间
    def _max_wait_vehicle(self, vehicle: Vehicle, charge: ChargePoint) -> float:
        d = dis(vehicle.x, vehicle.y, charge.x, charge.y)
        eta = self.sys_time + d / vehicle.speed
        return max(0, vehicle.t_off - eta)

    # 预约收益
    # 无人机预约某个任务点的收益
    def _reservation_uav_task(self, uav: UAV, task: TaskPoint) -> float:
        eta = self._arrival_time(uav, task.x, task.y)
        time_benefit = clip01((uav.t_off - eta) / max(uav.t_off - uav.t_on, 1))
        dist_cost = dis(uav.x, uav.y, task.x, task.y) / self.D_max
        energy_cost = task.cost_power / uav.full_power
        return task.reward / 2.0 + time_benefit - dist_cost - energy_cost
    # 工人预约某个任务点的收益
    def _reservation_worker_task(self, worker: Worker, task: TaskPoint) -> float:
        eta = self._arrival_time(worker, task.x, task.y)
        time_benefit = clip01((worker.t_off - eta) / max(worker.t_off - worker.t_on, 1))
        dist_cost = dis(worker.x, worker.y, task.x, task.y) / self.D_max
        return task.reward / 2.0 + time_benefit - dist_cost
    # 无人机预约某个充电点的收益
    def _reservation_uav_charge(self, uav: UAV, charge: ChargePoint) -> float:
        d = dis(uav.x, uav.y, charge.x, charge.y)
        e_arr = uav.power - d
        charge_need = clip01((uav.full_power - e_arr) / uav.full_power)
        eta = self._arrival_time(uav, charge.x, charge.y)
        time_benefit = clip01((uav.t_off - eta) / max(uav.t_off - uav.t_on, 1))
        dist_cost = d / self.D_max
        return charge_need + time_benefit - dist_cost
    # 小车预约某个充电点的收益
    def _reservation_vehicle_charge(self, vehicle: Vehicle, charge: ChargePoint) -> float:
        d = dis(vehicle.x, vehicle.y, charge.x, charge.y)
        eta = self._arrival_time(vehicle, charge.x, charge.y)
        time_benefit = clip01((vehicle.t_off - eta) / max(vehicle.t_off - vehicle.t_on, 1))
        dist_cost = d / self.D_max
        return time_benefit - dist_cost

    # FIFO配对收益
    def _pairing_gain_task(self, task_id, task_res) -> float:
        if task_id not in task_res:
            return 0.0
        if not self.ablation.use_pairing_reward:
            return 0.0

        res = task_res[task_id]
        uavs = res["uavs"]
        workers = res["workers"]
        if not uavs or not workers:
            return 0.0
        if not self.ablation.use_predictive_fifo:
            return 1.0

        task = self.tasks[task_id]
        # 按到达时间排序
        uavs_sorted = sorted(uavs, key=lambda u: (self._arrival_time(u, task.x, task.y), u.id))
        workers_sorted = sorted(workers, key=lambda w: (self._arrival_time(w, task.x, task.y), w.id))

        u_head = uavs_sorted[0]
        w_head = workers_sorted[0]

        eta_u = self._arrival_time(u_head, task.x, task.y)
        eta_w = self._arrival_time(w_head, task.x, task.y)

        w_max_u = self._max_wait_uav_task(u_head, task)
        w_max_w = self._max_wait_worker(w_head, task)

        deadline_u = eta_u + w_max_u
        deadline_w = eta_w + w_max_w

        # 检查等待区间重叠
        if max(eta_u, eta_w) > min(deadline_u, deadline_w):
            return 0.0

        # 等待代价
        wait_total = abs(eta_u - eta_w)
        denom = w_max_u + w_max_w + 1e-6
        q = wait_total / denom
        return 1.0 - q

    def _pairing_gain_charge(self, charge_id, charge_res) -> float:
        if charge_id not in charge_res:
            return 0.0
        if not self.ablation.use_pairing_reward:
            return 0.0

        res = charge_res[charge_id]
        uavs = res["uavs"]
        vehicles = res["vehicles"]
        if not uavs or not vehicles:
            return 0.0
        if not self.ablation.use_predictive_fifo:
            return 1.0

        charge = self.charges[charge_id]
        uavs_sorted = sorted(uavs, key=lambda u: (self._arrival_time(u, charge.x, charge.y), u.id))
        vehicles_sorted = sorted(vehicles, key=lambda v: (self._arrival_time(v, charge.x, charge.y), v.id))

        u_head = uavs_sorted[0]
        v_head = vehicles_sorted[0]

        eta_u = self._arrival_time(u_head, charge.x, charge.y)
        eta_v = self._arrival_time(v_head, charge.x, charge.y)

        w_max_u = self._max_wait_uav_charge(u_head, charge)
        w_max_v = self._max_wait_vehicle(v_head, charge)

        deadline_u = eta_u + w_max_u
        deadline_v = eta_v + w_max_v

        if max(eta_u, eta_v) > min(deadline_u, deadline_v):
            return 0.0

        wait_total = abs(eta_u - eta_v)
        denom = w_max_u + w_max_v + 1e-6
        q = wait_total / denom
        return 1.0 - q

    # 拥挤惩罚
    def _congestion_task(self, task_id, task_res) -> float:
        if task_id not in task_res:
            return 0.0
        res = task_res[task_id]
        g_u = max(0, len(res["uavs"]) - 1)
        g_w = max(0, len(res["workers"]) - 1)
        return g_u + g_w

    def _congestion_charge(self, charge_id, charge_res) -> float:
        if charge_id not in charge_res:
            return 0.0
        res = charge_res[charge_id]
        g_u = max(0, len(res["uavs"]) - 1)
        g_v = max(0, len(res["vehicles"]) - 1)
        return g_u + g_v

    # 局部势函数计算
    def _task_potential(self, task_id, task_res) -> float:
        # 任务点势函数
        if task_id not in task_res:
            return 0.0
        res = task_res[task_id]
        task = self.tasks[task_id]

        # 预约收益之和
        phi = 0.0
        for u in res["uavs"]:
            phi += self._reservation_uav_task(u, task)
        for w in res["workers"]:
            phi += self._reservation_worker_task(w, task)

        # 配对收益
        phi += self._pairing_gain_task(task_id, task_res)

        # 拥挤惩罚
        if self.ablation.use_crowding_penalty:
            phi -= self._congestion_task(task_id, task_res)

        return phi

    def _charge_potential(self, charge_id, charge_res) -> float:
        # 充电点势函数
        if charge_id not in charge_res:
            return 0.0
        res = charge_res[charge_id]
        charge = self.charges[charge_id]

        phi = 0.0
        for u in res["uavs"]:
            phi += self._reservation_uav_charge(u, charge)
        for v in res["vehicles"]:
            phi += self._reservation_vehicle_charge(v, charge)

        phi += self._pairing_gain_charge(charge_id, charge_res)
        if self.ablation.use_crowding_penalty:
            phi -= self._congestion_charge(charge_id, charge_res)

        return phi

    def _local_potential(self, task_res, charge_res) -> float:
        # 局部势函数
        phi = 0.0
        for tid in task_res:
            phi += self._task_potential(tid, task_res)
        for cid in charge_res:
            phi += self._charge_potential(cid, charge_res)
        return phi

    # 边际收益计算
    def _compute_marginal_gain(self, agent, action_type, action_id,
                                neighbor_uavs, neighbor_workers, neighbor_vehicles):

        # 保存原始状态
        old_target = agent.target
        old_target_type = agent.target_type
        old_mode = agent.mode

        # 计算Phi(a_i=empty, a_{-i})
        agent.target = None
        agent.target_type = None
        agent.mode = Mode.IDLE
        task_res_0, charge_res_0 = self._build_local_reservation(
            agent, neighbor_uavs, neighbor_workers, neighbor_vehicles)
        phi_empty = self._local_potential(task_res_0, charge_res_0)

        # 计算Phi(a_i=a, a_{-i})
        agent.target = action_id
        agent.target_type = action_type
        agent.mode = Mode.MOVE
        task_res_1, charge_res_1 = self._build_local_reservation(
            agent, neighbor_uavs, neighbor_workers, neighbor_vehicles)
        phi_action = self._local_potential(task_res_1, charge_res_1)

        # 恢复原始状态
        agent.target = old_target
        agent.target_type = old_target_type
        agent.mode = old_mode

        return phi_action - phi_empty

    # 事件锁定检查
    def _is_locked(self, agent) -> bool:
        if not self.ablation.use_action_locking:
            return False
        if agent.mode not in (Mode.MOVE, Mode.WAIT, Mode.EXEC):
            return False

        # 条件1：目标仍存在
        if agent.target_type == "task":
            if agent.target is None or self.tasks[agent.target].completed:
                return False
        # 充电点不会被删除，恒成立

        # 条件2：等待未超时
        if agent.mode == Mode.WAIT:
            if self.sys_time >= agent.wait_deadline:
                return False

        # 条件3：能量仍可行（UAV）
        if isinstance(agent, UAV):
            if agent.target_type == "task":
                task = self.tasks[agent.target]
                if not self._uav_task_feasible(agent, task):
                    return False
            elif agent.target_type == "charge":
                charge = self.charges[agent.target]
                if not self._uav_charge_feasible(agent, charge):
                    return False

        # 条件4：时间窗仍可行
        if agent.mode == Mode.MOVE:
            if agent.target_type == "task":
                p = self.tasks[agent.target]
            else:
                p = self.charges[agent.target]
            eta = self._arrival_time(agent, p.x, p.y)
            if eta > agent.t_off:
                return False

        return True

    # 激活率
    def _activation_rate(self, agent) -> float:

        if not self.ablation.use_state_aware_activation:
            return self.activation_scale

        # 时间紧迫因子
        time_ratio = max(0, (agent.t_off - self.sys_time) / max(agent.t_off - agent.t_on, 1))
        f_time = 1.0 + (1.0 - time_ratio) ** 2

        # 密度因子
        n_cand = 0
        if isinstance(agent, UAV):
            for t in self.tasks:
                if not t.completed and dis(agent.x, agent.y, t.x, t.y) <= agent.radius and self._uav_task_feasible(agent, t):
                    n_cand += 1
            for c in self.charges:
                if dis(agent.x, agent.y, c.x, c.y) <= agent.radius and self._uav_charge_feasible(agent, c):
                    n_cand += 1
        elif isinstance(agent, Worker):
            for t in self.tasks:
                if not t.completed and dis(agent.x, agent.y, t.x, t.y) <= agent.radius and self._worker_task_feasible(agent, t):
                    n_cand += 1
        elif isinstance(agent, Vehicle):
            for c in self.charges:
                if dis(agent.x, agent.y, c.x, c.y) <= agent.radius and self._vehicle_charge_feasible(agent, c):
                    n_cand += 1
        f_density = 1.0 + n_cand

        # 电量因子
        if isinstance(agent, UAV):
            f_power = 1.0 + (1.0 - agent.power / agent.full_power) ** 3
        else:
            f_power = 1.0

        return self.activation_scale * f_time * f_density * f_power

    # UAV被激活后的完整决策过程

    def _record_target_switch(self, agent, old_target, old_target_type, old_mode) -> None:
        if old_mode not in (Mode.MOVE, Mode.WAIT, Mode.EXEC):
            return
        if old_target is None:
            return
        if (agent.target, agent.target_type) != (old_target, old_target_type):
            self.target_switches += 1

    def _decide_uav(self, uav: UAV):

        # Step 1: 读取通信范围内的邻居状态
        n_uavs, n_workers, n_vehicles = self._get_neighbors(uav)
        p_uavs, p_workers, p_vehicles = self._perceived_neighbors(uav, n_uavs, n_workers, n_vehicles)

        # Step 2: 事件锁定检查，被锁定后不做任何决策
        old_target = uav.target
        old_target_type = uav.target_type
        old_mode = uav.mode

        if self._is_locked(uav):
            return

        # 解锁 -> IDLE
        uav.mode = Mode.IDLE
        uav.target = None
        uav.target_type = None

        # Step 3: 构造候选集合：未完成、在通信范围内、满足可行性约束（能量+时间窗）
        candidates = []  # (type, id, gain)

        for task in self.tasks:
            if task.completed:
                continue
            if dis(uav.x, uav.y, task.x, task.y) <= uav.radius and self._uav_task_feasible(uav, task):
                candidates.append(("task", task.id))

        for charge in self.charges:
            if dis(uav.x, uav.y, charge.x, charge.y) <= uav.radius and self._uav_charge_feasible(uav, charge):
                candidates.append(("charge", charge.id))

        # 通信范围内没有任何可行目标，空动作（mode=IDLE）
        if not candidates:
            self._record_target_switch(uav, old_target, old_target_type, old_mode)
            uav.tau = self.event_k
            self.total_decisions += 1
            self._broadcast_state(uav)
            return

        # Step 4: 计算智能体动作收益
        best_gain = 0.0
        best_action = None
        best_dist = float('inf')

        for action_type, action_id in candidates:
            gain = self._compute_marginal_gain(
                uav, action_type, action_id, p_uavs, p_workers, p_vehicles)
            if action_type == "task":
                p = self.tasks[action_id]
            else:
                p = self.charges[action_id]
            d = dis(uav.x, uav.y, p.x, p.y)

            # Step 5: 选择收益最大的目标点，如果多个动作收益相同，选择距离更近的
            if gain > best_gain or (gain == best_gain and d < best_dist):
                best_gain = gain
                best_action = (action_type, action_id)
                best_dist = d

        # Step 6: 更新状态
        if best_action is not None:
            action_type, action_id = best_action
            uav.target = action_id
            uav.target_type = action_type
            uav.mode = Mode.MOVE

            if action_type == "task":
                p = self.tasks[action_id]
            else:
                p = self.charges[action_id]
            uav.arrival_time = self._arrival_time(uav, p.x, p.y)

            # 计算等待截止时刻
            if action_type == "task":
                uav.wait_deadline = uav.arrival_time + self._max_wait_uav_task(uav, self.tasks[action_id])
            else:
                uav.wait_deadline = uav.arrival_time + self._max_wait_uav_charge(uav, self.charges[action_id])

        # Step 7: 写状态供邻居读取
        self._record_target_switch(uav, old_target, old_target_type, old_mode)

        uav.tau = self.event_k
        self.total_decisions += 1
        self._broadcast_state(uav)

    # Worker决策
    def _decide_worker(self, worker: Worker):
        n_uavs, n_workers, n_vehicles = self._get_neighbors(worker)
        p_uavs, p_workers, p_vehicles = self._perceived_neighbors(worker, n_uavs, n_workers, n_vehicles)

        old_target = worker.target
        old_target_type = worker.target_type
        old_mode = worker.mode

        if self._is_locked(worker):
            return

        worker.mode = Mode.IDLE
        worker.target = None
        worker.target_type = None

        candidates = []
        for task in self.tasks:
            if task.completed:
                continue
            if dis(worker.x, worker.y, task.x, task.y) <= worker.radius and self._worker_task_feasible(worker, task):
                candidates.append(("task", task.id))

        if not candidates:
            self._record_target_switch(worker, old_target, old_target_type, old_mode)
            worker.tau = self.event_k
            self.total_decisions += 1
            self._broadcast_state(worker)
            return

        best_gain = 0.0
        best_action = None
        best_dist = float('inf')

        for action_type, action_id in candidates:
            gain = self._compute_marginal_gain(
                worker, action_type, action_id, p_uavs, p_workers, p_vehicles)
            p = self.tasks[action_id]
            d = dis(worker.x, worker.y, p.x, p.y)

            if gain > best_gain or (gain == best_gain and d < best_dist):
                best_gain = gain
                best_action = (action_type, action_id)
                best_dist = d

        if best_action is not None:
            action_type, action_id = best_action
            worker.target = action_id
            worker.target_type = action_type
            worker.mode = Mode.MOVE
            p = self.tasks[action_id]
            worker.arrival_time = self._arrival_time(worker, p.x, p.y)
            worker.wait_deadline = worker.arrival_time + self._max_wait_worker(worker, self.tasks[action_id])

        self._record_target_switch(worker, old_target, old_target_type, old_mode)

        worker.tau = self.event_k
        self.total_decisions += 1
        self._broadcast_state(worker)

    # Vehicle决策
    def _decide_vehicle(self, vehicle: Vehicle):
        n_uavs, n_workers, n_vehicles = self._get_neighbors(vehicle)
        p_uavs, p_workers, p_vehicles = self._perceived_neighbors(vehicle, n_uavs, n_workers, n_vehicles)

        old_target = vehicle.target
        old_target_type = vehicle.target_type
        old_mode = vehicle.mode

        if self._is_locked(vehicle):
            return

        vehicle.mode = Mode.IDLE
        vehicle.target = None
        vehicle.target_type = None

        candidates = []
        for charge in self.charges:
            if dis(vehicle.x, vehicle.y, charge.x, charge.y) <= vehicle.radius and self._vehicle_charge_feasible(vehicle, charge):
                candidates.append(("charge", charge.id))

        if not candidates:
            self._record_target_switch(vehicle, old_target, old_target_type, old_mode)
            vehicle.tau = self.event_k
            self.total_decisions += 1
            self._broadcast_state(vehicle)
            return

        best_gain = 0.0
        best_action = None
        best_dist = float('inf')

        for action_type, action_id in candidates:
            gain = self._compute_marginal_gain(
                vehicle, action_type, action_id, p_uavs, p_workers, p_vehicles)
            p = self.charges[action_id]
            d = dis(vehicle.x, vehicle.y, p.x, p.y)

            if gain > best_gain or (gain == best_gain and d < best_dist):
                best_gain = gain
                best_action = (action_type, action_id)
                best_dist = d

        if best_action is not None:
            action_type, action_id = best_action
            vehicle.target = action_id
            vehicle.target_type = action_type
            vehicle.mode = Mode.MOVE
            p = self.charges[action_id]
            vehicle.arrival_time = self._arrival_time(vehicle, p.x, p.y)
            vehicle.wait_deadline = vehicle.arrival_time + self._max_wait_vehicle(vehicle, self.charges[action_id])

        self._record_target_switch(vehicle, old_target, old_target_type, old_mode)

        vehicle.tau = self.event_k
        self.total_decisions += 1
        self._broadcast_state(vehicle)

    # 移动更新
    def _move_agent(self, agent, dt=1.0):
        if agent.mode != Mode.MOVE or agent.target is None:
            return
        # 计算和目标点的距离
        if agent.target_type == "task":
            p = self.tasks[agent.target]
        else:
            p = self.charges[agent.target]

        dx = p.x - agent.x
        dy = p.y - agent.y
        d = math.sqrt(dx**2 + dy**2)

        if d < 1e-6:
            # 已到达
            return

        requested_step = agent.speed * dt
        if isinstance(agent, UAV):
            # UAV 的移动距离受剩余电量约束；若电量耗尽则不能继续前进
            step = min(requested_step, max(0.0, agent.power))
            if step <= 1e-9:
                agent.mode = Mode.IDLE
                agent.target = None
                agent.target_type = None
                self._broadcast_state(agent)
                return
        else:
            step = requested_step

        if step >= d:
            # 一步就能走到
            agent.x = p.x
            agent.y = p.y
            actual_step = d
            if isinstance(agent, UAV):
                agent.power -= actual_step
                agent.power = max(0, agent.power)
        else:
            # 沿方向向量走一步
            agent.x += (dx / d) * step
            agent.y += (dy / d) * step
            actual_step = step
            if isinstance(agent, UAV):
                # UAV扣除移动消耗的电量
                agent.power -= actual_step
                agent.power = max(0, agent.power)
                if agent.power <= 1e-9:
                    # 中途耗尽电量时，停止当前行动
                    agent.mode = Mode.IDLE
                    agent.target = None
                    agent.target_type = None
                    self._broadcast_state(agent)

        self.total_travel_distance += actual_step

    # 到达检查
    def _check_arrival(self, agent):
        if agent.mode != Mode.MOVE or agent.target is None:
            return

        if agent.target_type == "task":
            p = self.tasks[agent.target]
        else:
            p = self.charges[agent.target]

        d = dis(agent.x, agent.y, p.x, p.y)
        if d < 0.5:  # 到达阈值
            agent.x = p.x
            agent.y = p.y
            agent.mode = Mode.WAIT
            agent.arrival_time = self.sys_time
            self._broadcast_state(agent)

    # 检查所有任务点的FIFO匹配
    def _check_task_matching(self):
        for task in self.tasks:
            if task.completed:
                continue

            # 找到在该任务点等待的UAV和Worker
            waiting_uavs = [u for u in self.uavs
                           if u.mode == Mode.WAIT and u.target == task.id
                           and u.target_type == "task"]
            waiting_workers = [w for w in self.workers
                              if w.mode == Mode.WAIT and w.target == task.id
                              and w.target_type == "task"]

            if not waiting_uavs or not waiting_workers:
                continue

            # FIFO: 按到达时间排序
            waiting_uavs.sort(key=lambda u: (u.arrival_time, u.id))
            waiting_workers.sort(key=lambda w: (w.arrival_time, w.id))

            u = waiting_uavs[0]
            w = waiting_workers[0]

            # 检查等待区间重叠
            if max(u.arrival_time, w.arrival_time) <= min(u.wait_deadline, w.wait_deadline):
                # 匹配成功，开始执行
                self.successful_task_matches += 1
                exec_start = max(u.arrival_time, w.arrival_time)
                exec_time = task.cost_power / u.speed
                finish_time = exec_start + exec_time

                # UAV等待消耗
                u_wait = max(0, exec_start - u.arrival_time)
                u.power -= u.hover_power * u_wait

                u.mode = Mode.EXEC
                w.mode = Mode.EXEC
                u.partner_id = w.id
                w.partner_id = u.id
                u.exec_finish_time = finish_time
                w.exec_finish_time = finish_time
                self._broadcast_state(u)
                self._broadcast_state(w)

    # 检查所有充电点的FIFO匹配
    def _check_charge_matching(self):
        for charge in self.charges:
            if charge.occupied:
                continue

            waiting_uavs = [u for u in self.uavs
                           if u.mode == Mode.WAIT and u.target == charge.id
                           and u.target_type == "charge"]
            waiting_vehicles = [v for v in self.vehicles
                               if v.mode == Mode.WAIT and v.target == charge.id
                               and v.target_type == "charge"]

            if not waiting_uavs or not waiting_vehicles:
                continue

            waiting_uavs.sort(key=lambda u: (u.arrival_time, u.id))
            waiting_vehicles.sort(key=lambda v: (v.arrival_time, v.id))

            u = waiting_uavs[0]
            v = waiting_vehicles[0]

            if max(u.arrival_time, v.arrival_time) <= min(u.wait_deadline, v.wait_deadline):
                self.successful_charge_matches += 1
                exec_start = max(u.arrival_time, v.arrival_time)

                # UAV等待消耗
                u_wait = max(0, exec_start - u.arrival_time)
                u.power -= u.hover_power * u_wait

                e_arr = u.power
                charge_time = (u.full_power - e_arr) / v.charge_power
                finish_time = exec_start + charge_time

                u.mode = Mode.EXEC
                v.mode = Mode.EXEC
                u.partner_id = v.id
                v.partner_id = u.id
                u.exec_finish_time = finish_time
                v.exec_finish_time = finish_time
                charge.occupied = True
                self._broadcast_state(u)
                self._broadcast_state(v)

    # 目标完成检查
    def _check_service_completion(self):
        # 任务完成
        for u in self.uavs:
            if u.mode == Mode.EXEC and u.target_type == "task":
                if self.sys_time >= u.exec_finish_time:
                    task = self.tasks[u.target]
                    if not task.completed:
                        task.completed = True
                        self.completed_tasks.append(task.id)
                        u.power -= task.cost_power
                        u.power = max(0, u.power)

                    # Worker完成
                    for w in self.workers:
                        if w.mode == Mode.EXEC and w.partner_id == u.id and w.target == u.target:
                            w.mode = Mode.IDLE
                            w.target = None
                            w.target_type = None
                            w.partner_id = None
                            self._broadcast_state(w)
                            break

                    u.mode = Mode.IDLE
                    u.target = None
                    u.target_type = None
                    u.partner_id = None
                    self._broadcast_state(u)

        # 充电完成
        for u in self.uavs:
            if u.mode == Mode.EXEC and u.target_type == "charge":
                if self.sys_time >= u.exec_finish_time:
                    u.power = u.full_power  # 充满

                    charge = self.charges[u.target]
                    charge.occupied = False

                    for v in self.vehicles:
                        if v.mode == Mode.EXEC and v.partner_id == u.id and v.target == u.target:
                            v.mode = Mode.IDLE
                            v.target = None
                            v.target_type = None
                            v.partner_id = None
                            self._broadcast_state(v)
                            break

                    u.mode = Mode.IDLE
                    u.target = None
                    u.target_type = None
                    u.partner_id = None
                    self._broadcast_state(u)

    # 处理等待超时
    def _check_timeouts(self):
        for agent_list in [self.uavs, self.workers, self.vehicles]:
            for agent in agent_list:
                if agent.mode == Mode.WAIT:
                    if self.sys_time >= agent.wait_deadline:
                        if isinstance(agent, UAV):
                            waited = max(0.0, agent.wait_deadline - agent.arrival_time)
                            agent.power -= agent.hover_power * waited
                            agent.power = max(0.0, agent.power)
                        agent.mode = Mode.IDLE
                        agent.target = None
                        agent.target_type = None
                        agent.partner_id = None
                        agent.arrival_time = float('inf')
                        agent.wait_deadline = float('inf')
                        self.failed_waits += 1
                        self._broadcast_state(agent)

    # 智能体上下线处理
    def _manage_online_status(self):
        for agent_list in [self.uavs, self.workers, self.vehicles]:
            for agent in agent_list:
                if agent.t_on <= self.sys_time < agent.t_off:
                    # 在线
                    if agent.mode == Mode.OFFLINE:
                        agent.mode = Mode.IDLE
                        self._broadcast_state(agent)
                else:
                    # 下线
                    if agent.mode != Mode.OFFLINE:
                        agent.mode = Mode.OFFLINE
                        agent.target = None
                        agent.target_type = None
                        agent.partner_id = None
                        agent.arrival_time = float('inf')
                        agent.wait_deadline = float('inf')
                        agent.exec_finish_time = float('inf')
                        self._broadcast_state(agent)

    #将三类智能体拼成一个总列表，统一遍历
    def _all_agents(self):
        return self.uavs + self.workers + self.vehicles

    def _sample_activation_events(self) -> list:
        events = [] #存储所有候选激活事件

        for u in self.uavs:
            if self._is_online(u):
                rate = self._activation_rate(u)
                if rate > 1e-12:
                    events.append((self.sys_time + np.random.exponential(1.0 / rate), "uav", u))

        for w in self.workers:
            if self._is_online(w):
                rate = self._activation_rate(w)
                if rate > 1e-12:
                    events.append((self.sys_time + np.random.exponential(1.0 / rate), "worker", w))

        for v in self.vehicles:
            if self._is_online(v):
                rate = self._activation_rate(v)
                if rate > 1e-12:
                    events.append((self.sys_time + np.random.exponential(1.0 / rate), "vehicle", v))

        return events

    def _next_deterministic_event_time(self) -> float:
        next_time = float('inf')
        for agent in self._all_agents():
            if agent.mode == Mode.OFFLINE:
                if self.sys_time < agent.t_on:
                    next_time = min(next_time, agent.t_on)
                continue

            if self.sys_time < agent.t_off:
                next_time = min(next_time, agent.t_off)

            if agent.mode == Mode.MOVE and agent.target is not None:
                if agent.target_type == "task":
                    p = self.tasks[agent.target]
                else:
                    p = self.charges[agent.target]
                next_time = min(next_time, self.sys_time + dis(agent.x, agent.y, p.x, p.y) / agent.speed)

            if agent.mode == Mode.WAIT and agent.wait_deadline > self.sys_time:
                next_time = min(next_time, agent.wait_deadline)

            if agent.mode == Mode.EXEC and agent.exec_finish_time > self.sys_time:
                next_time = min(next_time, agent.exec_finish_time)

        return next_time

    def _advance_physical_state(self, dt: float):
        if dt <= 0:
            return
        for u in self.uavs:
            if self._is_online(u):
                self._move_agent(u, dt)
        for w in self.workers:
            if self._is_online(w):
                self._move_agent(w, dt)
        for v in self.vehicles:
            if self._is_online(v):
                self._move_agent(v, dt)

    def _process_physical_events(self):
        self._manage_online_status()

        for u in self.uavs:
            if self._is_online(u):
                self._check_arrival(u)
        for w in self.workers:
            if self._is_online(w):
                self._check_arrival(w)
        for v in self.vehicles:
            if self._is_online(v):
                self._check_arrival(v)

        self._check_service_completion()
        self._check_timeouts()
        self._check_task_matching()
        self._check_charge_matching()


    def get_metrics(self) -> Dict[str, object]:
        completed = len(self.completed_tasks)
        total = len(self.tasks)
        total_matches = self.successful_task_matches + self.successful_charge_matches
        return {
            "ablation": self.ablation.name,
            "completed": completed,
            "total": total,
            "completion_rate": completed / total if total else 0.0,
            "decision_count": self.total_decisions,
            "event_count": self.event_k,
            "failed_waits": self.failed_waits,
            "successful_task_matches": self.successful_task_matches,
            "successful_charge_matches": self.successful_charge_matches,
            "successful_matches": total_matches,
            "successful_matching_rate": total_matches / max(self.total_decisions, 1),
            "waiting_timeout_rate": self.failed_waits / max(total_matches + self.failed_waits, 1),
            "target_switches": self.target_switches,
            "total_travel_distance": self.total_travel_distance,
        }

    def run_event_driven(self, verbose=True):
        # 主循环
        if verbose:
            print(f"UAVs: {len(self.uavs)}, Workers: {len(self.workers)}, "
                  f"Vehicles: {len(self.vehicles)}")
            print(f"Tasks: {len(self.tasks)}, Charges: {len(self.charges)}")
            print(f"Limit Time: {self.limit_time}, Radius: {self.radius}")
            print(f"D_max: {self.D_max:.2f}")
            print("-" * 50)

        total_tasks = len(self.tasks)
        self.sys_time = 0.0
        self._manage_online_status()  # 智能体上下线管理
        next_report_time = 0.0        # 每30个时间单位打印一次进度
        eps = 1e-9

        while self.sys_time < self.limit_time:
            activation_events = self._sample_activation_events()  # 为每个在线智能体采样下一次激活事件
            next_activation_time = min(
                (event_time for event_time, _, _ in activation_events),
                default=float('inf'),
            )
            next_deterministic_time = self._next_deterministic_event_time()  # 下一次确定性物理事件的最早时刻
            next_time = min(
                next_activation_time,
                next_deterministic_time,
                float(self.limit_time),
            )

            if next_time == float('inf'):
                break

            dt = max(0.0, next_time - self.sys_time)
            self._advance_physical_state(dt)  # 所有人按这段时间继续移动
            self.sys_time = next_time         # 系统时间跳到 next_time

            self._process_physical_events()   # 处理该时刻发生的物理事件
            if next_activation_time <= next_time + eps:
                triggered = [
                    (atype, agent)
                    for event_time, atype, agent in activation_events
                    if abs(event_time - next_time) <= eps
                ]
                triggered.sort(key=lambda item: (item[0], item[1].id))  # 同时刻触发者按固定顺序逐个更新
                for atype, agent in triggered:
                    if not self._is_online(agent):
                        continue
                    self.event_k += 1
                    if atype == 'uav':
                        self._decide_uav(agent)
                    elif atype == 'worker':
                        self._decide_worker(agent)
                    elif atype == 'vehicle':
                        self._decide_vehicle(agent)

            if verbose:
                while next_report_time <= self.sys_time + eps and next_report_time <= self.limit_time:
                    n_completed = len(self.completed_tasks)
                    online_u = sum(1 for u in self.uavs if self._is_online(u))
                    online_w = sum(1 for w in self.workers if self._is_online(w))
                    online_v = sum(1 for v in self.vehicles if self._is_online(v))
                    print(f"t={next_report_time:6.1f} | 完成: {n_completed}/{total_tasks} "
                          f"({100*n_completed/total_tasks:.1f}%) | "
                          f"在线: U={online_u} W={online_w} V={online_v} | "
                          f"决策次数: {self.total_decisions} | "
                          f"等待失败: {self.failed_waits}")
                    next_report_time += 30.0

            if len(self.completed_tasks) >= total_tasks:
                break

        n_completed = len(self.completed_tasks)
        if verbose:
            print("最终结果:")
            print(f"  完成任务: {n_completed}/{total_tasks} ({100*n_completed/total_tasks:.1f}%)")
            print(f"  总决策次数: {self.total_decisions}")
            print(f"  总异步事件: {self.event_k}")
            print(f"  等待超时次数: {self.failed_waits}")

        return n_completed, total_tasks


if __name__ == '__main__':
    base = Path(__file__).resolve().parent / 'data'
    parser = argparse.ArgumentParser(description='Async-PALP event-driven scheduler')
    parser.add_argument('--visualize-3d', action='store_true', help='run with the live procedural 3-D scene')
    parser.add_argument('--data', type=Path, default=base, help='dataset folder')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--limit-time', type=float, default=180.0)
    parser.add_argument('--radius', type=float, default=8.0)
    parser.add_argument('--activation-scale', type=float, default=0.05)
    parser.add_argument('--playback-speed', type=float, default=8.0, help='simulation seconds per real second in Unity')
    parser.add_argument('--unity-build', type=Path,
                        default=Path(__file__).resolve().parent / 'unity_build' / 'AsyncPALP3D.exe',
                        help='path to the render-only Unity player')
    parser.add_argument('--state-file', type=Path,
                        default=Path(__file__).resolve().parent / 'outputs' / 'runtime' / 'unity_state.json',
                        help='atomic JSON state file shared with Unity')
    parser.add_argument('--no-hold', action='store_true', help='close the visualization when the simulation ends')
    args = parser.parse_args()
    data_dir = args.data.resolve()

    if args.visualize_3d:
        from unity_3d_visualizer import run_unity_visualization

        run_unity_visualization(
            data_dir=data_dir,
            seed=args.seed,
            limit_time=args.limit_time,
            radius=args.radius,
            activation_scale=args.activation_scale,
            playback_speed=args.playback_speed,
            unity_build=args.unity_build.resolve(),
            state_file=args.state_file.resolve(),
            hold_window=not args.no_hold,
        )
    else:
        scheduler_obj = scheduler(
            uav_file=str(data_dir / 'uavMap.csv'),
            worker_file=str(data_dir / 'workerMap.csv'),
            vehicle_file=str(data_dir / 'carMap.csv'),
            task_file=str(data_dir / 'taskMap.csv'),
            charge_file=str(data_dir / 'chargeMap.csv'),
            radius=args.radius,
            hover_power=0.5,
            limit_time=args.limit_time,
            seed=args.seed,
            activation_scale=args.activation_scale,
        )
        scheduler_obj.run_event_driven(verbose=True)
