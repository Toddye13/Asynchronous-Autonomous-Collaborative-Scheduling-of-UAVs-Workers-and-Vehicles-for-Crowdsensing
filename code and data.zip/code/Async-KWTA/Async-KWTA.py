from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from algorithm import Mode, UAV, Vehicle, Worker, dis, scheduler as async_scheduler


class scheduler(async_scheduler):
    TASK_TOP_K = 3
    CHARGE_TOP_K = 3
    UAV_LOW_POWER_RATIO = 0.3

    # 按距离近优先、编号小优先（距离相同时）的规则对候选目标列表排序。
    def _sort_entries(self, entries: list[tuple[int, float]]) -> list[tuple[int, float]]:
        return sorted(entries, key=lambda item: (item[1], item[0]))

    # 从已排序候选列表中取出最优目标点编号
    def _choose_best(self, entries: list[tuple[int, float]]) -> int | None:
        if not entries:
            return None
        return entries[0][0]

    # 从已排序候选列表中提取前K个目标点编号
    def _top_k_ids(self, entries: list[tuple[int, float]], k: int) -> tuple[int, ...]:
        return tuple(target_id for target_id, _ in entries[:k])

    def _agent_start_time(self, agent) -> float:
        return max(self.sys_time, agent.t_on)

    def _task_plan(self, agent, task) -> tuple[float, float] | None:
        start = self._agent_start_time(agent)
        distance = dis(agent.x, agent.y, task.x, task.y)
        arrival = start + distance / agent.speed
        if arrival > agent.t_off:
            return None

        if isinstance(agent, UAV):
            d_return, _ = self._nearest_charge(task.x, task.y)
            if distance + task.cost_power + d_return > agent.power:
                return None
            if start == self.sys_time:
                deadline = arrival + self._max_wait_uav_task(agent, task)
            else:
                deadline = agent.t_off
        else:
            deadline = agent.t_off
        return arrival, deadline

    def _charge_plan(self, agent, charge) -> tuple[float, float] | None:
        start = self._agent_start_time(agent)
        distance = dis(agent.x, agent.y, charge.x, charge.y)
        if isinstance(agent, UAV) and distance > agent.power:
            return None

        arrival = start + distance / agent.speed
        if arrival > agent.t_off:
            return None

        if isinstance(agent, UAV):
            if start == self.sys_time:
                deadline = arrival + self._max_wait_uav_charge(agent, charge)
            else:
                deadline = agent.t_off
        else:
            deadline = agent.t_off
        return arrival, deadline

    def _intervals_overlap(
        self,
        arrival: float,
        deadline: float,
        partner_arrival: float,
        partner_deadline: float,
    ) -> bool:
        return max(arrival, partner_arrival) <= min(deadline, partner_deadline)

    def _task_partner_plans(self, agent, task) -> list[tuple[float, float]]:
        partners = self.workers if isinstance(agent, UAV) else self.uavs
        plans: list[tuple[float, float]] = []
        for partner in partners:
            if self.sys_time > partner.t_off:
                continue

            if (
                partner.mode in (Mode.MOVE, Mode.WAIT, Mode.EXEC)
                and partner.target_type == "task"
                and partner.target == task.id
            ):
                arrival = self.sys_time if partner.mode == Mode.WAIT else partner.arrival_time
                deadline = partner.wait_deadline if partner.wait_deadline != float("inf") else partner.t_off
                plans.append((arrival, deadline))
                continue

            if partner.mode not in (Mode.IDLE, Mode.OFFLINE):
                continue
            if dis(partner.x, partner.y, task.x, task.y) > partner.radius:
                continue
            plan = self._task_plan(partner, task)
            if plan is not None:
                plans.append(plan)
        return plans

    def _charge_partner_plans(self, agent, charge) -> list[tuple[float, float]]:
        partners = self.vehicles if isinstance(agent, UAV) else self.uavs
        plans: list[tuple[float, float]] = []
        for partner in partners:
            if self.sys_time > partner.t_off:
                continue

            if (
                partner.mode in (Mode.MOVE, Mode.WAIT, Mode.EXEC)
                and partner.target_type == "charge"
                and partner.target == charge.id
            ):
                arrival = self.sys_time if partner.mode == Mode.WAIT else partner.arrival_time
                deadline = partner.wait_deadline if partner.wait_deadline != float("inf") else partner.t_off
                plans.append((arrival, deadline))
                continue

            if partner.mode not in (Mode.IDLE, Mode.OFFLINE):
                continue
            if dis(partner.x, partner.y, charge.x, charge.y) > partner.radius:
                continue
            plan = self._charge_plan(partner, charge)
            if plan is not None:
                plans.append(plan)
        return plans

    def _has_task_partner(self, agent, task) -> bool:
        plan = self._task_plan(agent, task)
        if plan is None:
            return False
        arrival, deadline = plan
        return any(
            self._intervals_overlap(arrival, deadline, partner_arrival, partner_deadline)
            for partner_arrival, partner_deadline in self._task_partner_plans(agent, task)
        )

    def _has_charge_partner(self, agent, charge) -> bool:
        plan = self._charge_plan(agent, charge)
        if plan is None:
            return False
        arrival, deadline = plan
        return any(
            self._intervals_overlap(arrival, deadline, partner_arrival, partner_deadline)
            for partner_arrival, partner_deadline in self._charge_partner_plans(agent, charge)
        )

    def _filter_entries_with_partner(
        self,
        agent,
        entries: list[tuple[int, float]],
        target_type: str,
    ) -> list[tuple[int, float]]:
        if target_type == "task":
            filtered = [
                entry for entry in entries
                if self._has_task_partner(agent, self.tasks[entry[0]])
            ]
        else:
            filtered = [
                entry for entry in entries
                if self._has_charge_partner(agent, self.charges[entry[0]])
            ]
        return filtered or entries

    # 为UAV构造可行任务点候选列表，并按距离从近到远排序
    def _uav_task_entries(self, uav: UAV) -> list[tuple[int, float]]:
        entries = []
        for task in self.tasks:
            if task.completed:
                continue
            if dis(uav.x, uav.y, task.x, task.y) <= uav.radius and self._uav_task_feasible(uav, task):
                distance = dis(uav.x, uav.y, task.x, task.y)
                entries.append((task.id, distance))
        return self._sort_entries(entries)

    # 为UAV构造可行充电点候选列表，并按距离从近到远排序
    def _uav_charge_entries(self, uav: UAV) -> list[tuple[int, float]]:
        entries = []
        for charge in self.charges:
            if dis(uav.x, uav.y, charge.x, charge.y) <= uav.radius and self._uav_charge_feasible(uav, charge):
                distance = dis(uav.x, uav.y, charge.x, charge.y)
                entries.append((charge.id, distance))
        return self._sort_entries(entries)

    # 为Worker构造可行任务点候选列表，并按距离从近到远排序
    def _worker_task_entries(self, worker: Worker) -> list[tuple[int, float]]:
        entries = []
        for task in self.tasks:
            if task.completed:
                continue
            if dis(worker.x, worker.y, task.x, task.y) <= worker.radius and self._worker_task_feasible(worker, task):
                distance = dis(worker.x, worker.y, task.x, task.y)
                entries.append((task.id, distance))
        return self._sort_entries(entries)

    # 为当前Vehicle构造可行充电点候选列表，并按距离从近到远排序
    def _vehicle_charge_entries(self, vehicle: Vehicle) -> list[tuple[int, float]]:
        entries = []
        for charge in self.charges:
            if dis(vehicle.x, vehicle.y, charge.x, charge.y) <= vehicle.radius and self._vehicle_charge_feasible(
                vehicle, charge
            ):
                distance = dis(vehicle.x, vehicle.y, charge.x, charge.y)
                entries.append((charge.id, distance))
        return self._sort_entries(entries)

    # 智能体在自己的前K个候选和合作方前K个候选集之间取交集，有交集就选交集中最近的，否则退回选自己前K个中最近的。
    def _choose_from_intersection(
        self,
        own_entries: list[tuple[int, float]],
        partner_topk_union: set[int],
        k: int,
    ) -> tuple[int | None, bool]:
        own_top_k_entries = own_entries[:k]
        if not own_top_k_entries:
            return None, False

        intersecting_entries = [entry for entry in own_top_k_entries if entry[0] in partner_topk_union]
        chosen = self._choose_best(intersecting_entries)
        if chosen is not None:
            return chosen, True

        return self._choose_best(own_top_k_entries), False

    # 合并通信范围内所有Worker的前K个任务点候选集
    def _uav_task_topk_union_from_workers(self, workers: list[Worker]) -> set[int]:
        union: set[int] = set()
        for worker in workers:
            union.update(self._top_k_ids(self._worker_task_entries(worker), self.TASK_TOP_K))
        return union

    # 合并通信范围内所有Vehicle的前K个充电点候选集
    def _uav_charge_topk_union_from_vehicles(self, vehicles: list[Vehicle]) -> set[int]:
        union: set[int] = set()
        for vehicle in vehicles:
            union.update(self._top_k_ids(self._vehicle_charge_entries(vehicle), self.CHARGE_TOP_K))
        return union

    # 合并通信范围内所有UAV的前K个任务点候选集
    def _worker_task_topk_union_from_uavs(self, uavs: list[UAV]) -> set[int]:
        union: set[int] = set()
        for uav in uavs:
            union.update(self._top_k_ids(self._uav_task_entries(uav), self.TASK_TOP_K))
        return union

    # 合并通信范围内所有UAV的前K个充电候选集。
    def _vehicle_charge_topk_union_from_uavs(self, uavs: list[UAV]) -> set[int]:
        union: set[int] = set()
        for uav in uavs:
            union.update(self._top_k_ids(self._uav_charge_entries(uav), self.CHARGE_TOP_K))
        return union

    # UAV决策
    def _decide_uav(self, uav: UAV):
        n_uavs, n_workers, n_vehicles = self._get_neighbors(uav)
        p_uavs, p_workers, p_vehicles = self._perceived_neighbors(uav, n_uavs, n_workers, n_vehicles)

        if self._is_locked(uav):
            return

        uav.mode = Mode.IDLE
        uav.target = None
        uav.target_type = None

        # 分别生成任务侧和充电侧的候选列表
        task_entries = self._filter_entries_with_partner(uav, self._uav_task_entries(uav), "task")
        charge_entries = self._filter_entries_with_partner(uav, self._uav_charge_entries(uav), "charge")

        # 任务侧执行一次K-WTA
        task_choice, task_intersects = self._choose_from_intersection(
            task_entries, self._uav_task_topk_union_from_workers(p_workers), self.TASK_TOP_K
        )
        # 充电侧执行一次K-WTA
        charge_choice, charge_intersects = self._choose_from_intersection(
            charge_entries, self._uav_charge_topk_union_from_vehicles(p_vehicles), self.CHARGE_TOP_K
        )

        # 根据当前电量高低决定优先做任务还是优先充电，电量比<0.3前往充电
        power_ratio = (uav.power / uav.full_power) if uav.full_power > 0 else 0.0
        prefer_task = power_ratio > self.UAV_LOW_POWER_RATIO

        # 如果有任务候选，且当前电量较高或没有充电候选，则优先选择任务
        if task_choice is not None and (prefer_task or charge_choice is None):
            action_type = "task"
            action_id = task_choice
        # 否则若存在充电候选，则选择充电
        elif charge_choice is not None:
            action_type = "charge"
            action_id = charge_choice
        # 若没有充电候选但仍有任务候选，则退回选择任务
        elif task_choice is not None:
            action_type = "task"
            action_id = task_choice
        else:
            # 若任务点和充电点都没有候选，则保持空闲并广播当前状态
            uav.tau = self.event_k
            self.total_decisions += 1
            self._broadcast_state(uav)
            return

        # 更新状态
        uav.target = action_id
        uav.target_type = action_type
        uav.mode = Mode.MOVE
        point = self.tasks[action_id] if action_type == "task" else self.charges[action_id]
        uav.arrival_time = self._arrival_time(uav, point.x, point.y)
        if action_type == "task":
            uav.wait_deadline = uav.arrival_time + self._max_wait_uav_task(uav, self.tasks[action_id])
        else:
            uav.wait_deadline = uav.arrival_time + self._max_wait_uav_charge(uav, self.charges[action_id])

        uav.tau = self.event_k
        self.total_decisions += 1
        self._broadcast_state(uav)

    # Worker被异步激活后，先在自身前K个任务候选与通信范围内UAV的前K个任务候选并集中取交集，优先选择交集内最近的任务点
    # 若无交集则退回选择自身前K中最近的任务点移动
    def _decide_worker(self, worker: Worker):
        n_uavs, n_workers, n_vehicles = self._get_neighbors(worker)
        p_uavs, _, _ = self._perceived_neighbors(worker, n_uavs, n_workers, n_vehicles)

        if self._is_locked(worker):
            return

        worker.mode = Mode.IDLE
        worker.target = None
        worker.target_type = None

        task_entries = self._filter_entries_with_partner(worker, self._worker_task_entries(worker), "task")
        task_choice, _ = self._choose_from_intersection(
            task_entries, self._worker_task_topk_union_from_uavs(p_uavs), self.TASK_TOP_K
        )
        if task_choice is None:
            worker.tau = self.event_k
            self.total_decisions += 1
            self._broadcast_state(worker)
            return

        worker.target = task_choice
        worker.target_type = "task"
        worker.mode = Mode.MOVE
        point = self.tasks[task_choice]
        worker.arrival_time = self._arrival_time(worker, point.x, point.y)
        worker.wait_deadline = worker.arrival_time + self._max_wait_worker(worker, point)

        worker.tau = self.event_k
        self.total_decisions += 1
        self._broadcast_state(worker)

    # Vehicle决策同Worker
    def _decide_vehicle(self, vehicle: Vehicle):
        n_uavs, n_workers, n_vehicles = self._get_neighbors(vehicle)
        p_uavs, _, _ = self._perceived_neighbors(vehicle, n_uavs, n_workers, n_vehicles)

        if self._is_locked(vehicle):
            return

        vehicle.mode = Mode.IDLE
        vehicle.target = None
        vehicle.target_type = None

        charge_entries = self._filter_entries_with_partner(vehicle, self._vehicle_charge_entries(vehicle), "charge")
        charge_choice, _ = self._choose_from_intersection(
            charge_entries, self._vehicle_charge_topk_union_from_uavs(p_uavs), self.CHARGE_TOP_K
        )
        if charge_choice is None:
            vehicle.tau = self.event_k
            self.total_decisions += 1
            self._broadcast_state(vehicle)
            return

        vehicle.target = charge_choice
        vehicle.target_type = "charge"
        vehicle.mode = Mode.MOVE
        point = self.charges[charge_choice]
        vehicle.arrival_time = self._arrival_time(vehicle, point.x, point.y)
        vehicle.wait_deadline = vehicle.arrival_time + self._max_wait_vehicle(vehicle, point)

        vehicle.tau = self.event_k
        self.total_decisions += 1
        self._broadcast_state(vehicle)

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="K-WTA baseline for asynchronous multi-agent scheduling.")
    parser.add_argument(
        "--data-dir",
        default=str(Path(__file__).resolve().parent / "data" / "HighpowerDatasets" / "Random_1"),
        help="Dataset folder containing uavMap.csv, workerMap.csv, carMap.csv, taskMap.csv, and chargeMap.csv.",
    )
    parser.add_argument("--radius", type=float, default=8.0)
    parser.add_argument("--limit-time", type=float, default=180.0)
    parser.add_argument("--hover-power", type=float, default=0.5)
    parser.add_argument("--seed", type=int, default=6012220)
    parser.add_argument("--activation-scale", type=float, default=0.05)
    parser.add_argument("--quiet", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    base = Path(args.data_dir)
    scheduler_obj = scheduler(
        uav_file=str(base / "uavMap.csv"),
        worker_file=str(base / "workerMap.csv"),
        vehicle_file=str(base / "carMap.csv"),
        task_file=str(base / "taskMap.csv"),
        charge_file=str(base / "chargeMap.csv"),
        radius=args.radius,
        hover_power=args.hover_power,
        limit_time=args.limit_time,
        seed=args.seed,
        activation_scale=args.activation_scale,
    )

    completed, total = scheduler_obj.run_event_driven(verbose=not args.quiet)
    completion_rate = completed / total if total else 0.0
    print(
        f"K-WTA result: {base.name} completed {completed}/{total} "
        f"({completion_rate * 100.0:.2f}%), decisions={scheduler_obj.total_decisions}, "
        f"events={scheduler_obj.event_k}, failed_waits={scheduler_obj.failed_waits}"
    )


if __name__ == "__main__":
    main()
