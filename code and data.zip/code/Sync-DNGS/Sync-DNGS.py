"""基于 HoAs-PALN_Correct.py 的同步调度 interval/seed 实验。

在项目目录运行：python code/HoAs-PALN-1006.py
原有收益、Softmax、局部 Nash 更新、FCFS 充电及成功匹配完成口径均保留。
decision_count 与 Async-PALP total_decisions 使用相同单位：
每轮每个在线、未锁定的 UAV/Worker/Car 作一次完整调度决策计 1 次，
空动作和失败匹配也计入；初始化、内部 best-response 和 Nash 检查不另计。
完成率最高种子仅指本次测试的种子集合，完成率与决策次数取自同一次运行。
"""

import argparse
import contextlib
import hashlib
import json
from pathlib import Path

# 默认扫描范围；--intervals / --seeds 可覆盖这些设置。
DEFAULT_INTERVALS = (5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15)
DEFAULT_SEEDS = (42, 43, 44, 45, 46)
DEFAULT_RANDOM = 'all'
TARGET_DECISIONS = 550
COUNT_TOLERANCE_PERCENT = 5
MATCHING_DIAGNOSTICS = []  # 只记录原求解器的 joint_equilibrium，不干预行为。

CORRECT_SOURCE_SHA256 = '950a09bc735343b2a03116f8710e5e5ca36c87212a70ea7cb70e0314c7fbe7ad'

# 以下为 Correct 原算法；唯一附加项是被动记录联合 Nash 检查结果。
import numpy as np
import random
import matplotlib.pyplot as plt
import concurrent.futures
import pandas as pd
import time
import math
import os
from collections import defaultdict

# 记录程序开始时间
start_time = time.time()

# 通信半径
RADIUS = 6
# 决策时间间隔（秒）
INTERVAL = 8
# 限制总时间（秒）
LIMIT_TIME = 180

# 论文主体实验默认不引入通信丢包；仅在鲁棒性实验中显式开启。
ENABLE_PACKET_LOSS = False
PACKET_LOSS_RANGE = (0.05, 0.10)

# 与论文主体实验及原始统计口径保持一致：在决策时刻检查智能体在线，
# 但不额外丢弃已经形成、仅完成时刻超过下线/仿真截止时刻的匹配。
# 若需要评估更严格的“动作必须在在线窗口内执行完毕”场景，可显式设为 True。
ENFORCE_ACTION_DEADLINES = False

UAV_charge_info = None

def distance(agent1, agent2):
    """
    计算两个智能体之间的距离。

    参数:
        agent1 (array-like): 第一个智能体的位置。
        agent2 (array-like): 第二个智能体的位置。

    返回:
        float: 两个智能体之间的距离。
    """
    return np.linalg.norm(agent1 - agent2)


def softmax_select_target(agent_pos, all_targets, candidate_targets):
    """严格按论文式(20)-(21)，以 score=-distance 的 Softmax 选择行为点。"""
    if not candidate_targets:
        return None

    candidate_targets = list(candidate_targets)
    scores = -np.array(
        [distance(agent_pos, all_targets[target_idx]) for target_idx in candidate_targets],
        dtype=float
    )
    # 减去最大值只用于数值稳定，不改变式(21)的概率。
    exp_scores = np.exp(scores - np.max(scores))
    probabilities = exp_scores / np.sum(exp_scores)
    return int(np.random.choice(candidate_targets, p=probabilities))


def build_valid_targets(all_agents, all_targets, uPows=None, required_powers=None):
    """构造同时满足通信半径和论文式(3)/(4)电量约束的行为点集合。"""
    valid_targets_per_agent = {}
    for agent_idx, agent_pos in enumerate(all_agents):
        valid_targets = []
        for target_idx, target_pos in enumerate(all_targets):
            if distance(agent_pos, target_pos) > RADIUS:
                continue
            if uPows is not None and required_powers is not None:
                if uPows[agent_idx] < required_powers[agent_idx, target_idx]:
                    continue
            valid_targets.append(target_idx)
        valid_targets_per_agent[agent_idx] = valid_targets
    return valid_targets_per_agent

def split_uav_data(uav_data, task_data, charge_data, worker_data, car_data, iteration, current_time):
    """
    根据无人机电量和预期收益，将无人机划分为执行任务或续航。

    参数:
        uav_data (DataFrame): 无人机数据。
        task_data (DataFrame): 任务数据。
        charge_data (DataFrame): 充电站数据。
        worker_data (DataFrame): 工人数据。
        car_data (DataFrame): 汽车数据。
        iteration (int): 当前迭代次数。
        current_time (int): 当前时间。

    返回:
        四个DataFrame，分别为任务可用、任务不可用、续航可用、续航不可用的无人机数据。
    """
    # 式(10)/(17)使用 UAV 自身的 U_downtime，而不是截断到 LIMIT_TIME。
    # estimate_* 中再减去本轮 INTERVAL，等价于 U_downtime-SysTime。
    uav_data = uav_data.copy()
    uav_data['time_left'] = uav_data['U_downtime'] - (iteration - 1) * INTERVAL

    # 过滤当前在线的无人机
    uav_online = uav_data[
        (uav_data['U_uptime'] <= current_time) & (uav_data['U_downtime'] >= current_time)
        ]

    uav_task_list = []
    uav_charge_list = []

    for index, uav in uav_online.iterrows():
        # 计算执行任务的预期收益
        utility_task = estimate_tasks_option1(uav, task_data, worker_data, charge_data)
        # 计算续航的预期收益
        utility_charge = estimate_tasks_option2(uav, charge_data, car_data)

        if utility_task >= utility_charge:
            uav_task_list.append(index)
        else:
            uav_charge_list.append(index)

    # 分别获取任务匹配和续航匹配的无人机数据
    uav_task_df = uav_online.loc[uav_task_list].copy()
    uav_charge_df = uav_online.loc[uav_charge_list].copy()

    print(f"已将 {len(uav_task_df)} 架 UAV 分配到任务匹配")
    print(f"已将 {len(uav_charge_df)} 架 UAV 分配到续航匹配")

    # 根据需要时间划分无人机的可用性
    uav_task_available = uav_task_df[uav_task_df['time_needed'] == 0].copy()
    uav_task_unavailable = uav_task_df[uav_task_df['time_needed'] > 0].copy()

    uav_charge_available = uav_charge_df[uav_charge_df['time_needed'] == 0].copy()
    uav_charge_unavailable = uav_charge_df[uav_charge_df['time_needed'] > 0].copy()

    print(f"任务匹配中可用的 UAV 数量: {len(uav_task_available)}")
    print(f"任务匹配中不可用的 UAV 数量: {len(uav_task_unavailable)}")
    print(f"续航匹配中可用的 UAV 数量: {len(uav_charge_available)}")
    print(f"续航匹配中不可用的 UAV 数量: {len(uav_charge_unavailable)}")

    return uav_task_available, uav_task_unavailable, uav_charge_available, uav_charge_unavailable


def estimate_tasks_option1(uav, task_data, worker_data, charge_data=None):
    """
    估算无人机继续执行任务的预期收益。

    参数:
        uav (Series): 单个无人机的数据。
        task_data (DataFrame): 任务数据。
        worker_data (DataFrame): 工人数据。

    返回:
        float: 任务的预期收益。
    """
    uPow = uav['uPow']
    speed = uav['uavRge']
    uav_pos = np.array([uav['x'], uav['y']])
    Fullpower = uav['Fullpower']
    time_left = uav['time_left']
    uav_online_time = uav['U_downtime'] - uav['U_uptime']

    if Fullpower <= 0 or uav_online_time <= 0:
        return 0

    # 已完成任务不能参与式(6)-(12)的期望收益估计。
    if 'status' in task_data.columns:
        task_data = task_data[task_data['status'] == 0]
    if task_data.empty or worker_data.empty or charge_data is None or charge_data.empty:
        return 0

    task_positions = task_data[['x', 'y']].values
    distances = np.linalg.norm(task_positions - uav_pos, axis=1)
    tasks_in_range = distances <= RADIUS

    if not np.any(tasks_in_range):
        return 0

    in_range_task_indices = np.flatnonzero(tasks_in_range)
    nearest_task_idx = int(in_range_task_indices[np.argmin(distances[in_range_task_indices])])
    min_distance = distances[nearest_task_idx]
    if speed == 0:
        return 0

    # 计算无人机移动到最近任务的耗电和时间
    delta_pow_T = min_distance  # ΔuPowT
    t_ut = min_distance / speed  # ΔuTimeT

    # 过滤可用的工人
    available_workers = worker_data[worker_data['time_needed'] == 0]
    if available_workers.empty:
        return 0
    worker_positions = available_workers[['x', 'y']].values
    worker_distances = np.linalg.norm(worker_positions - task_positions[nearest_task_idx], axis=1)
    workers_in_range = worker_distances <= RADIUS

    if not np.any(workers_in_range):
        return 0

    in_range_worker_indices = np.flatnonzero(workers_in_range)
    nearest_worker_idx = int(in_range_worker_indices[np.argmin(worker_distances[in_range_worker_indices])])
    min_worker_distance = worker_distances[nearest_worker_idx]

    # 任务点最近的工人移动到任务点所需时间计算
    worker_speed = available_workers.iloc[nearest_worker_idx]['workerRge']
    if worker_speed <= 0:
        return 0
    t_wt = min_worker_distance / worker_speed  # ΔwTimeT

    # 计算任务完成时间
    T_costPow = task_data.iloc[nearest_task_idx]['T_costPow']

    # 论文约束(4)：到达任务、完成任务后还必须能到最近充电点。
    charge_positions = charge_data[['x', 'y']].values
    return_distance = np.min(
        np.linalg.norm(charge_positions - task_positions[nearest_task_idx], axis=1)
    )
    if min_distance + T_costPow + return_distance > uPow:
        return 0

    time_task = max(t_ut, t_wt) + T_costPow / speed  # ΔtaskTime = max(ΔuTimeT , ΔwTimeT) + T_costPow / uRge
    T_left_prime = time_left - INTERVAL - time_task  # uLeftT = U_downtime - SysTime - ΔtaskTime

    if T_left_prime < 0:
        return 0

    # 计算剩余续航的减少量占满电电量的比例
    uPowSumT_ratio = (delta_pow_T + T_costPow) / Fullpower  # ΔuPowSumT = ΔuPowT + T_costPow
    # 计算剩余在线时间占整体在线时间的比例
    uLeftT_ratio = T_left_prime / uav_online_time

    # 计算无人机选择执行任务的预期奖励
    R_task = 1 - uLeftT_ratio * uPowSumT_ratio

    return R_task


def estimate_tasks_option2(uav, charge_data, car_data):
    """
    估算无人机进行续航的预期收益。

    参数:
        uav (Series): 单个无人机的数据。
        charge_data (DataFrame): 充电站数据。
        car_data (DataFrame): 汽车数据。

    返回:
        float: 续航的预期收益。
    """
    uPow = uav['uPow']
    speed = uav['uavRge']
    uav_pos = np.array([uav['x'], uav['y']])
    Fullpower = uav['Fullpower']
    time_left = uav['time_left']
    uav_online_time = uav['U_downtime'] - uav['U_uptime']

    if Fullpower <= 0 or uav_online_time <= 0 or charge_data.empty or car_data.empty:
        return 0

    charge_positions = charge_data[['x', 'y']].values
    distances_to_charge = np.linalg.norm(charge_positions - uav_pos, axis=1)

    # 式(3)及第4.1节 Step 1：充电点须在通信范围内且当前电量可达。
    charges_in_range = (distances_to_charge <= RADIUS) & (distances_to_charge <= uPow)
    if not np.any(charges_in_range):
        return 0

    in_range_charge_indices = np.flatnonzero(charges_in_range)
    nearest_charge_idx = int(
        in_range_charge_indices[np.argmin(distances_to_charge[in_range_charge_indices])]
    )
    min_distance_charge = distances_to_charge[nearest_charge_idx]
    if speed == 0:
        return 0

    # 计算无人机移动到最近续航点的耗电和时间
    delta_pow_C = min_distance_charge  # ΔuPowC
    t_uch = min_distance_charge / speed  # ΔuTimeC

    # 过滤可用的汽车
    available_cars = car_data[car_data['time_needed'] == 0]
    if available_cars.empty:
        return 0
    car_positions = available_cars[['x', 'y']].values
    car_distances = np.linalg.norm(car_positions - charge_positions[nearest_charge_idx], axis=1)
    cars_in_range = car_distances <= RADIUS

    if not np.any(cars_in_range):
        return 0

    in_range_car_indices = np.flatnonzero(cars_in_range)
    nearest_car_idx = int(in_range_car_indices[np.argmin(car_distances[in_range_car_indices])])
    min_car_distance = car_distances[nearest_car_idx]

    # 续航点最近的汽车移动到续航点所需时间计算
    car_speed = available_cars.iloc[nearest_car_idx]['carRge']
    if car_speed <= 0:
        return 0
    t_cch = min_car_distance / car_speed  # ΔvTimeC

    # 计算充电完成时间
    C_chargePow = available_cars.iloc[nearest_car_idx]['C_chargePow']
    if C_chargePow == 0:
        return 0

    time_charge = max(t_uch, t_cch) + (Fullpower - uPow + min_distance_charge) / C_chargePow  # ΔchargeTime
    T_left_prime = time_left - INTERVAL - time_charge  # uLeftC = U_downtime - SysTime - ΔchargeTime

    if T_left_prime < 0:
        return 0

    # 计算无人机续航增加量所占比例
    uPowSumC_ratio = (Fullpower - uPow) / Fullpower  # ΔuPowSumC = Fullpower - uPow
    # 计算剩余在线时间占整体在线时间的比例
    uLeftC_ratio = T_left_prime / uav_online_time

    # 计算无人机选择充电续航的预期收益
    R_charge = uLeftC_ratio * uPowSumC_ratio

    return R_charge

def split_agents_by_time(agent_data, current_time, uptime_col, downtime_col):
    """
    根据智能体的上线和下线时间及需要时间，划分为可用和不可用的智能体。

    参数:
        agent_data (DataFrame): 智能体数据。
        current_time (int): 当前时间。
        uptime_col (str): 上线时间列名。
        downtime_col (str): 下线时间列名。

    返回:
        Tuple[DataFrame, DataFrame]: 可用和不可用的智能体数据。
    """
    available = agent_data[
        (agent_data[uptime_col] <= current_time) &
        (agent_data[downtime_col] >= current_time) &
        (agent_data['time_needed'] == 0)
        ].copy()
    unavailable = agent_data[
        (agent_data[uptime_col] <= current_time) &
        (agent_data[downtime_col] >= current_time) &
        (agent_data['time_needed'] > 0)
        ].copy()

    print(f"已将 {len(available)} 个可用的智能体分配到匹配")
    print(f"已将 {len(unavailable)} 个不可用的智能体排除在匹配之外")

    return available, unavailable

def compute_task_reward(agent_idx, all_agents, all_targets, current_matching, matching_other, role):
    """计算工人和被划分到执行任务的无人机的收益"""
    agent_pos = all_agents[agent_idx]
    reward = 0

    # 遍历所有目标点
    for target_idx, target_pos in enumerate(all_targets):
        if distance(agent_pos, target_pos) > RADIUS:
            continue  # 不在通信范围内

        # 检查当前匹配中是否有智能体匹配到该目标点
        primary_matched = any(t == target_idx for t in current_matching.values() if t is not None)

        # 检查其他匹配中是否有智能体匹配到该目标点
        other_matched = any(
            t == target_idx for t in matching_other.values() if t is not None) if matching_other else False

        # 双重匹配则获得收益
        if primary_matched and other_matched:
            reward += 1

    return reward

# 基于续航点上匹配的无人机的具体电量恢复量进行计算
def compute_charge_reward(agent_idx, all_agents, all_targets, current_matching, matching_other, role):
    """计算汽车/无人机的充电匹配收益，支持多无人机在同一充电点
    该函数细化到匹配到续航点的无人机的电量恢复量，即（满电电量 - 当前电量）的和。
    如果在通信范围内的续航点有汽车匹配，则对于每个匹配到该续航点的无人机，收益增加其电量恢复量。
    """
    global UAV_charge_info
    agent_pos = all_agents[agent_idx]
    reward = 0

    # 遍历所有目标点
    for target_idx, target_pos in enumerate(all_targets):
        if distance(agent_pos, target_pos) > RADIUS:
            continue  # 不在通信范围内

        # 判断该续航点是否被某个汽车匹配
        num_others = sum(1 for t in matching_other.values() if t == target_idx)
        if num_others > 0:
            # 根据角色判断使用哪个匹配字典获取无人机匹配信息
            if role == 'uav':
                uav_matching = current_matching
            else:
                uav_matching = matching_other
            # 累加所有与该续航点匹配的无人机的电量恢复量
            for primary_idx, matched_target in uav_matching.items():
                if matched_target == target_idx:
                    if UAV_charge_info is not None and 0 <= primary_idx < len(UAV_charge_info):
                        # matching 中的 primary_idx 是位置索引，不能用原 DataFrame 标签索引。
                        full_power = UAV_charge_info.iloc[primary_idx]['Fullpower']
                        current_power = UAV_charge_info.iloc[primary_idx]['uPow']
                        recovery_amount = full_power - current_power
                        reward += recovery_amount
    return reward


def reward_based_update_local(agent_idx, all_agents, all_targets, current_matching, agent_speeds, matching_other=None,
                              role='agent', reward_func=compute_task_reward, uPows=None, valid_targets=None):
    """基于直接收益的匹配更新（带Softmax距离概率）"""
    agent_pos = all_agents[agent_idx]
    current_reward = reward_func(
        agent_idx, all_agents, all_targets, current_matching, matching_other, role
    )

    if valid_targets is None:
        valid_targets = [
            target_idx for target_idx, target_pos in enumerate(all_targets)
            if distance(agent_pos, target_pos) <= RADIUS
        ]

    # Algorithm 2 的“Resample via the softmax step above”：从全部可行行为点
    # 按式(20)-(21)抽样；仅当抽样行为严格提高收益时才切换。
    selected_target = softmax_select_target(agent_pos, all_targets, valid_targets)
    if selected_target is not None:
        temp_matching = current_matching.copy()
        temp_matching[agent_idx] = selected_target
        new_reward = reward_func(
            agent_idx, all_agents, all_targets, temp_matching, matching_other, role
        )
        if new_reward > current_reward:
            current_matching[agent_idx] = selected_target

    return current_matching.get(agent_idx, None)


def optimize_matching_distributed_async_local(all_agents, all_targets, agent_speeds, current_matching,
                                              max_iterations=1000, matching_other=None, role='agent',
                                              uPows=None, T_costPow=0, C_ChargePow=0,
                                              reward_func=compute_task_reward,
                                              valid_targets_per_agent=None):
    """
    分布式优化匹配（强制满足纳什均衡条件）
    """
    num_agents = len(all_agents)
    num_targets = len(all_targets)

    if valid_targets_per_agent is None:
        valid_targets_per_agent = build_valid_targets(all_agents, all_targets)

    # 仅初始化尚无有效行为的智能体。交替优化时必须保留上一轮行为，
    # 否则局部 Nash 过程会在每轮被重新随机化。
    for i in range(num_agents):
        valid_targets = valid_targets_per_agent.get(i, [])
        current_target = current_matching.get(i)
        if current_target not in valid_targets:
            current_matching[i] = softmax_select_target(
                all_agents[i], all_targets, valid_targets
            )

    matching_history = [current_matching.copy()]
    active_agents = set(range(num_agents))

    iteration = 0
    while iteration < max_iterations and len(active_agents) > 0:
        # Appendix A 描述的是异步 best-response；按随机顺序逐个更新，
        # 避免多个线程同时写 current_matching 所造成的非论文博弈状态。
        changes = 0
        update_order = list(active_agents)
        random.shuffle(update_order)
        for i in update_order:
            old_target = current_matching.get(i)
            new_target = reward_based_update_local(
                i,
                all_agents,
                all_targets,
                current_matching,
                agent_speeds,
                matching_other=matching_other,
                role=role,
                reward_func=reward_func,
                uPows=uPows,
                valid_targets=valid_targets_per_agent.get(i, [])
            )
            if old_target != new_target:
                changes += 1

        matching_history.append(current_matching.copy())

        # 步骤2：纳什均衡检查
        Si, ASi = check_nash_equilibrium(
            all_agents, all_targets, current_matching, matching_other, role,
            reward_func, valid_targets_per_agent
        )

        # 更新活跃智能体集合
        new_active = set()
        for i in range(num_agents):
            if not ASi[i]:
                neighbors = [
                    j for j in range(num_agents)
                    if j != i and distance(all_agents[i], all_agents[j]) <= RADIUS
                ]
                new_active.add(i)
                new_active.update(neighbors)
        active_agents = new_active

        if all(ASi):
            break

        iteration += 1

    return matching_history, current_matching


def check_nash_equilibrium(all_agents, all_targets, current_matching, matching_other, role, reward_func,
                           valid_targets_per_agent=None):
    """纳什均衡检查（返回Si和ASi数组）"""
    num_agents = len(all_agents)
    Si = np.zeros(num_agents, dtype=bool)
    ASi = np.zeros(num_agents, dtype=bool)

    # 计算每个智能体的Si值
    for i in range(num_agents):
        current_reward = reward_func(i, all_agents, all_targets, current_matching, matching_other, role)
        max_reward = current_reward

        # 只检查满足通信和功能约束的可行单边偏移。
        if valid_targets_per_agent is None:
            valid_targets = [
                target_idx for target_idx, target_pos in enumerate(all_targets)
                if distance(all_agents[i], target_pos) <= RADIUS
            ]
        else:
            valid_targets = valid_targets_per_agent.get(i, [])

        for target_idx in valid_targets:
            if target_idx == current_matching.get(i):
                continue
            temp_matching = current_matching.copy()
            temp_matching[i] = target_idx
            new_reward = reward_func(i, all_agents, all_targets, temp_matching, matching_other, role)
            if new_reward > max_reward:
                max_reward = new_reward

        Si[i] = (max_reward <= current_reward)

    # 计算ASi值（邻域内所有智能体满足Si）
    for i in range(num_agents):
        neighbors = [
            j for j in range(num_agents)
            if j != i and distance(all_agents[i], all_agents[j]) <= RADIUS
        ]
        if len(neighbors) == 0:
            ASi[i] = Si[i]  # 无邻居时只考虑自身
        else:
            ASi[i] = all(Si[neighbors]) and Si[i]  # 自身和邻居都满足

    return Si, ASi


def post_process_matching(
    final_matching_primary,
    final_matching_other,
    all_primaries,
    all_others,
    all_targets,
    primary_speeds,
    other_speeds,
    target_status,
    role_primary='agent',
    role_other='other',
    primary_reward_func=compute_task_reward,
    other_reward_func=compute_charge_reward,
    primary_uPows=None,
    primary_required_powers=None
):
    """
    后处理匹配结果，基于收益最大化避免冲突选择，并下放至次优解

    参数:
        final_matching_primary (dict): 主匹配结果（如 UAV 任务匹配）
        final_matching_other (dict): 其他匹配结果（如 Worker 匹配）
        all_primaries (ndarray): 主智能体位置数组
        all_others (ndarray): 其他智能体位置数组
        all_targets (ndarray): 所有目标位置数组
        primary_speeds (array-like): 主智能体速度
        other_speeds (array-like): 其他智能体速度
        target_status (array-like): 目标状态（0=未完成）
        role_primary (str): 主智能体角色（如 'uav_task'）
        role_other (str): 其他智能体角色（如 'worker'）

    返回:
        Tuple[dict, dict]: 处理后的主匹配和其他匹配结果
    """

    valid_targets_per_primary = build_valid_targets(
        all_primaries,
        all_targets,
        uPows=primary_uPows,
        required_powers=primary_required_powers
    )
    for primary_idx, valid_targets in valid_targets_per_primary.items():
        valid_targets_per_primary[primary_idx] = [
            target_idx for target_idx in valid_targets
            if target_status[target_idx] == 0
        ]

    # 构建目标到主智能体的映射
    target_to_primaries = defaultdict(list)
    for primary_idx, target_idx in final_matching_primary.items():
        if target_idx in valid_targets_per_primary.get(primary_idx, []):
            target_to_primaries[target_idx].append(primary_idx)
        else:
            final_matching_primary[primary_idx] = None

    # 构建目标到其他智能体的映射
    target_to_others = defaultdict(list)
    for other_idx, target_idx in final_matching_other.items():
        if target_idx is not None and target_status[target_idx] == 0:
            target_to_others[target_idx].append(other_idx)
        else:
            final_matching_other[other_idx] = None

    # 任务点保持一 UAV 对一任务；充电点按论文修订后的 FCFS 规则允许
    # 多架 UAV 排队，因此不能在这里把它们错误地裁成一架。
    occupied_primary_targets = set(target_to_primaries.keys())
    if role_other != 'car':
        for target_idx, primary_indices in list(target_to_primaries.items()):
            if len(primary_indices) <= 1:
                continue

            # 计算当前所有主智能体在此目标的收益
            current_rewards = []
            valid_primaries = []

            for primary_idx in primary_indices:
                temp_matching = final_matching_primary.copy()
                temp_matching[primary_idx] = target_idx
                reward = primary_reward_func(
                    primary_idx,
                    all_primaries,
                    all_targets,
                    temp_matching,
                    final_matching_other,
                    role_primary
                )
                current_rewards.append(reward)
                valid_primaries.append(primary_idx)

            # 如果没有有效的主体，继续下一个目标
            if not valid_primaries:
                continue

            # 找出收益最高的主体
            max_reward = max(current_rewards)
            best_primary_idx = valid_primaries[current_rewards.index(max_reward)]

            # 为其他主体寻找替代目标（使用预计算的有效目标）
            for primary_idx in valid_primaries:
                if primary_idx != best_primary_idx:
                    best_alternative = None
                    best_alt_reward = -1

                    # 只遍历预先计算的有效目标
                    for alt_target_idx in valid_targets_per_primary.get(primary_idx, []):
                        if alt_target_idx == target_idx:
                            continue
                        if target_status[alt_target_idx] != 0:
                            continue
                        if alt_target_idx in occupied_primary_targets:
                            continue

                        # 创建临时匹配计算收益
                        temp_matching = final_matching_primary.copy()
                        temp_matching[primary_idx] = alt_target_idx
                        reward = primary_reward_func(
                            primary_idx,
                            all_primaries,
                            all_targets,
                            temp_matching,
                            final_matching_other,
                            role_primary
                        )
                        if reward > best_alt_reward:
                            best_alt_reward = reward
                            best_alternative = alt_target_idx
                    # 更新匹配
                    if best_alternative is not None:
                        final_matching_primary[primary_idx] = best_alternative
                        target_to_primaries[best_alternative].append(primary_idx)
                        occupied_primary_targets.add(best_alternative)
                    else:
                        final_matching_primary[primary_idx] = None

    # ---------------------------- 处理其他匹配冲突 ----------------------------
    occupied_other_targets = set(target_to_others.keys())
    for target_idx, other_indices in list(target_to_others.items()):
        if len(other_indices) > 1:
            # 计算当前所有其他智能体在此目标的收益
            current_rewards = []
            for other_idx in other_indices:
                temp_matching = final_matching_other.copy()
                temp_matching[other_idx] = target_idx
                reward = other_reward_func(
                    other_idx,
                    all_others,
                    all_targets,
                    temp_matching,
                    final_matching_primary,
                    role_other
                )
                current_rewards.append(reward)

            # 保留收益最高的智能体
            max_reward = max(current_rewards)
            best_other_idx = other_indices[current_rewards.index(max_reward)]

            for other_idx in other_indices:
                if other_idx != best_other_idx:
                    best_alternative = None
                    best_alt_reward = -1
                    # 搜索备选目标
                    for alt_target_idx in range(len(all_targets)):
                        if alt_target_idx == target_idx:
                            continue
                        if target_status[alt_target_idx] != 0:
                            continue
                        if distance(all_others[other_idx], all_targets[alt_target_idx]) > RADIUS:
                            continue
                        if alt_target_idx in occupied_other_targets:
                            continue
                        # 计算备选收益
                        temp_matching = final_matching_other.copy()
                        temp_matching[other_idx] = alt_target_idx
                        reward = other_reward_func(
                            other_idx,
                            all_others,
                            all_targets,
                            temp_matching,
                            final_matching_primary,
                            role_other
                        )
                        if reward > best_alt_reward:
                            best_alt_reward = reward
                            best_alternative = alt_target_idx
                    # 更新匹配
                    if best_alternative is not None:
                        final_matching_other[other_idx] = best_alternative
                        target_to_others[best_alternative].append(other_idx)
                        occupied_other_targets.add(best_alternative)
                    else:
                        final_matching_other[other_idx] = None

    for target_idx in range(len(all_targets)):
        if target_status[target_idx] != 0:
            if target_idx in target_to_primaries:
                for primary_idx in target_to_primaries[target_idx]:
                    final_matching_primary[primary_idx] = None
            if target_idx in target_to_others:
                for other_idx in target_to_others[target_idx]:
                    final_matching_other[other_idx] = None

    return final_matching_primary, final_matching_other


def get_final_triple_matching(final_matching_primary, final_matching_other, all_primaries, all_others, all_targets,
                              primary_speeds, other_speeds, primary_ids, other_ids, target_ids, target_status,
                              role_primary='agent', role_other='other', primary_uPows=None,
                              primary_fullpowers=None, other_charge_powers=None):
    """
    生成最终的三元匹配结果。

    参数:
        final_matching_primary (dict): 主匹配结果。
        final_matching_other (dict): 其他匹配结果。
        all_primaries (ndarray): 所有主智能体的位置数组。
        all_others (ndarray): 所有其他智能体的位置数组。
        all_targets (ndarray): 所有目标的位置数组。
        primary_speeds (array-like): 主智能体的速度。
        other_speeds (array-like): 其他智能体的速度。
        primary_ids (array-like): 主智能体的ID。
        other_ids (array-like): 其他智能体的ID。
        target_ids (array-like): 目标的ID。
        target_status (array-like): 目标的状态。
        role_primary (str): 主智能体角色。
        role_other (str): 其他智能体角色。

    返回:
        Tuple[dict, dict, dict]: 最终三元匹配，主匹配，其他匹配。
    """
    final_triple_matching = {}
    is_charging = role_other == 'car'

    target_to_other = {
        target_idx: other_idx
        for other_idx, target_idx in final_matching_other.items()
        if target_idx is not None
    }

    if not is_charging:
        for primary_idx, target_idx in final_matching_primary.items():
            if target_idx is None or target_idx not in target_to_other or target_status[target_idx] != 0:
                continue

            other_idx = target_to_other[target_idx]
            primary_pos = all_primaries[primary_idx]
            other_pos = all_others[other_idx]
            target_pos = all_targets[target_idx]
            primary_speed = primary_speeds[primary_idx]
            other_speed = other_speeds[other_idx]
            primary_time = distance(primary_pos, target_pos) / primary_speed if primary_speed > 0 else float('inf')
            other_time = distance(other_pos, target_pos) / other_speed if other_speed > 0 else float('inf')

            final_triple_matching[target_idx] = {
                'target_idx': target_idx,
                f'{role_primary}_idx': primary_idx,
                f'{role_other}_idx': other_idx,
                'consumed_time': max(primary_time, other_time),
                f'{role_primary}_time': primary_time,
                f'{role_other}_time': other_time
            }
        return final_triple_matching

    # 约束(4)修订说明：同一车辆对同一充电点的多架 UAV 按到达时间 FCFS，
    # 逐架充电，绝不能把服务时间写成 0 或当作同时完成。
    charge_point_assignments = defaultdict(list)
    for primary_idx, target_idx in final_matching_primary.items():
        if target_idx is not None and target_idx in target_to_other and target_status[target_idx] == 0:
            charge_point_assignments[target_idx].append(primary_idx)

    for target_idx, uav_indices in charge_point_assignments.items():
        other_idx = target_to_other[target_idx]
        target_pos = all_targets[target_idx]
        other_speed = other_speeds[other_idx]
        other_time = (
            distance(all_others[other_idx], target_pos) / other_speed
            if other_speed > 0 else float('inf')
        )

        arrivals = []
        for primary_idx in uav_indices:
            primary_speed = primary_speeds[primary_idx]
            primary_time = (
                distance(all_primaries[primary_idx], target_pos) / primary_speed
                if primary_speed > 0 else float('inf')
            )
            arrivals.append((primary_time, primary_idx))
        arrivals.sort(key=lambda item: (item[0], item[1]))

        vehicle_available_time = other_time
        for queue_position, (primary_time, primary_idx) in enumerate(arrivals, start=1):
            travel_energy = distance(all_primaries[primary_idx], target_pos)
            if (primary_uPows is not None and primary_fullpowers is not None
                    and other_charge_powers is not None):
                arrival_power = primary_uPows[primary_idx] - travel_energy
                charge_power = other_charge_powers[other_idx]
                charge_time = (
                    (primary_fullpowers[primary_idx] - arrival_power) / charge_power
                    if charge_power > 0 else float('inf')
                )
            else:
                arrival_power = None
                charge_time = 0

            service_start = max(primary_time, vehicle_available_time)
            completion_time = service_start + charge_time
            vehicle_available_time = completion_time

            # 充电匹配可能同一 target 对应多架 UAV，使用复合键避免覆盖。
            match_key = (target_idx, primary_idx)
            final_triple_matching[match_key] = {
                'target_idx': target_idx,
                f'{role_primary}_idx': primary_idx,
                f'{role_other}_idx': other_idx,
                'queue_position': queue_position,
                'arrival_power': arrival_power,
                'charge_time': charge_time,
                'consumed_time': completion_time,
                f'{role_primary}_time': primary_time,
                f'{role_other}_time': other_time
            }

    return final_triple_matching


def optimize_matching(primary_df, other_df, target_df, role_primary='agent', role_other='other',
                     max_iterations=1000, current_time=0, num_alternations=2,
                     return_charge_positions=None):
    """
    封装的匹配优化函数
    """
    all_primaries = primary_df[['x', 'y']].values
    primary_speeds = primary_df[f'{role_primary}Rge'].values
    primary_ids = primary_df['ID'].values
    primary_uPows = primary_df['uPow'].values if 'uPow' in primary_df.columns else None  # 获取电量数据
    primary_fullpowers = (
        primary_df['Fullpower'].values if 'Fullpower' in primary_df.columns else None
    )

    all_others = other_df[['x', 'y']].values
    other_speeds = other_df[f'{role_other}Rge'].values
    other_ids = other_df['ID'].values
    other_charge_powers = (
        other_df['C_chargePow'].values if 'C_chargePow' in other_df.columns else None
    )

    all_targets = target_df[['x', 'y']].values
    target_ids = target_df['original_index'].values
    target_status = target_df['status'].values

    # 将论文式(3)/(4)的目标相关电量需求显式带入每次行为选择。
    primary_required_powers = None
    if primary_uPows is not None:
        move_distances = np.linalg.norm(
            all_primaries[:, np.newaxis, :] - all_targets[np.newaxis, :, :], axis=2
        )
        if role_other == 'worker':
            task_costs = target_df['T_costPow'].to_numpy(dtype=float)
            if return_charge_positions is None or len(return_charge_positions) == 0:
                return_distances = np.full(len(all_targets), np.inf)
            else:
                return_charge_positions = np.asarray(return_charge_positions)
                return_distances = np.min(
                    np.linalg.norm(
                        all_targets[:, np.newaxis, :] - return_charge_positions[np.newaxis, :, :],
                        axis=2
                    ),
                    axis=1
                )
            primary_required_powers = (
                move_distances + task_costs[np.newaxis, :] + return_distances[np.newaxis, :]
            )
        elif role_other == 'car':
            primary_required_powers = move_distances

    valid_targets_primary = build_valid_targets(
        all_primaries, all_targets, primary_uPows, primary_required_powers
    )
    valid_targets_other = build_valid_targets(all_others, all_targets)
    for valid_targets_per_agent in (valid_targets_primary, valid_targets_other):
        for agent_idx, valid_targets in valid_targets_per_agent.items():
            valid_targets_per_agent[agent_idx] = [
                target_idx for target_idx in valid_targets
                if target_status[target_idx] == 0
            ]

    print(f"-------------Starting {role_primary.capitalize()} Optimization-------------")
    print(f"Primary Agents: {len(primary_df)}, Other Agents: {len(other_df)}, Targets: {len(target_df)}")

    # 初始化匹配字典
    final_matching_primary = {i: None for i in range(len(primary_df))}
    final_matching_other = {i: None for i in range(len(other_df))}

    # 根据角色确定奖励函数
    if role_other == 'worker':
        primary_reward_func = compute_task_reward
        other_reward_func = compute_task_reward
    elif role_other == 'car':
        primary_reward_func = compute_charge_reward
        other_reward_func = compute_charge_reward
    else:
        primary_reward_func = compute_task_reward
        other_reward_func = compute_task_reward

    # 保留原代码的两轮异构交替；每一轮内部仍按 Algorithm 2 的局部
    # Nash 条件迭代，避免额外的外层全局反复显著放大决策时间。
    joint_equilibrium = False
    for alt_round in range(num_alternations):
        # 优化主匹配（传递 uPows）
        _, final_matching_primary = optimize_matching_distributed_async_local(
            all_primaries, all_targets, primary_speeds,
            current_matching=final_matching_primary.copy(),
            max_iterations=max_iterations,
            matching_other=final_matching_other,
            role=role_primary,
            reward_func=primary_reward_func,
            uPows=primary_uPows,
            valid_targets_per_agent=valid_targets_primary
        )

        # 优化其他匹配
        _, final_matching_other = optimize_matching_distributed_async_local(
            all_others, all_targets, other_speeds,
            current_matching=final_matching_other.copy(),
            max_iterations=max_iterations,
            matching_other=final_matching_primary,
            role=role_other,
            reward_func=other_reward_func,
            valid_targets_per_agent=valid_targets_other
        )

        # 冲突处理会改变行为，必须在 Nash 判定之前执行。
        final_matching_primary, final_matching_other = post_process_matching(
            final_matching_primary, final_matching_other,
            all_primaries, all_others, all_targets,
            primary_speeds, other_speeds,
            target_status,
            role_primary=role_primary,
            role_other=role_other,
            primary_reward_func=primary_reward_func,
            other_reward_func=other_reward_func,
            primary_uPows=primary_uPows,
            primary_required_powers=primary_required_powers
        )

        primary_Si, _ = check_nash_equilibrium(
            all_primaries, all_targets, final_matching_primary,
            final_matching_other, role_primary, primary_reward_func,
            valid_targets_primary
        )
        other_Si, _ = check_nash_equilibrium(
            all_others, all_targets, final_matching_other,
            final_matching_primary, role_other, other_reward_func,
            valid_targets_other
        )
        if np.all(primary_Si) and np.all(other_Si):
            joint_equilibrium = True
            break

    if not joint_equilibrium and (len(all_primaries) > 0 or len(all_others) > 0):
        print(f"Warning: {role_primary}/{role_other} matching reached the safety iteration limit before joint equilibrium.")

    MATCHING_DIAGNOSTICS.append({
        'agent_count': len(all_primaries) + len(all_others),
        'joint_equilibrium': bool(joint_equilibrium),
    })

    # 生成最终匹配结果
    final_triple_matching = get_final_triple_matching(
        final_matching_primary, final_matching_other,
        all_primaries, all_others, all_targets,
        primary_speeds, other_speeds,
        primary_ids, other_ids, target_ids, target_status,
        role_primary=role_primary, role_other=role_other,
        primary_uPows=primary_uPows,
        primary_fullpowers=primary_fullpowers,
        other_charge_powers=other_charge_powers
    )

    # 打印匹配结果
    print("\nFinal Triple Matching Results:")
    for match_key, info in final_triple_matching.items():
        target_idx = info.get('target_idx', match_key)
        if target_idx is None or target_status[target_idx] != 0:
            continue  # 跳过无效或已完成的目标

        # 获取主智能体和其他智能体的索引
        primary_idx = info[f'{role_primary}_idx']
        other_idx = info[f'{role_other}_idx']

        # 获取位置坐标
        primary_pos = all_primaries[primary_idx]
        other_pos = all_others[other_idx]
        target_pos = all_targets[target_idx]

        # 获取ID和时间
        primary_id = primary_ids[primary_idx]
        other_id = other_ids[other_idx]
        target_id = target_ids[target_idx]
        consumed_time = info['consumed_time']

        # 格式化输出，添加位置信息
        print(
            f"{role_primary.capitalize()} {primary_id} [{primary_pos[0]:}, {primary_pos[1]:}] + "
            f"{role_other.capitalize()} {other_id} [{other_pos[0]:}, {other_pos[1]:}] -> "
            f"Target {target_id} [{target_pos[0]:}, {target_pos[1]:}], Time: {consumed_time:.2f}s"
        )

    return final_triple_matching, final_matching_primary, final_matching_other

def optimize_task(uav_task, worker_available_df, task_map_df, current_time, charge_map_df=None):
    """
    优化任务匹配。

    参数:
        uav_task (DataFrame): 可用的任务 UAV 数据。
        worker_available_df (DataFrame): 可用的工人数据。
        task_map_df (DataFrame): 任务映射数据。
        current_time (int): 当前时间。

    返回:
        Tuple[dict, dict, dict]: 任务匹配结果。
    """
    return optimize_matching(
        primary_df=uav_task,
        other_df=worker_available_df,
        target_df=task_map_df,
        role_primary='uav',
        role_other='worker',
        max_iterations=1000,
        current_time=current_time,
        return_charge_positions=(
            charge_map_df[['x', 'y']].values
            if charge_map_df is not None else None
        )
    )

def optimize_charge(uav_charge, car_available_df, charge_map_df, current_time):
    """
    优化续航匹配。

    参数:
        uav_charge (DataFrame): 可用的续航 UAV 数据。
        car_available_df (DataFrame): 可用的汽车数据。
        charge_map_df (DataFrame): 充电站映射数据。
        current_time (int): 当前时间。

    返回:
        Tuple[dict, dict, dict]: 续航匹配结果。
    """
    global UAV_charge_info
    UAV_charge_info = uav_charge.reset_index(drop=True).copy()
    return optimize_matching(
        primary_df=uav_charge,
        other_df=car_available_df,
        target_df=charge_map_df,
        role_primary='uav',
        role_other='car',
        max_iterations=1000,
        current_time=current_time
    )

REQUIRED_FILES = ('uavMap.csv', 'workerMap.csv', 'carMap.csv', 'taskMap.csv', 'chargeMap.csv')
DECISION_DEFINITION = (
    'Same unit as algorithm.py total_decisions: one complete scheduling decision per '
    'online unlocked UAV/worker/car at each synchronous trigger, including empty actions '
    'and unsuccessful matching attempts. Busy/offline agents are excluded. Initialization, '
    'local best-response iterations, conflict resolution and Nash checks are not counted again.'
)
COMPLETION_DEFINITION = (
    'HoAs-PALN_Correct.py convention: a successful task triple match sets status=1 '
    'immediately; busy duration still includes travel and task execution. '
    'Action deadlines and packet loss retain the source defaults (disabled).'
)
REPORT_METRICS = (
    'completion_rate', 'decision_count', 'uav_decision_count', 'worker_decision_count',
    'car_decision_count', 'sync_round_count', 'successful_task_matches',
    'successful_charge_matches', 'unconverged_solver_call_count', 'final_ne_fraction',
)


def _read_dataset(directory):
    """仅在内存中初始化，绝不改写输入 CSV。"""
    frames = [pd.read_csv(directory / filename) for filename in REQUIRED_FILES]
    uavs, workers, cars, tasks, charges = frames
    for frame in (uavs, workers, cars):
        if frame['ID'].isna().any() or frame['ID'].duplicated().any():
            raise ValueError(f'{directory}: 智能体 ID 必须非空且唯一。')
        frame['time_needed'] = 0.0
        frame[['x', 'y']] = frame[['x', 'y']].astype(float)
    uavs['uPow'] = uavs['uPow'].astype(float)
    tasks['status'] = 0
    # 使用完整任务表的行号，过滤/重排之后仍更新正确的原任务。
    tasks['original_index'] = tasks.index
    charges['original_index'] = charges.index
    charges['status'] = 0
    return uavs, workers, cars, tasks, charges


def _count_round_decisions(uav_task, uav_charge, workers, cars):
    """按智能体计数，而非按轮次、成功匹配数或优化器内部循环计数。"""
    return {
        'uav_decision_count': len(set(uav_task['ID']) | set(uav_charge['ID'])),
        'worker_decision_count': workers['ID'].nunique(),
        'car_decision_count': cars['ID'].nunique(),
    }


def run_one_dataset(directory, interval=5, seed=42, limit_time=180, radius=8):
    """保留 Correct 主循环的状态更新，只将磁盘中间结果改为内存状态。"""
    global INTERVAL, LIMIT_TIME, RADIUS, UAV_charge_info
    INTERVAL, LIMIT_TIME, RADIUS = float(interval), float(limit_time), float(radius)
    if any(not math.isfinite(value) or value <= 0 for value in (INTERVAL, LIMIT_TIME, RADIUS)):
        raise ValueError('interval、limit_time、radius 必须为有限正数。')
    random.seed(seed)
    np.random.seed(seed)
    UAV_charge_info = None
    MATCHING_DIAGNOSTICS.clear()
    started = time.perf_counter()
    uav_data, worker_data, car_data, task_full, charge_map_df = _read_dataset(directory)
    counts = {'uav_decision_count': 0, 'worker_decision_count': 0, 'car_decision_count': 0}
    successful_task_count = successful_charge_count = sync_round_count = 0

    # 保留 Correct 的同步时刻：interval, 2*interval, ...；整除时含 LIMIT_TIME。
    for iteration in range(1, int(LIMIT_TIME / INTERVAL) + 1):
        current_time = iteration * INTERVAL
        sync_round_count += 1
        print(f'\nStarting iteration {iteration} at time {current_time}')
        for frame in (uav_data, worker_data, car_data):
            # 全部扣减到零时也保持浮点列，避免后续写入小数时间触发 dtype 警告。
            frame['time_needed'] = frame['time_needed'].apply(
                lambda value: max(0.0, value - INTERVAL)
            ).astype(float)
        worker_available, _ = split_agents_by_time(
            worker_data, current_time, 'W_uptime', 'W_downtime'
        )
        car_available, _ = split_agents_by_time(
            car_data, current_time, 'C_uptime', 'C_downtime'
        )
        task_map_df = task_full[task_full['status'] == 0].copy().reset_index(drop=True)
        charge_map_df = charge_map_df.copy().reset_index(drop=True)
        charge_map_df['status'] = 0
        uav_task_available, _, uav_charge_available, _ = split_uav_data(
            uav_data, task_map_df, charge_map_df, worker_available, car_available,
            iteration, current_time
        )

        # 一轮每名在线且空闲的智能体只计一次；没有候选目标时的空动作也计入。
        # UAV 的任务/充电选择与后续匹配组成一次完整决策，不重复计数。
        for role, value in _count_round_decisions(
                uav_task_available, uav_charge_available, worker_available, car_available).items():
            counts[role] += int(value)

        primary_ids_task = uav_task_available['ID'].values
        primary_ids_charge = uav_charge_available['ID'].values
        other_ids_worker = worker_available['ID'].values
        other_ids_car = car_available['ID'].values

        # 两个匹配均基于本轮同一份状态。串行调用确保 Windows 下 interval/radius
        # 和随机种子生效，避免子进程重新导入后使用模块默认参数。
        task_triple_matching, _, _ = optimize_task(
            uav_task_available, worker_available, task_map_df, current_time, charge_map_df
        )
        charge_triple_matching, _, _ = optimize_charge(
            uav_charge_available, car_available, charge_map_df, current_time
        )
        task_targets = task_map_df[['x', 'y']].values
        charge_targets = charge_map_df[['x', 'y']].values
        successful_task_matches = {}
        successful_charge_matches = {}

        for match_key, info in task_triple_matching.items():
            target_idx = info.get('target_idx', match_key)
            if target_idx is None:
                continue
            primary_idx = info['uav_idx']
            primary_id = primary_ids_task[primary_idx]
            worker_id = other_ids_worker[info['worker_idx']]
            target_pos = task_targets[target_idx]
            original_pos = uav_task_available.iloc[primary_idx][['x', 'y']].values
            move_distance = distance(original_pos, target_pos)
            task_cost_pow = float(task_map_df.iloc[target_idx]['T_costPow'])
            uav_speed = float(uav_data.loc[uav_data['ID'] == primary_id, 'uavRge'].values[0])
            if uav_speed <= 0:
                continue
            total_task_time = float(info['consumed_time']) + task_cost_pow / uav_speed
            uav_downtime = float(uav_data.loc[uav_data['ID'] == primary_id, 'U_downtime'].values[0])
            worker_downtime = float(
                worker_data.loc[worker_data['ID'] == worker_id, 'W_downtime'].values[0]
            )
            if (ENFORCE_ACTION_DEADLINES and current_time + total_task_time >
                    min(uav_downtime, worker_downtime, LIMIT_TIME)):
                continue
            if ENABLE_PACKET_LOSS:
                failure_prob = random.uniform(*PACKET_LOSS_RANGE)
                if random.random() < failure_prob:
                    continue
            successful_info = info.copy()
            successful_info['total_time'] = total_task_time
            successful_task_matches[match_key] = successful_info
            uav_mask = uav_data['ID'] == primary_id
            uav_data.loc[uav_mask, ['x', 'y']] = target_pos
            uav_data.loc[uav_mask, 'uPow'] -= move_distance + task_cost_pow
            uav_data.loc[uav_mask, 'uPow'] = uav_data.loc[uav_mask, 'uPow'].round(2)
            uav_data.loc[uav_mask, 'time_needed'] = round(total_task_time, 2)

        for match_key, info in charge_triple_matching.items():
            target_idx = info.get('target_idx', match_key)
            if target_idx is None:
                continue
            primary_id = primary_ids_charge[info['uav_idx']]
            car_id = other_ids_car[info['car_idx']]
            # 已包含飞行、等待及 FCFS 充电；不可再次加 charge_time。
            consumed_time = float(info['consumed_time'])
            uav_downtime = float(uav_data.loc[uav_data['ID'] == primary_id, 'U_downtime'].values[0])
            car_downtime = float(car_data.loc[car_data['ID'] == car_id, 'C_downtime'].values[0])
            if (ENFORCE_ACTION_DEADLINES and current_time + consumed_time >
                    min(uav_downtime, car_downtime, LIMIT_TIME)):
                continue
            if ENABLE_PACKET_LOSS:
                failure_prob = random.uniform(*PACKET_LOSS_RANGE)
                if random.random() < failure_prob:
                    continue
            successful_charge_matches[match_key] = info
            uav_mask = uav_data['ID'] == primary_id
            full_power = float(uav_data.loc[uav_mask, 'Fullpower'].values[0])
            uav_data.loc[uav_mask, ['x', 'y']] = charge_targets[target_idx]
            uav_data.loc[uav_mask, 'uPow'] = round(full_power, 2)
            uav_data.loc[uav_mask, 'time_needed'] = round(consumed_time, 2)

        for match_key, info in successful_task_matches.items():
            target_idx = info.get('target_idx', match_key)
            worker_id = other_ids_worker[info['worker_idx']]
            worker_mask = worker_data['ID'] == worker_id
            worker_data.loc[worker_mask, ['x', 'y']] = task_targets[target_idx]
            worker_data.loc[worker_mask, 'time_needed'] = round(float(info['total_time']), 2)
            original_target_idx = int(task_map_df.iloc[target_idx]['original_index'])
            # 沿用 Correct 的完成口径：成功三元匹配即设 status=1。
            task_full.loc[original_target_idx, 'status'] = 1

        for match_key, info in successful_charge_matches.items():
            target_idx = info.get('target_idx', match_key)
            car_id = other_ids_car[info['car_idx']]
            car_mask = car_data['ID'] == car_id
            car_data.loc[car_mask, ['x', 'y']] = charge_targets[target_idx]
            current_car_time = float(car_data.loc[car_mask, 'time_needed'].values[0])
            car_data.loc[car_mask, 'time_needed'] = max(
                current_car_time, round(float(info['consumed_time']), 2)
            )
        successful_task_count += len(successful_task_matches)
        successful_charge_count += len(successful_charge_matches)

    total_tasks = len(task_full)
    completed_tasks = int((task_full['status'] == 1).sum())
    rate = completed_tasks / total_tasks if total_tasks else 0.0
    nonempty_checks = [entry for entry in MATCHING_DIAGNOSTICS if entry['agent_count'] > 0]
    failed_checks = sum(not entry['joint_equilibrium'] for entry in nonempty_checks)
    decision_count = sum(counts.values())
    return {
        'dataset': directory.name, 'interval': INTERVAL, 'seed': int(seed),
        'radius': RADIUS, 'limit_time': LIMIT_TIME,
        'total_tasks': total_tasks, 'completed_tasks': completed_tasks,
        'completion_rate': rate, 'task_completion_rate_percent': rate * 100,
        'decision_count': decision_count, 'scheduling_decision_count': decision_count,
        **counts, 'sync_round_count': sync_round_count,
        'successful_task_matches': successful_task_count,
        'successful_charge_matches': successful_charge_count,
        'nash_checked_solver_calls': len(nonempty_checks),
        'unconverged_solver_call_count': failed_checks,
        'final_ne_fraction': 1 - failed_checks / len(nonempty_checks) if nonempty_checks else 1.0,
        'elapsed_seconds': time.perf_counter() - started,
    }


def _positive_number(value):
    number = float(value)
    if not math.isfinite(number) or number <= 0:
        raise argparse.ArgumentTypeError('请输入有限正数。')
    return number


def _number_list(value, integer=False):
    parts = [part.strip() for part in value.split(',') if part.strip()]
    if not parts:
        raise ValueError('列表不能为空。')
    values = [int(part) if integer else _positive_number(part) for part in parts]
    if integer and any(number < 0 or number >= 2**32 for number in values):
        raise ValueError('seed 必须为 0 到 2**32-1 的整数。')
    return sorted(set(values))


def _select_datasets(root, random_selection, named_selection=None):
    root = root.resolve()
    if named_selection is not None:
        names = list(dict.fromkeys(name.strip() for name in named_selection.split(',') if name.strip()))
        directories = [root / name for name in names]
    else:
        available = {}
        for path in root.glob('Random_*'):
            if path.is_dir() and path.name[7:].isdigit():
                available[int(path.name[7:])] = path
        if random_selection.strip().lower() == 'all':
            numbers = sorted(available)
        else:
            numbers = []
            for part in random_selection.split(','):
                part = part.strip()
                if '-' in part:
                    low, high = (int(number) for number in part.split('-', 1))
                    if low > high:
                        raise ValueError(f'数据集范围必须从小到大：{part}')
                    numbers.extend(range(low, high + 1))
                elif part:
                    numbers.append(int(part))
            numbers = sorted(set(numbers))
        missing = [number for number in numbers if number not in available]
        if missing:
            raise ValueError(f'找不到这些数据集：{missing}')
        directories = [available[number] for number in numbers]
    if not directories:
        raise ValueError(f'未选中数据集，请检查 {root}')
    if any(directory.name == 'ALL' for directory in directories):
        raise ValueError('ALL 为汇总行保留名称，请使用其他数据集目录名。')
    for directory in directories:
        missing = [name for name in REQUIRED_FILES if not (directory / name).is_file()]
        if missing:
            raise ValueError(f'{directory} 缺少：{", ".join(missing)}')
    return directories


def _save_csv(path, rows):
    temporary = path.with_suffix(path.suffix + '.tmp')
    frame = rows if isinstance(rows, pd.DataFrame) else pd.DataFrame(rows)
    frame.to_csv(temporary, index=False, encoding='utf-8-sig')
    temporary.replace(path)


def _save_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(path)


def _best_seed_summary(rows):
    """ALL 先按同一个 seed 对各数据集等权平均，再选完成率最高的 seed。"""
    frame = pd.DataFrame(rows)
    if 'interval' not in frame:
        frame = frame.assign(interval=0.0)
    metrics = [name for name in REPORT_METRICS if name in frame]
    per_seed = frame.groupby(['interval', 'seed'], as_index=False)[metrics].mean()
    scopes = [('ALL', per_seed, frame.dataset.nunique())]
    scopes.extend((dataset, group, 1) for dataset, group in frame.groupby('dataset', sort=True))
    rows = []
    for scope, group, dataset_count in scopes:
        # 完成率并列时取较小种子；不以决策次数或耗时来挑种子。
        selected = group.sort_values(
            ['interval', 'completion_rate', 'seed'], ascending=[True, False, True], kind='stable'
        ).drop_duplicates('interval')
        for _, row in selected.iterrows():
            rows.append({
                'scope': scope, 'interval': row.interval, 'best_seed': int(row.seed),
                'dataset_count': int(dataset_count),
                'tested_seed_count': int(group[group.interval == row.interval].seed.nunique()),
                'task_completion_rate_percent': row.completion_rate * 100,
                **{metric: row[metric] for metric in metrics},
            })
    return pd.DataFrame(rows)


def _nearest_intervals(best, target, tolerance_percent, references=None):
    reference_best = _best_seed_summary(references) if references else None
    result = []
    for scope in ['ALL'] + sorted(value for value in best.scope.unique() if value != 'ALL'):
        group = best[best.scope == scope]
        ref = reference_best[reference_best.scope == scope].iloc[0] if reference_best is not None else None
        scope_target = float(ref.decision_count) if ref is not None else target
        selected = group.assign(gap=(group.decision_count - scope_target).abs()).sort_values(
            ['gap', 'interval'], kind='stable'
        ).iloc[0]
        gap = float(selected.decision_count - scope_target)
        gap_percent = 100 * gap / scope_target if scope_target else None
        within = abs(gap_percent) <= tolerance_percent if scope_target else abs(gap) <= 1e-9
        row = {
            'scope': scope, 'selected_interval': selected.interval,
            'selected_seed': int(selected.best_seed),
            'tested_seed_count': int(selected.tested_seed_count),
            'target_decision_count': scope_target, 'decision_count': selected.decision_count,
            'task_completion_rate_percent': selected.task_completion_rate_percent,
            'decision_gap': gap, 'decision_gap_percent': gap_percent,
            'tolerance_percent': tolerance_percent, 'within_tolerance': bool(within),
            'selection_basis': 'async_best_seed' if ref is not None else 'fixed_target',
            'unconverged_solver_call_count': selected.unconverged_solver_call_count,
            'final_ne_fraction': selected.final_ne_fraction,
        }
        if ref is not None:
            row.update({
                'async_selected_seed': int(ref.best_seed),
                'async_completion_rate_percent': ref.task_completion_rate_percent,
                'sync_minus_async_pp': selected.task_completion_rate_percent - ref.task_completion_rate_percent,
            })
        result.append(row)
    return pd.DataFrame(result)


def _write_reports(rows, references, args):
    best = _best_seed_summary(rows)
    nearest = _nearest_intervals(best, args.target_decisions, args.tolerance_percent, references)
    _save_csv(args.out_dir / 'best_seed_summary.csv', best)
    _save_csv(args.out_dir / 'closest_to_target.csv', nearest)
    if references:
        _save_csv(args.out_dir / 'async_best_seed.csv', _best_seed_summary(references).drop(columns='interval'))
    _save_json(args.out_dir / 'report_config.json', {
        'target_decisions': args.target_decisions, 'tolerance_percent': args.tolerance_percent,
        'seed_summary': 'best',
        'best_seed_rule': 'Maximum completion at each interval; common seed and equal dataset weights for ALL; ties choose smallest seed.',
        'async_seed_rule': 'Independently maximize Async completion over the same tested seeds.',
        'source_runs_sha256': hashlib.sha256((args.out_dir / 'runs.csv').read_bytes()).hexdigest(),
        'reporter_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    })
    table = best[best.scope == 'ALL'][
        ['interval', 'best_seed', 'decision_count', 'task_completion_rate_percent']
    ].rename(columns={
        'interval': 'Interval', 'best_seed': '最高完成率种子',
        'decision_count': '决策次数', 'task_completion_rate_percent': '任务完成率(%)',
    })
    print('\n每个 interval 的最高完成率种子（跨数据集使用同一个种子、等权平均）：')
    print(table.to_string(index=False, float_format=lambda value: f'{value:.2f}'))
    selected = nearest.iloc[0]
    print(f'\n推荐 Interval={selected.selected_interval:g}，seed={int(selected.selected_seed)}：'
          f'决策次数={selected.decision_count:.2f}，目标={selected.target_decision_count:.2f}，'
          f'完成率={selected.task_completion_rate_percent:.2f}%。')
    if not selected.within_tolerance:
        print(f'当前最接近的结果仍超出 ±{args.tolerance_percent:g}% 范围，请补充附近 interval 再比较。')
    if selected.unconverged_solver_call_count > 0:
        print('该结果存在未达到联合 Nash 条件的匹配调用，具体数量保留在结果表中。')
    if references:
        print(f'Async-PALP 最高完成率种子={int(selected.async_selected_seed)}，'
              f'完成率={selected.async_completion_rate_percent:.2f}%，'
              f'HoAs-PALN 差值={selected.sync_minus_async_pp:+.2f} 个百分点。')
    print(f'表格目录：{args.out_dir}')


def _run_async_reference(directory, seed, args):
    from algorithm import scheduler

    sim = scheduler(
        uav_file=str(directory / 'uavMap.csv'), worker_file=str(directory / 'workerMap.csv'),
        vehicle_file=str(directory / 'carMap.csv'), task_file=str(directory / 'taskMap.csv'),
        charge_file=str(directory / 'chargeMap.csv'), radius=args.radius,
        limit_time=args.limit_time, seed=seed, hover_power=args.hover_power,
        activation_scale=args.activation_scale,
    )
    sim.run_event_driven(verbose=args.verbose)
    return {'dataset': directory.name, 'seed': seed, **sim.get_metrics()}


def _source_hashes(directories, with_reference):
    paths = {'HoAs-PALN-1006.py': Path(__file__).resolve()}
    if with_reference:
        paths['algorithm.py'] = Path(__file__).resolve().parent / 'algorithm.py'
    for directory in directories:
        for filename in REQUIRED_FILES:
            paths[f'{directory.name}/{filename}'] = directory / filename
    return {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}


def _validate_checkpoint(rows, references, directories, intervals, seeds, with_reference):
    expected = {(directory.name, interval, seed)
                for directory in directories for interval in intervals for seed in seeds}
    recorded = [(row['dataset'], float(row['interval']), int(row['seed'])) for row in rows]
    if len(recorded) != len(set(recorded)) or not set(recorded).issubset(expected):
        raise ValueError('runs.csv 含重复或不属于本次计划的记录。')
    expected_reference = {(directory.name, seed) for directory in directories for seed in seeds}
    recorded_reference = [(row['dataset'], int(row['seed'])) for row in references]
    if (len(recorded_reference) != len(set(recorded_reference))
            or not set(recorded_reference).issubset(expected_reference)
            or (recorded_reference and not with_reference)):
        raise ValueError('async_reference.csv 含重复或不属于本次计划的记录。')
    for row in rows:
        role_sum = sum(row[role] for role in ('uav_decision_count', 'worker_decision_count', 'car_decision_count'))
        if row['decision_count'] != role_sum or row['decision_count'] != row['scheduling_decision_count']:
            raise ValueError('保存的决策次数不等于三类智能体计数之和。')


def _resume_protocol_matches(previous, current, output_dir):
    """只允许清单中记录的精确类型修复前后版本衔接，其他检查仍严格相等。"""
    if previous == current:
        return True
    try:
        compatibility = json.loads(
            (output_dir / 'source_compatibility.json').read_text(encoding='utf-8')
        )
    except (OSError, ValueError):
        return False
    if not isinstance(compatibility, dict) or compatibility.get('fix') != 'time_needed_float_dtype':
        return False
    source_name = 'HoAs-PALN-1006.py'
    if (previous.get('sha256', {}).get(source_name) != compatibility.get('before_sha256')
            or current['sha256'][source_name] != compatibility.get('after_sha256')):
        return False
    expected_previous = {
        **current,
        'sha256': {**current['sha256'], source_name: compatibility['before_sha256']},
    }
    return previous == expected_previous


def main():
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description='HoAs-PALN_Correct 的多 interval、最高完成率种子实验。')
    parser.add_argument('--dataset-root', type=Path, default=base / 'data' / 'HighpowerDatasets')
    datasets = parser.add_mutually_exclusive_group()
    datasets.add_argument('--random', default=DEFAULT_RANDOM, help='all、1、1-10 或 1,3,5')
    datasets.add_argument('--datasets', help='用逗号分隔数据集文件夹名称')
    intervals = parser.add_mutually_exclusive_group()
    intervals.add_argument('--interval', type=_positive_number, help='仅测试一个 interval')
    intervals.add_argument('--intervals', default=','.join(str(value) for value in DEFAULT_INTERVALS))
    parser.add_argument('--seeds', default=','.join(str(value) for value in DEFAULT_SEEDS))
    parser.add_argument('--radius', type=_positive_number, default=8)
    parser.add_argument('--limit-time', type=_positive_number, default=180)
    parser.add_argument('--target-decisions', type=_positive_number, default=TARGET_DECISIONS)
    parser.add_argument('--tolerance-percent', type=float, default=COUNT_TOLERANCE_PERCENT)
    parser.add_argument('--out-dir', type=Path, default=base / 'results' / 'hoas_paln_1006')
    parser.add_argument('--verbose', action='store_true', help='显示每一轮完整匹配日志')
    parser.add_argument('--summarize-only', action='store_true', help='只汇总完整的已有实验，不运行仿真')
    parser.add_argument('--with-async-reference', action='store_true', help='同时运行 Async-PALP，按其实测决策次数匹配')
    parser.add_argument('--hover-power', type=float, default=0.5, help='Async-PALP 设置')
    parser.add_argument('--activation-scale', type=_positive_number, default=0.05, help='Async-PALP 设置')
    args = parser.parse_args()
    try:
        interval_values = [args.interval] if args.interval is not None else _number_list(args.intervals)
        seed_values = _number_list(args.seeds, integer=True)
        if not math.isfinite(args.tolerance_percent) or args.tolerance_percent < 0:
            raise ValueError('tolerance-percent 必须为有限非负数。')
        if not math.isfinite(args.hover_power) or args.hover_power < 0:
            raise ValueError('hover-power 必须为有限非负数。')
        if args.with_async_reference and args.activation_scale < 1e-6:
            raise ValueError('Async-PALP activation-scale 至少为 1e-6。')
        args.out_dir = args.out_dir.resolve()
        config_path = args.out_dir / 'run_config.json'
        runs_path = args.out_dir / 'runs.csv'
        reference_path = args.out_dir / 'async_reference.csv'
        rows, references = [], []
        if args.summarize_only:
            metadata = json.loads(config_path.read_text(encoding='utf-8'))
            if metadata.get('schema_version') != 'hoas_paln_correct_1006_v1':
                raise ValueError('该目录不是 1006 正确版的实验结果。')
            rows = pd.read_csv(runs_path).to_dict('records')
            protocol = metadata['protocol']
            references = pd.read_csv(reference_path).to_dict('records') if protocol['with_async_reference'] else []
            directories = [Path(path) for path in protocol['datasets']]
            plan = metadata['plan']
            _validate_checkpoint(rows, references, directories, plan['intervals'], plan['seeds'],
                                 protocol['with_async_reference'])
            if (len(rows) != len(directories) * len(plan['intervals']) * len(plan['seeds'])
                    or (protocol['with_async_reference'] and len(references) != len(directories) * len(plan['seeds']))):
                raise ValueError('实验尚未全部完成，不能用部分种子结果选择最高完成率种子。')
            _write_reports(rows, references, args)
            return
        directories = _select_datasets(args.dataset_root, args.random, args.datasets)
        protocol = {
            'datasets': [str(directory.resolve()) for directory in directories],
            'radius': args.radius, 'limit_time': args.limit_time,
            'max_matching_iterations': 1000, 'num_alternations': 2,
            'with_async_reference': args.with_async_reference,
            'hover_power': args.hover_power, 'activation_scale': args.activation_scale,
            'decision_count_definition': DECISION_DEFINITION,
            'completion_definition': COMPLETION_DEFINITION,
            'correct_source_sha256': CORRECT_SOURCE_SHA256,
            'action_deadlines': ENFORCE_ACTION_DEADLINES, 'packet_loss': ENABLE_PACKET_LOSS,
            'sync_times': 'interval, 2*interval, ...; floor(limit_time/interval) rounds, including exact horizon',
            'sha256': _source_hashes(directories, args.with_async_reference),
        }
        metadata = {
            'schema_version': 'hoas_paln_correct_1006_v1', 'protocol': protocol,
            'plan': {'intervals': interval_values, 'seeds': seed_values},
            'seed_rule': 'Maximum completion; common seed and equal dataset weights for ALL; ties choose smallest seed.',
            'interval_rule': 'Nearest decision count using each interval\'s selected best-completion seed.',
            'selection': {'target_decisions': args.target_decisions,
                          'tolerance_percent': args.tolerance_percent},
            'status': 'running',
        }
        if config_path.exists():
            previous = json.loads(config_path.read_text(encoding='utf-8'))
            if (previous.get('schema_version') != metadata['schema_version']
                    or not _resume_protocol_matches(previous.get('protocol', {}), protocol, args.out_dir)):
                raise ValueError('代码、数据或仿真参数已改变；请用 --out-dir 指定新的结果目录。')
            history = list(previous.get('source_history', []))
            previous_source = previous['protocol']['sha256']['HoAs-PALN-1006.py']
            if previous_source != protocol['sha256']['HoAs-PALN-1006.py']:
                history.append(previous_source)
            metadata['source_history'] = list(dict.fromkeys(history))
            if (not set(previous['plan']['intervals']).issubset(interval_values)
                    or not set(previous['plan']['seeds']).issubset(seed_values)):
                raise ValueError('继续实验时须包含原有 intervals/seeds，或另设 --out-dir。')
            rows = pd.read_csv(runs_path).to_dict('records') if runs_path.exists() else []
            references = pd.read_csv(reference_path).to_dict('records') if reference_path.exists() else []
        elif runs_path.exists() or reference_path.exists():
            raise ValueError('结果目录缺少 run_config.json；请使用新的 --out-dir。')
        _validate_checkpoint(rows, references, directories, interval_values, seed_values, args.with_async_reference)
    except (ValueError, OSError, KeyError, argparse.ArgumentTypeError) as error:
        parser.error(str(error))

    args.out_dir.mkdir(parents=True, exist_ok=True)
    _save_json(config_path, metadata)
    done = {(row['dataset'], float(row['interval']), int(row['seed'])) for row in rows}
    reference_done = {(row['dataset'], int(row['seed'])) for row in references}
    total = len(directories) * len(interval_values) * len(seed_values)
    print(f'共 {len(directories)} 个数据集 × {len(interval_values)} 个 interval × {len(seed_values)} 个种子 = {total} 次实验。', flush=True)
    print('每名在线且空闲的 UAV/Worker/Car 每轮计 1 次决策；空动作计入，内部迭代不重复计数。', flush=True)
    if done:
        print(f'已读取 {len(done)} 次已完成实验，自动继续剩余部分。', flush=True)
    for directory in directories:
        for interval in interval_values:
            for seed in seed_values:
                key = (directory.name, interval, seed)
                if key in done:
                    continue
                print(f'[{len(done) + 1}/{total}] {directory.name} | Interval={interval:g} | seed={seed}', flush=True)
                with open(os.devnull, 'w') as sink:
                    with contextlib.nullcontext() if args.verbose else contextlib.redirect_stdout(sink):
                        row = run_one_dataset(directory, interval, seed, args.limit_time, args.radius)
                rows.append(row)
                _save_csv(runs_path, rows)
                done.add(key)
                print(f"  完成率={row['task_completion_rate_percent']:.2f}% | 决策次数={row['decision_count']} | {row['elapsed_seconds']:.1f}s", flush=True)
        if args.with_async_reference:
            for seed in seed_values:
                if (directory.name, seed) in reference_done:
                    continue
                print(f'Async-PALP | {directory.name} | seed={seed}', flush=True)
                with open(os.devnull, 'w') as sink:
                    with contextlib.nullcontext() if args.verbose else contextlib.redirect_stdout(sink):
                        reference = _run_async_reference(directory, seed, args)
                references.append(reference)
                _save_csv(reference_path, references)
                reference_done.add((directory.name, seed))
    _write_reports(rows, references, args)
    metadata['status'] = 'complete'
    _save_json(config_path, metadata)


if __name__ == '__main__':
    main()
