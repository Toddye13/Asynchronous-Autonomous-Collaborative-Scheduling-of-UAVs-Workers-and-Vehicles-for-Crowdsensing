from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from algorithm import Mode, UAV, Vehicle, Worker, dis, scheduler as async_scheduler


class scheduler(async_scheduler):
    LOW_POWER_RATIO = 0.3
    PARTNER_BONUS = 8.0
    OVERLAP_BONUS = 4.0
    ARRIVAL_GAP_WEIGHT = 2.0
    DISTANCE_WEIGHT = 1.0
    URGENCY_WEIGHT = 1.5
    CHARGE_URGENCY_WEIGHT = 5.0
    SAME_ROLE_CONGESTION_PENALTY = 3.0
    FULL_PAIR_CONGESTION_PENALTY = 8.0

    def _agent_start_time(self, agent) -> float:
        return max(self.sys_time, agent.t_on)

    def _task_plan(self, agent, task) -> tuple[float, float] | None:
        start = self._agent_start_time(agent)
        distance = dis(agent.x, agent.y, task.x, task.y)
        arrival = start + distance / agent.speed
        if arrival > agent.t_off:
            return None

        if isinstance(agent, UAV):
            d_return, _ = self._nearest_charge(task.x, task.y)
            if distance + task.cost_power + d_return > agent.power:
                return None
            if start == self.sys_time:
                deadline = arrival + self._max_wait_uav_task(agent, task)
            else:
                deadline = agent.t_off
        else:
            deadline = agent.t_off
        return arrival, deadline

    def _charge_plan(self, agent, charge) -> tuple[float, float] | None:
        start = self._agent_start_time(agent)
        distance = dis(agent.x, agent.y, charge.x, charge.y)
        if isinstance(agent, UAV) and distance > agent.power:
            return None

        arrival = start + distance / agent.speed
        if arrival > agent.t_off:
            return None

        if isinstance(agent, UAV):
            if start == self.sys_time:
                deadline = arrival + self._max_wait_uav_charge(agent, charge)
            else:
                deadline = agent.t_off
        else:
            deadline = agent.t_off
        return arrival, deadline

    def _intervals_overlap(
        self,
        arrival: float,
        deadline: float,
        partner_arrival: float,
        partner_deadline: float,
    ) -> bool:
        return max(arrival, partner_arrival) <= min(deadline, partner_deadline)

    def _committed_plan(self, partner, target_type: str, target_id: int) -> tuple[float, float] | None:
        if partner.target_type != target_type or partner.target != target_id:
            return None
        if partner.mode == Mode.MOVE:
            deadline = partner.wait_deadline if partner.wait_deadline != float("inf") else partner.t_off
            return partner.arrival_time, deadline
        if partner.mode == Mode.WAIT:
            deadline = partner.wait_deadline if partner.wait_deadline != float("inf") else partner.t_off
            return self.sys_time, deadline
        return None

    def _task_partner_plans(
        self,
        agent,
        task,
        perceived_uavs: list[UAV],
        perceived_workers: list[Worker],
    ) -> list[tuple[float, float]]:
        partners = perceived_workers if isinstance(agent, UAV) else perceived_uavs
        plans: list[tuple[float, float]] = []
        for partner in partners:
            committed = self._committed_plan(partner, "task", task.id)
            if committed is not None:
                plans.append(committed)
                continue

            if partner.mode != Mode.IDLE:
                continue
            if dis(partner.x, partner.y, task.x, task.y) > partner.radius:
                continue
            plan = self._task_plan(partner, task)
            if plan is not None:
                plans.append(plan)
        return plans

    def _charge_partner_plans(
        self,
        agent,
        charge,
        perceived_uavs: list[UAV],
        perceived_vehicles: list[Vehicle],
    ) -> list[tuple[float, float]]:
        partners = perceived_vehicles if isinstance(agent, UAV) else perceived_uavs
        plans: list[tuple[float, float]] = []
        for partner in partners:
            committed = self._committed_plan(partner, "charge", charge.id)
            if committed is not None:
                plans.append(committed)
                continue

            if partner.mode != Mode.IDLE:
                continue
            if dis(partner.x, partner.y, charge.x, charge.y) > partner.radius:
                continue
            plan = self._charge_plan(partner, charge)
            if plan is not None:
                plans.append(plan)
        return plans

    def _best_partner_gap(
        self,
        arrival: float,
        deadline: float,
        partner_plans: list[tuple[float, float]],
    ) -> tuple[bool, bool, float]:
        if not partner_plans:
            return False, False, float("inf")

        best_gap = min(abs(arrival - partner_arrival) for partner_arrival, _ in partner_plans)
        has_overlap = any(
            self._intervals_overlap(arrival, deadline, partner_arrival, partner_deadline)
            for partner_arrival, partner_deadline in partner_plans
        )
        return True, has_overlap, best_gap

    def _time_urgency(self, agent, arrival: float) -> float:
        window = max(agent.t_off - agent.t_on, 1.0)
        remaining = max(0.0, agent.t_off - arrival)
        return 1.0 - min(remaining / window, 1.0)

    def _uav_low_power_ratio(self, uav: UAV) -> float:
        return 1.0 - min(max(uav.power / max(uav.full_power, 1e-9), 0.0), 1.0)

    def _is_reserved_for(self, agent, target_type: str, target_id: int) -> bool:
        return (
            agent.mode in (Mode.MOVE, Mode.WAIT, Mode.EXEC)
            and agent.target_type == target_type
            and agent.target == target_id
        )

    def _local_task_congestion(
        self,
        agent,
        task_id: int,
        perceived_uavs: list[UAV],
        perceived_workers: list[Worker],
    ) -> float:
        reserved_uavs = sum(1 for uav in perceived_uavs if self._is_reserved_for(uav, "task", task_id))
        reserved_workers = sum(1 for worker in perceived_workers if self._is_reserved_for(worker, "task", task_id))

        same_role_count = reserved_uavs if isinstance(agent, UAV) else reserved_workers
        penalty = self.SAME_ROLE_CONGESTION_PENALTY * same_role_count

        if reserved_uavs > 0 and reserved_workers > 0:
            penalty += self.FULL_PAIR_CONGESTION_PENALTY
        return penalty

    def _local_charge_congestion(
        self,
        agent,
        charge_id: int,
        perceived_uavs: list[UAV],
        perceived_vehicles: list[Vehicle],
    ) -> float:
        reserved_uavs = sum(1 for uav in perceived_uavs if self._is_reserved_for(uav, "charge", charge_id))
        reserved_vehicles = sum(1 for vehicle in perceived_vehicles if self._is_reserved_for(vehicle, "charge", charge_id))

        same_role_count = reserved_uavs if isinstance(agent, UAV) else reserved_vehicles
        penalty = self.SAME_ROLE_CONGESTION_PENALTY * same_role_count

        if reserved_uavs > 0 and reserved_vehicles > 0:
            penalty += self.FULL_PAIR_CONGESTION_PENALTY
        return penalty

    def _score_task_candidate(
        self,
        agent,
        task,
        perceived_uavs: list[UAV],
        perceived_workers: list[Worker],
    ) -> tuple[float, float] | None:
        plan = self._task_plan(agent, task)
        if plan is None:
            return None

        arrival, deadline = plan
        partner_plans = self._task_partner_plans(agent, task, perceived_uavs, perceived_workers)
        has_partner, has_overlap, best_gap = self._best_partner_gap(arrival, deadline, partner_plans)
        distance = dis(agent.x, agent.y, task.x, task.y)
        gap_cost = 0.0 if best_gap == float("inf") else best_gap / max(self.limit_time, 1.0)
        distance_cost = distance / self.D_max
        congestion_penalty = self._local_task_congestion(agent, task.id, perceived_uavs, perceived_workers)
        score = (
            (self.PARTNER_BONUS if has_partner else 0.0)
            + (self.OVERLAP_BONUS if has_overlap else 0.0)
            + self.URGENCY_WEIGHT * self._time_urgency(agent, arrival)
            - self.ARRIVAL_GAP_WEIGHT * gap_cost
            - self.DISTANCE_WEIGHT * distance_cost
            - congestion_penalty
        )
        return score, distance

    def _score_charge_candidate(
        self,
        agent,
        charge,
        perceived_uavs: list[UAV],
        perceived_vehicles: list[Vehicle],
    ) -> tuple[float, float] | None:
        plan = self._charge_plan(agent, charge)
        if plan is None:
            return None

        arrival, deadline = plan
        partner_plans = self._charge_partner_plans(agent, charge, perceived_uavs, perceived_vehicles)
        has_partner, has_overlap, best_gap = self._best_partner_gap(arrival, deadline, partner_plans)
        distance = dis(agent.x, agent.y, charge.x, charge.y)
        gap_cost = 0.0 if best_gap == float("inf") else best_gap / max(self.limit_time, 1.0)
        distance_cost = distance / self.D_max
        charge_urgency = self._uav_low_power_ratio(agent) if isinstance(agent, UAV) else 0.0
        congestion_penalty = self._local_charge_congestion(agent, charge.id, perceived_uavs, perceived_vehicles)
        score = (
            (self.PARTNER_BONUS if has_partner else 0.0)
            + (self.OVERLAP_BONUS if has_overlap else 0.0)
            + self.CHARGE_URGENCY_WEIGHT * charge_urgency
            + self.URGENCY_WEIGHT * self._time_urgency(agent, arrival)
            - self.ARRIVAL_GAP_WEIGHT * gap_cost
            - self.DISTANCE_WEIGHT * distance_cost
            - congestion_penalty
        )
        return score, distance

    def _finish_decision(self, agent) -> None:
        agent.tau = self.event_k
        self.total_decisions += 1
        self._broadcast_state(agent)

    def _better_candidate(
        self,
        score: float,
        distance: float,
        target_id: int,
        best_score: float,
        best_dist: float,
        best_target_id: int | None,
    ) -> bool:
        return score > best_score or (
            score == best_score
            and (distance, target_id) < (best_dist, best_target_id if best_target_id is not None else target_id)
        )

    def _decide_uav(self, uav: UAV):
        n_uavs, n_workers, n_vehicles = self._get_neighbors(uav)
        p_uavs, p_workers, p_vehicles = self._perceived_neighbors(uav, n_uavs, n_workers, n_vehicles)

        if self._is_locked(uav):
            return

        uav.mode = Mode.IDLE
        uav.target = None
        uav.target_type = None

        best_task_score = float("-inf")
        best_task_id: int | None = None
        best_task_dist = float("inf")

        for task in self.tasks:
            if task.completed:
                continue
            if dis(uav.x, uav.y, task.x, task.y) > uav.radius:
                continue
            scored = self._score_task_candidate(uav, task, p_uavs, p_workers)
            if scored is None:
                continue
            score, distance = scored
            if self._better_candidate(score, distance, task.id, best_task_score, best_task_dist, best_task_id):
                best_task_score = score
                best_task_id = task.id
                best_task_dist = distance

        best_charge_score = float("-inf")
        best_charge_id: int | None = None
        best_charge_dist = float("inf")

        for charge in self.charges:
            if dis(uav.x, uav.y, charge.x, charge.y) > uav.radius:
                continue
            scored = self._score_charge_candidate(uav, charge, p_uavs, p_vehicles)
            if scored is None:
                continue
            score, distance = scored
            if self._better_candidate(score, distance, charge.id, best_charge_score, best_charge_dist, best_charge_id):
                best_charge_score = score
                best_charge_id = charge.id
                best_charge_dist = distance

        if best_task_id is not None and best_task_score > 0.0:
            action_type = "task"
            action_id = best_task_id
        elif best_charge_id is not None and best_charge_score > 0.0:
            action_type = "charge"
            action_id = best_charge_id
        else:
            action_type = None
            action_id = None

        if action_type is not None and action_id is not None:
            uav.target = action_id
            uav.target_type = action_type
            uav.mode = Mode.MOVE
            point = self.tasks[action_id] if action_type == "task" else self.charges[action_id]
            uav.arrival_time = self._arrival_time(uav, point.x, point.y)
            if action_type == "task":
                uav.wait_deadline = uav.arrival_time + self._max_wait_uav_task(uav, self.tasks[action_id])
            else:
                uav.wait_deadline = uav.arrival_time + self._max_wait_uav_charge(uav, self.charges[action_id])

        self._finish_decision(uav)

    def _decide_worker(self, worker: Worker):
        n_uavs, n_workers, n_vehicles = self._get_neighbors(worker)
        p_uavs, p_workers, _ = self._perceived_neighbors(worker, n_uavs, n_workers, n_vehicles)

        if self._is_locked(worker):
            return

        worker.mode = Mode.IDLE
        worker.target = None
        worker.target_type = None

        best_score = float("-inf")
        best_task_id: int | None = None
        best_dist = float("inf")

        for task in self.tasks:
            if task.completed:
                continue
            if dis(worker.x, worker.y, task.x, task.y) > worker.radius:
                continue
            scored = self._score_task_candidate(worker, task, p_uavs, p_workers)
            if scored is None:
                continue
            score, distance = scored
            if score > best_score or (score == best_score and (distance, task.id) < (best_dist, best_task_id if best_task_id is not None else task.id)):
                best_score = score
                best_task_id = task.id
                best_dist = distance

        if best_task_id is not None and best_score > 0.0:
            worker.target = best_task_id
            worker.target_type = "task"
            worker.mode = Mode.MOVE
            point = self.tasks[best_task_id]
            worker.arrival_time = self._arrival_time(worker, point.x, point.y)
            worker.wait_deadline = worker.arrival_time + self._max_wait_worker(worker, point)

        self._finish_decision(worker)

    def _decide_vehicle(self, vehicle: Vehicle):
        n_uavs, n_workers, n_vehicles = self._get_neighbors(vehicle)
        p_uavs, _, p_vehicles = self._perceived_neighbors(vehicle, n_uavs, n_workers, n_vehicles)

        if self._is_locked(vehicle):
            return

        vehicle.mode = Mode.IDLE
        vehicle.target = None
        vehicle.target_type = None

        best_score = float("-inf")
        best_charge_id: int | None = None
        best_dist = float("inf")

        for charge in self.charges:
            if dis(vehicle.x, vehicle.y, charge.x, charge.y) > vehicle.radius:
                continue
            scored = self._score_charge_candidate(vehicle, charge, p_uavs, p_vehicles)
            if scored is None:
                continue
            score, distance = scored
            if score > best_score or (score == best_score and (distance, charge.id) < (best_dist, best_charge_id if best_charge_id is not None else charge.id)):
                best_score = score
                best_charge_id = charge.id
                best_dist = distance

        if best_charge_id is not None and best_score > 0.0:
            vehicle.target = best_charge_id
            vehicle.target_type = "charge"
            vehicle.mode = Mode.MOVE
            point = self.charges[best_charge_id]
            vehicle.arrival_time = self._arrival_time(vehicle, point.x, point.y)
            vehicle.wait_deadline = vehicle.arrival_time + self._max_wait_vehicle(vehicle, point)

        self._finish_decision(vehicle)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="CTAS baseline for asynchronous multi-agent scheduling.")
    parser.add_argument(
        "--data-dir",
        default=str(Path(__file__).resolve().parent / "data" / "HighpowerDatasets" / "BicycleOrder"),
        help="Dataset folder containing uavMap.csv, workerMap.csv, carMap.csv, taskMap.csv, and chargeMap.csv.",
    )
    parser.add_argument("--radius", type=float, default=8.0)
    parser.add_argument("--limit-time", type=float, default=240.0)
    parser.add_argument("--hover-power", type=float, default=0.5)
    parser.add_argument("--seed", type=int, default=6012220)
    parser.add_argument("--activation-scale", type=float, default=0.05)
    parser.add_argument("--quiet", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    base = Path(args.data_dir)
    scheduler_obj = scheduler(
        uav_file=str(base / "uavMap.csv"),
        worker_file=str(base / "workerMap.csv"),
        vehicle_file=str(base / "carMap.csv"),
        task_file=str(base / "taskMap.csv"),
        charge_file=str(base / "chargeMap.csv"),
        radius=args.radius,
        hover_power=args.hover_power,
        limit_time=args.limit_time,
        seed=args.seed,
        activation_scale=args.activation_scale,
    )

    completed, total = scheduler_obj.run_event_driven(verbose=not args.quiet)
    completion_rate = completed / total if total else 0.0
    print(
        f"CTAS result: {base.name} completed {completed}/{total} "
        f"({completion_rate * 100.0:.2f}%), decisions={scheduler_obj.total_decisions}, "
        f"events={scheduler_obj.event_k}, failed_waits={scheduler_obj.failed_waits}"
    )


if __name__ == "__main__":
    main()
