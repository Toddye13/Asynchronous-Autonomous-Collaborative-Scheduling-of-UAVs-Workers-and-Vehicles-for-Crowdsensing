from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from algorithm import Mode, UAV, Vehicle, Worker, dis, scheduler as async_scheduler

Action = tuple[str, int] | None


class scheduler(async_scheduler):
    PAIR_REWARD_TASK = 12.0
    PAIR_REWARD_CHARGE = 9.0
    OVERLAP_BONUS = 3.0
    FOCAL_ACTION_BONUS = 1.0
    ARRIVAL_GAP_WEIGHT = 3.0
    DISTANCE_WEIGHT = 1.5
    TIME_URGENCY_WEIGHT = 1.0
    CHARGE_URGENCY_WEIGHT = 4.0
    UNMATCHED_PENALTY = 2.0
    INVALID_PAIR_PENALTY = 5.0
    CONGESTION_PENALTY = 2.0
    LOW_POWER_TASK_PENALTY = 3.0
    UAV_LOW_POWER_RATIO = 0.3

    def __init__(
        self,
        *args,
        population_size: int = 36,
        generations: int = 18,
        mutation_rate: float = 0.15,
        elite_count: int = 4,
        tournament_size: int = 3,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.population_size = max(6, int(population_size))
        self.generations = max(1, int(generations))
        self.mutation_rate = min(max(float(mutation_rate), 0.0), 1.0)
        self.elite_count = max(1, min(int(elite_count), self.population_size))
        self.tournament_size = max(2, min(int(tournament_size), self.population_size))

    def _agent_start_time(self, agent) -> float:
        return max(self.sys_time, agent.t_on)

    def _task_plan(self, agent, task) -> tuple[float, float] | None:
        start = self._agent_start_time(agent)
        distance = dis(agent.x, agent.y, task.x, task.y)
        arrival = start + distance / agent.speed
        if arrival > agent.t_off:
            return None

        if isinstance(agent, UAV):
            d_return, _ = self._nearest_charge(task.x, task.y)
            if distance + task.cost_power + d_return > agent.power:
                return None
            if start == self.sys_time:
                deadline = arrival + self._max_wait_uav_task(agent, task)
            else:
                deadline = agent.t_off
        else:
            deadline = agent.t_off
        return arrival, deadline

    def _charge_plan(self, agent, charge) -> tuple[float, float] | None:
        start = self._agent_start_time(agent)
        distance = dis(agent.x, agent.y, charge.x, charge.y)
        if isinstance(agent, UAV) and distance > agent.power:
            return None

        arrival = start + distance / agent.speed
        if arrival > agent.t_off:
            return None

        if isinstance(agent, UAV):
            if start == self.sys_time:
                deadline = arrival + self._max_wait_uav_charge(agent, charge)
            else:
                deadline = agent.t_off
        else:
            deadline = agent.t_off
        return arrival, deadline

    def _intervals_overlap(
        self,
        arrival: float,
        deadline: float,
        partner_arrival: float,
        partner_deadline: float,
    ) -> bool:
        return max(arrival, partner_arrival) <= min(deadline, partner_deadline)

    def _committed_plan(self, partner, target_type: str, target_id: int) -> tuple[float, float] | None:
        if partner.target_type != target_type or partner.target != target_id:
            return None
        if partner.mode == Mode.MOVE:
            deadline = partner.wait_deadline if partner.wait_deadline != float("inf") else partner.t_off
            return partner.arrival_time, deadline
        if partner.mode == Mode.WAIT:
            deadline = partner.wait_deadline if partner.wait_deadline != float("inf") else partner.t_off
            return self.sys_time, deadline
        return None

    def _finish_decision(self, agent) -> None:
        agent.tau = self.event_k
        self.total_decisions += 1
        self._broadcast_state(agent)

    def _agent_sort_key(self, agent) -> tuple[str, int]:
        if isinstance(agent, UAV):
            return ("uav", agent.id)
        if isinstance(agent, Worker):
            return ("worker", agent.id)
        return ("vehicle", agent.id)

    def _time_urgency(self, agent, arrival: float) -> float:
        window = max(agent.t_off - agent.t_on, 1.0)
        remaining = max(0.0, agent.t_off - arrival)
        return 1.0 - min(remaining / window, 1.0)

    def _uav_low_power_ratio(self, uav: UAV) -> float:
        return 1.0 - min(max(uav.power / max(uav.full_power, 1e-9), 0.0), 1.0)

    def _candidate_actions(self, agent) -> list[Action]:
        actions: list[Action] = [None]
        if isinstance(agent, UAV):
            for task in self.tasks:
                if task.completed:
                    continue
                if dis(agent.x, agent.y, task.x, task.y) <= agent.radius and self._task_plan(agent, task):
                    actions.append(("task", task.id))
            for charge in self.charges:
                if dis(agent.x, agent.y, charge.x, charge.y) <= agent.radius and self._charge_plan(agent, charge):
                    actions.append(("charge", charge.id))
        elif isinstance(agent, Worker):
            for task in self.tasks:
                if task.completed:
                    continue
                if dis(agent.x, agent.y, task.x, task.y) <= agent.radius and self._task_plan(agent, task):
                    actions.append(("task", task.id))
        else:
            for charge in self.charges:
                if dis(agent.x, agent.y, charge.x, charge.y) <= agent.radius and self._charge_plan(agent, charge):
                    actions.append(("charge", charge.id))
        return actions

    def _local_decision_agents(
        self,
        focal,
        perceived_uavs: list[UAV],
        perceived_workers: list[Worker],
        perceived_vehicles: list[Vehicle],
    ) -> tuple[list, list[list[Action]]]:
        agents = [focal]
        for agent in perceived_uavs + perceived_workers + perceived_vehicles:
            if agent.mode == Mode.IDLE:
                agents.append(agent)

        unique = {}
        for agent in agents:
            unique[self._agent_sort_key(agent)] = agent
        agents = sorted(unique.values(), key=self._agent_sort_key)

        if focal not in agents:
            agents.insert(0, focal)
        else:
            agents.remove(focal)
            agents.insert(0, focal)

        domains = [self._candidate_actions(agent) for agent in agents]
        return agents, domains

    def _random_chromosome(self, domains: list[list[Action]]) -> tuple[int, ...]:
        return tuple(random.randrange(len(domain)) for domain in domains)

    def _seed_chromosomes(self, domains: list[list[Action]]) -> list[tuple[int, ...]]:
        seeds: list[tuple[int, ...]] = []
        if not domains:
            return seeds

        for focal_idx in range(len(domains[0])):
            chromosome = [random.randrange(len(domain)) for domain in domains]
            chromosome[0] = focal_idx
            seeds.append(tuple(chromosome))

        none_chromosome = tuple(0 for _ in domains)
        seeds.append(none_chromosome)
        return seeds

    def _individual_action_score(self, agent, action: Action, is_focal: bool) -> float:
        if action is None:
            return 0.0

        target_type, target_id = action
        point = self.tasks[target_id] if target_type == "task" else self.charges[target_id]
        distance = dis(agent.x, agent.y, point.x, point.y)
        plan = self._task_plan(agent, point) if target_type == "task" else self._charge_plan(agent, point)
        if plan is None:
            return -self.INVALID_PAIR_PENALTY

        arrival, _ = plan
        score = 0.0
        score += self.FOCAL_ACTION_BONUS if is_focal else 0.0
        score += self.TIME_URGENCY_WEIGHT * self._time_urgency(agent, arrival)
        score -= self.DISTANCE_WEIGHT * (distance / max(self.D_max, 1.0))

        if isinstance(agent, UAV) and target_type == "charge":
            score += self.CHARGE_URGENCY_WEIGHT * self._uav_low_power_ratio(agent)
        if isinstance(agent, UAV) and target_type == "task":
            power_ratio = agent.power / max(agent.full_power, 1e-9)
            if power_ratio < self.UAV_LOW_POWER_RATIO:
                score -= self.LOW_POWER_TASK_PENALTY * (self.UAV_LOW_POWER_RATIO - power_ratio)
        return score

    def _add_selected_plans(
        self,
        task_plans: dict[int, dict[str, list]],
        charge_plans: dict[int, dict[str, list]],
        agent,
        action: Action,
        is_focal: bool,
    ) -> float:
        if action is None:
            return 0.0

        target_type, target_id = action
        if target_type == "task":
            plan = self._task_plan(agent, self.tasks[target_id])
            if plan is None:
                return -self.INVALID_PAIR_PENALTY
            entry = (agent, plan[0], plan[1], is_focal)
            bucket = task_plans.setdefault(target_id, {"uavs": [], "workers": []})
            if isinstance(agent, UAV):
                bucket["uavs"].append(entry)
            elif isinstance(agent, Worker):
                bucket["workers"].append(entry)
        else:
            plan = self._charge_plan(agent, self.charges[target_id])
            if plan is None:
                return -self.INVALID_PAIR_PENALTY
            entry = (agent, plan[0], plan[1], is_focal)
            bucket = charge_plans.setdefault(target_id, {"uavs": [], "vehicles": []})
            if isinstance(agent, UAV):
                bucket["uavs"].append(entry)
            elif isinstance(agent, Vehicle):
                bucket["vehicles"].append(entry)
        return 0.0

    def _add_committed_plans(
        self,
        task_plans: dict[int, dict[str, list]],
        charge_plans: dict[int, dict[str, list]],
        perceived_uavs: list[UAV],
        perceived_workers: list[Worker],
        perceived_vehicles: list[Vehicle],
    ) -> None:
        for uav in perceived_uavs:
            if uav.target_type == "task" and uav.target is not None:
                plan = self._committed_plan(uav, "task", uav.target)
                if plan is not None:
                    task_plans.setdefault(uav.target, {"uavs": [], "workers": []})["uavs"].append(
                        (uav, plan[0], plan[1], False)
                    )
            elif uav.target_type == "charge" and uav.target is not None:
                plan = self._committed_plan(uav, "charge", uav.target)
                if plan is not None:
                    charge_plans.setdefault(uav.target, {"uavs": [], "vehicles": []})["uavs"].append(
                        (uav, plan[0], plan[1], False)
                    )

        for worker in perceived_workers:
            if worker.target_type == "task" and worker.target is not None:
                plan = self._committed_plan(worker, "task", worker.target)
                if plan is not None:
                    task_plans.setdefault(worker.target, {"uavs": [], "workers": []})["workers"].append(
                        (worker, plan[0], plan[1], False)
                    )

        for vehicle in perceived_vehicles:
            if vehicle.target_type == "charge" and vehicle.target is not None:
                plan = self._committed_plan(vehicle, "charge", vehicle.target)
                if plan is not None:
                    charge_plans.setdefault(vehicle.target, {"uavs": [], "vehicles": []})["vehicles"].append(
                        (vehicle, plan[0], plan[1], False)
                    )

    def _pairing_score(self, first: list, second: list, pair_reward: float) -> float:
        if not first and not second:
            return 0.0

        first = sorted(first, key=lambda item: (item[1], self._agent_sort_key(item[0])))
        second = sorted(second, key=lambda item: (item[1], self._agent_sort_key(item[0])))
        pair_count = min(len(first), len(second))
        score = 0.0

        for i in range(pair_count):
            a_agent, a_arrival, a_deadline, _ = first[i]
            b_agent, b_arrival, b_deadline, _ = second[i]
            gap = abs(a_arrival - b_arrival)
            if self._intervals_overlap(a_arrival, a_deadline, b_arrival, b_deadline):
                score += pair_reward + self.OVERLAP_BONUS
                score -= self.ARRIVAL_GAP_WEIGHT * (gap / max(self.limit_time, 1.0))
            else:
                score -= self.INVALID_PAIR_PENALTY
                score -= self.ARRIVAL_GAP_WEIGHT * (gap / max(self.limit_time, 1.0))

            score += 0.2 * (self._time_urgency(a_agent, a_arrival) + self._time_urgency(b_agent, b_arrival))

        unmatched = abs(len(first) - len(second))
        score -= self.UNMATCHED_PENALTY * unmatched
        same_role_congestion = max(0, len(first) - 1) + max(0, len(second) - 1)
        score -= self.CONGESTION_PENALTY * same_role_congestion
        return score

    def _fitness(
        self,
        chromosome: tuple[int, ...],
        agents: list,
        domains: list[list[Action]],
        perceived_uavs: list[UAV],
        perceived_workers: list[Worker],
        perceived_vehicles: list[Vehicle],
    ) -> float:
        task_plans: dict[int, dict[str, list]] = {}
        charge_plans: dict[int, dict[str, list]] = {}
        score = 0.0

        for index, gene in enumerate(chromosome):
            agent = agents[index]
            action = domains[index][gene]
            is_focal = index == 0
            score += self._individual_action_score(agent, action, is_focal)
            score += self._add_selected_plans(task_plans, charge_plans, agent, action, is_focal)

        self._add_committed_plans(task_plans, charge_plans, perceived_uavs, perceived_workers, perceived_vehicles)

        for bucket in task_plans.values():
            score += self._pairing_score(bucket["uavs"], bucket["workers"], self.PAIR_REWARD_TASK)
        for bucket in charge_plans.values():
            score += self._pairing_score(bucket["uavs"], bucket["vehicles"], self.PAIR_REWARD_CHARGE)

        return score

    def _tournament_select(self, scored_population: list[tuple[float, tuple[int, ...]]]) -> tuple[int, ...]:
        competitors = random.sample(scored_population, self.tournament_size)
        return max(competitors, key=lambda item: item[0])[1]

    def _crossover(self, parent_a: tuple[int, ...], parent_b: tuple[int, ...]) -> tuple[int, ...]:
        if len(parent_a) <= 1:
            return parent_a
        return tuple(a if random.random() < 0.5 else b for a, b in zip(parent_a, parent_b))

    def _mutate(self, chromosome: tuple[int, ...], domains: list[list[Action]]) -> tuple[int, ...]:
        mutated = list(chromosome)
        for index, domain in enumerate(domains):
            if len(domain) > 1 and random.random() < self.mutation_rate:
                mutated[index] = random.randrange(len(domain))
        return tuple(mutated)

    def _ga_choose_action(
        self,
        focal,
        perceived_uavs: list[UAV],
        perceived_workers: list[Worker],
        perceived_vehicles: list[Vehicle],
    ) -> Action:
        agents, domains = self._local_decision_agents(focal, perceived_uavs, perceived_workers, perceived_vehicles)
        if not domains or len(domains[0]) <= 1:
            return None

        population = self._seed_chromosomes(domains)
        while len(population) < self.population_size:
            population.append(self._random_chromosome(domains))
        population = population[: self.population_size]

        for _ in range(self.generations):
            scored = [
                (self._fitness(chromosome, agents, domains, perceived_uavs, perceived_workers, perceived_vehicles), chromosome)
                for chromosome in population
            ]
            scored.sort(key=lambda item: item[0], reverse=True)
            next_population = [chromosome for _, chromosome in scored[: self.elite_count]]
            while len(next_population) < self.population_size:
                parent_a = self._tournament_select(scored)
                parent_b = self._tournament_select(scored)
                child = self._crossover(parent_a, parent_b)
                next_population.append(self._mutate(child, domains))
            population = next_population

        best = max(
            population,
            key=lambda chromosome: self._fitness(
                chromosome, agents, domains, perceived_uavs, perceived_workers, perceived_vehicles
            ),
        )
        return domains[0][best[0]]

    def _apply_action(self, agent, action: Action) -> None:
        if action is None:
            self._finish_decision(agent)
            return

        action_type, action_id = action
        agent.target = action_id
        agent.target_type = action_type
        agent.mode = Mode.MOVE

        point = self.tasks[action_id] if action_type == "task" else self.charges[action_id]
        agent.arrival_time = self._arrival_time(agent, point.x, point.y)
        if action_type == "task":
            if isinstance(agent, UAV):
                agent.wait_deadline = agent.arrival_time + self._max_wait_uav_task(agent, self.tasks[action_id])
            else:
                agent.wait_deadline = agent.arrival_time + self._max_wait_worker(agent, self.tasks[action_id])
        else:
            if isinstance(agent, UAV):
                agent.wait_deadline = agent.arrival_time + self._max_wait_uav_charge(agent, self.charges[action_id])
            else:
                agent.wait_deadline = agent.arrival_time + self._max_wait_vehicle(agent, self.charges[action_id])
        self._finish_decision(agent)

    def _prepare_decision(self, agent) -> bool:
        if self._is_locked(agent):
            return False
        agent.mode = Mode.IDLE
        agent.target = None
        agent.target_type = None
        agent.partner_id = None
        return True

    def _decide_uav(self, uav: UAV):
        n_uavs, n_workers, n_vehicles = self._get_neighbors(uav)
        p_uavs, p_workers, p_vehicles = self._perceived_neighbors(uav, n_uavs, n_workers, n_vehicles)
        if not self._prepare_decision(uav):
            return
        action = self._ga_choose_action(uav, p_uavs, p_workers, p_vehicles)
        self._apply_action(uav, action)

    def _decide_worker(self, worker: Worker):
        n_uavs, n_workers, n_vehicles = self._get_neighbors(worker)
        p_uavs, p_workers, p_vehicles = self._perceived_neighbors(worker, n_uavs, n_workers, n_vehicles)
        if not self._prepare_decision(worker):
            return
        action = self._ga_choose_action(worker, p_uavs, p_workers, p_vehicles)
        self._apply_action(worker, action)

    def _decide_vehicle(self, vehicle: Vehicle):
        n_uavs, n_workers, n_vehicles = self._get_neighbors(vehicle)
        p_uavs, p_workers, p_vehicles = self._perceived_neighbors(vehicle, n_uavs, n_workers, n_vehicles)
        if not self._prepare_decision(vehicle):
            return
        action = self._ga_choose_action(vehicle, p_uavs, p_workers, p_vehicles)
        self._apply_action(vehicle, action)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Genetic Algorithm baseline for asynchronous multi-agent scheduling.")
    parser.add_argument(
        "--data-dir",
        default=str(Path(__file__).resolve().parent / "data" / "HighpowerDatasets" / "BicycleOrder"),
        help="Dataset folder containing uavMap.csv, workerMap.csv, carMap.csv, taskMap.csv, and chargeMap.csv.",
    )
    parser.add_argument("--radius", type=float, default=8.0)
    parser.add_argument("--limit-time", type=float, default=180.0)
    parser.add_argument("--hover-power", type=float, default=0.5)
    parser.add_argument("--seed", type=int, default=6012220)
    parser.add_argument("--activation-scale", type=float, default=0.05)
    parser.add_argument("--population-size", type=int, default=36)
    parser.add_argument("--generations", type=int, default=18)
    parser.add_argument("--mutation-rate", type=float, default=0.15)
    parser.add_argument("--elite-count", type=int, default=4)
    parser.add_argument("--tournament-size", type=int, default=3)
    parser.add_argument("--quiet", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    base = Path(args.data_dir)
    scheduler_obj = scheduler(
        uav_file=str(base / "uavMap.csv"),
        worker_file=str(base / "workerMap.csv"),
        vehicle_file=str(base / "carMap.csv"),
        task_file=str(base / "taskMap.csv"),
        charge_file=str(base / "chargeMap.csv"),
        radius=args.radius,
        hover_power=args.hover_power,
        limit_time=args.limit_time,
        seed=args.seed,
        activation_scale=args.activation_scale,
        population_size=args.population_size,
        generations=args.generations,
        mutation_rate=args.mutation_rate,
        elite_count=args.elite_count,
        tournament_size=args.tournament_size,
    )

    completed, total = scheduler_obj.run_event_driven(verbose=not args.quiet)
    completion_rate = completed / total if total else 0.0
    print(
        f"GA result: {base.name} completed {completed}/{total} "
        f"({completion_rate * 100.0:.2f}%), decisions={scheduler_obj.total_decisions}, "
        f"events={scheduler_obj.event_k}, failed_waits={scheduler_obj.failed_waits}, "
        f"population={args.population_size}, generations={args.generations}"
    )


if __name__ == "__main__":
    main()
