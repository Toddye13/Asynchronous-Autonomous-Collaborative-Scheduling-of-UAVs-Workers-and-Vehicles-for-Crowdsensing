from __future__ import annotations

import argparse
import json
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Optional

from algorithm import Mode, UAV, Vehicle, Worker, dis, scheduler as async_scheduler


REQUIRED_FILES = ["uavMap.csv", "workerMap.csv", "carMap.csv", "taskMap.csv", "chargeMap.csv"]

DEFAULT_API_KEY = "XXX"

class LLMError(RuntimeError):
    pass


class LLMClient:
    def __init__(
        self,
        api_key: str,
        model: str,
        base_url: str,
        timeout: float = 30.0,
        max_retries: int = 2,
    ) -> None:
        self.api_key = api_key
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max(0, max_retries)

    def rank_actions(self, prompt: str) -> dict[str, Any]:
        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "You are an asynchronous multi-agent scheduling policy. "
                        "You must return a valid JSON object only. "
                        "Never choose an action outside the candidate list. "
                        "Return exactly one best action in ranked_actions. "
                        "Do not explain or reason. Keep the response under 40 tokens."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            "temperature": 0,
            "top_p": 1,
            "max_tokens": 512,
        }

        last_error: Optional[BaseException] = None
        for attempt in range(self.max_retries + 1):
            try:
                return self._post(payload)
            except Exception as exc:  # keep simulation alive through controlled fallback
                last_error = exc
                if attempt < self.max_retries:
                    time.sleep(0.5 * (attempt + 1))
        raise LLMError(f"LLM request failed after retries: {last_error}") from last_error

    def _post(self, payload: dict[str, Any]) -> dict[str, Any]:
        url = f"{self.base_url}/chat/completions"
        body = json.dumps(payload).encode("utf-8")
        request = urllib.request.Request(
            url,
            data=body,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                raw = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise LLMError(f"HTTP {exc.code}: {detail}") from exc
        except urllib.error.URLError as exc:
            raise LLMError(f"URL error: {exc}") from exc

        try:
            response_json = json.loads(raw)
            choice = response_json["choices"][0]
            message = choice["message"]
            content = message.get("content") or message.get("reasoning_content") or ""
        except Exception as exc:
            raise LLMError(f"Unexpected LLM response shape: {raw[:500]}") from exc

        if not content.strip():
            message_preview = {key: str(value)[:120] for key, value in message.items()}
            raise LLMError(
                f"Empty LLM response: finish_reason={choice.get('finish_reason')}, "
                f"message={message_preview}"
            )

        return parse_json_object(content)


def parse_json_object(text: str) -> dict[str, Any]:
    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            return parsed
    except json.JSONDecodeError:
        pass

    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        try:
            parsed = json.loads(text[start : end + 1])
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            pass
    action_match = re.search(
        r"\b(task|charge)\b[^\d]{0,20}\bid\s*[:#=-]?\s*(\d+)\b",
        text,
        flags=re.IGNORECASE,
    )
    if action_match is None:
        action_match = re.search(
            r"\b(task|charge)\b\s*[:#=-]?\s*(\d+)\b",
            text,
            flags=re.IGNORECASE,
        )
    if action_match is not None:
        return {
            "ranked_actions": [
                {
                    "type": action_match.group(1).lower(),
                    "id": int(action_match.group(2)),
                }
            ]
        }
    raise LLMError(f"LLM did not return a JSON object: {text[:500]}")


class scheduler(async_scheduler):
    def __init__(
        self,
        *args,
        llm_client: LLMClient,
        max_candidates: int = 20,
        debug_every: int = 1,
        print_candidates: bool = False,
        **kwargs,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.llm_client = llm_client
        self.max_candidates = max(1, int(max_candidates))
        self.llm_calls = 0
        self.llm_failures = 0
        self.llm_invalid_outputs = 0
        self.llm_fallbacks = 0
        self.llm_total_latency = 0.0
        self.debug_every = max(1, int(debug_every))
        self.print_candidates = print_candidates

    @property
    def llm_avg_latency(self) -> float:
        return self.llm_total_latency / self.llm_calls if self.llm_calls else 0.0

    def llm_stats(self) -> dict[str, float | int]:
        return {
            "llm_calls": self.llm_calls,
            "llm_failures": self.llm_failures,
            "llm_invalid_outputs": self.llm_invalid_outputs,
            "llm_fallbacks": self.llm_fallbacks,
            "llm_total_latency": round(self.llm_total_latency, 6),
            "llm_avg_latency": round(self.llm_avg_latency, 6),
        }

    def _debug_print(self, message: str) -> None:
        print(message, flush=True)

    def _agent_label(self, agent) -> str:
        if isinstance(agent, UAV):
            return f"uav-{agent.id}"
        if isinstance(agent, Worker):
            return f"worker-{agent.id}"
        return f"vehicle-{agent.id}"

    def _decide_uav(self, uav: UAV):
        n_uavs, n_workers, n_vehicles = self._get_neighbors(uav)
        p_uavs, p_workers, p_vehicles = self._perceived_neighbors(uav, n_uavs, n_workers, n_vehicles)

        if self._is_locked(uav):
            return

        uav.mode = Mode.IDLE
        uav.target = None
        uav.target_type = None
        candidates: list[tuple[str, int]] = []

        for task in self.tasks:
            if not task.completed and dis(uav.x, uav.y, task.x, task.y) <= uav.radius and self._uav_task_feasible(uav, task):
                candidates.append(("task", task.id))
        for charge in self.charges:
            if dis(uav.x, uav.y, charge.x, charge.y) <= uav.radius and self._uav_charge_feasible(uav, charge):
                candidates.append(("charge", charge.id))

        self._decide_with_llm(uav, candidates, p_uavs, p_workers, p_vehicles)

    def _decide_worker(self, worker: Worker):
        n_uavs, n_workers, n_vehicles = self._get_neighbors(worker)
        p_uavs, p_workers, p_vehicles = self._perceived_neighbors(worker, n_uavs, n_workers, n_vehicles)

        if self._is_locked(worker):
            return

        worker.mode = Mode.IDLE
        worker.target = None
        worker.target_type = None
        candidates: list[tuple[str, int]] = []

        for task in self.tasks:
            if not task.completed and dis(worker.x, worker.y, task.x, task.y) <= worker.radius and self._worker_task_feasible(worker, task):
                candidates.append(("task", task.id))

        self._decide_with_llm(worker, candidates, p_uavs, p_workers, p_vehicles)

    def _decide_vehicle(self, vehicle: Vehicle):
        n_uavs, n_workers, n_vehicles = self._get_neighbors(vehicle)
        p_uavs, p_workers, p_vehicles = self._perceived_neighbors(vehicle, n_uavs, n_workers, n_vehicles)

        if self._is_locked(vehicle):
            return

        vehicle.mode = Mode.IDLE
        vehicle.target = None
        vehicle.target_type = None
        candidates: list[tuple[str, int]] = []

        for charge in self.charges:
            if dis(vehicle.x, vehicle.y, charge.x, charge.y) <= vehicle.radius and self._vehicle_charge_feasible(vehicle, charge):
                candidates.append(("charge", charge.id))

        self._decide_with_llm(vehicle, candidates, p_uavs, p_workers, p_vehicles)

    def _decide_with_llm(
        self,
        agent,
        candidates: list[tuple[str, int]],
        neighbor_uavs: list[UAV],
        neighbor_workers: list[Worker],
        neighbor_vehicles: list[Vehicle],
    ) -> None:
        agent_label = self._agent_label(agent)

        if not candidates:
            self._debug_print(
                f"[NO CANDIDATE] event={self.event_k}, "
                f"time={self.sys_time:.4f}, agent={agent_label} -> IDLE"
            )
            self._finish_idle_decision(agent)
            return

        features = self._candidate_features(agent, candidates, neighbor_uavs, neighbor_workers, neighbor_vehicles)
        prompt = self._build_prompt(agent, features, neighbor_uavs, neighbor_workers, neighbor_vehicles)

        chosen_action: Optional[tuple[str, int]] = None
        self.llm_calls += 1
        call_id = self.llm_calls

        should_print = (call_id % self.debug_every == 0)

        if should_print:
            completed = sum(1 for task in self.tasks if task.completed)
            total = len(self.tasks)
            self._debug_print(
                f"\n[LLM CALL #{call_id}] "
                f"event={self.event_k}, time={self.sys_time:.4f}, "
                f"agent={agent_label}, candidates={len(candidates)}, "
                f"completed={completed}/{total}, "
                f"failures={self.llm_failures}, invalid={self.llm_invalid_outputs}, fallback={self.llm_fallbacks}"
            )

            if self.print_candidates:
                self._debug_print("[CANDIDATES]")
                for idx, item in enumerate(features, start=1):
                    self._debug_print(
                        f"  {idx}. type={item['type']}, id={item['id']}, "
                        f"dist={item['distance']}, arrival={item['arrival_time']}, "
                        f"deadline={item['wait_deadline']}, "
                        f"partners={item['visible_partner_count']}, "
                        f"same={item['same_type_congestion_count']}, "
                        f"overlap={item['wait_interval_overlap']}, "
                        f"energy_margin={item.get('energy_margin', 'NA')}"
                    )

        started = time.perf_counter()
        response: Optional[dict[str, Any]] = None

        try:
            response = self.llm_client.rank_actions(prompt)
            chosen_action = self._first_valid_llm_action(response, candidates)

            if chosen_action is None:
                self.llm_invalid_outputs += 1
                if should_print:
                    self._debug_print(f"[LLM INVALID] response={response}")

        except LLMError as e:
            self.llm_failures += 1
            if should_print:
                self._debug_print(f"[LLM ERROR] {e}")

        finally:
            latency = time.perf_counter() - started
            self.llm_total_latency += latency

        if chosen_action is None:
            self.llm_fallbacks += 1
            chosen_action = self._nearest_candidate(agent, candidates)

            if should_print:
                self._debug_print(
                    f"[FALLBACK] choose nearest candidate: {chosen_action}, latency={latency:.2f}s"
                )
        else:
            if should_print:
                self._debug_print(
                    f"[LLM SELECT] action={chosen_action}, latency={latency:.2f}s"
                )

        if chosen_action is not None:
            self._apply_action(agent, chosen_action[0], chosen_action[1])
            if should_print:
                self._debug_print(
                    f"[APPLY] agent={agent_label}, target_type={chosen_action[0]}, "
                    f"target={chosen_action[1]}, arrival={agent.arrival_time:.4f}, "
                    f"wait_deadline={agent.wait_deadline:.4f}"
                )
        else:
            self._finish_idle_decision(agent)
            if should_print:
                self._debug_print(f"[IDLE] agent={agent_label}")

    def _candidate_features(
        self,
        agent,
        candidates: list[tuple[str, int]],
        neighbor_uavs: list[UAV],
        neighbor_workers: list[Worker],
        neighbor_vehicles: list[Vehicle],
    ) -> list[dict[str, Any]]:
        ranked: list[dict[str, Any]] = []
        for action_type, action_id in candidates:
            point = self.tasks[action_id] if action_type == "task" else self.charges[action_id]
            arrival = self._arrival_time(agent, point.x, point.y)
            wait_deadline = self._wait_deadline_for(agent, action_type, action_id, arrival)
            same_count, partner_count, best_partner_gap, overlap = self._local_partner_features(
                agent, action_type, action_id, arrival, wait_deadline, neighbor_uavs, neighbor_workers, neighbor_vehicles
            )

            item: dict[str, Any] = {
                "key": f"{action_type}:{action_id}",
                "type": action_type,
                "id": action_id,
                "distance": round(dis(agent.x, agent.y, point.x, point.y), 4),
                "arrival_time": round(arrival, 4),
                "wait_deadline": round(wait_deadline, 4),
                "visible_partner_count": partner_count,
                "same_type_congestion_count": same_count,
                "best_partner_arrival_gap": None if best_partner_gap is None else round(best_partner_gap, 4),
                "wait_interval_overlap": overlap,
            }
            if isinstance(agent, UAV):
                item["uav_power"] = round(agent.power, 4)
                item["uav_full_power"] = round(agent.full_power, 4)
                if action_type == "task":
                    task = self.tasks[action_id]
                    d_return, _ = self._nearest_charge(task.x, task.y)
                    item["energy_margin"] = round(
                        agent.power - dis(agent.x, agent.y, task.x, task.y) - task.cost_power - d_return,
                        4,
                    )
                else:
                    charge = self.charges[action_id]
                    item["energy_margin"] = round(agent.power - dis(agent.x, agent.y, charge.x, charge.y), 4)
            ranked.append(item)

        ranked.sort(
            key=lambda x: (
                -(1 if x["wait_interval_overlap"] else 0),
                -int(x["visible_partner_count"]),
                int(x["same_type_congestion_count"]),
                float(x["distance"]),
            )
        )
        return ranked[: self.max_candidates]

    def _local_partner_features(
        self,
        agent,
        action_type: str,
        action_id: int,
        arrival: float,
        wait_deadline: float,
        neighbor_uavs: list[UAV],
        neighbor_workers: list[Worker],
        neighbor_vehicles: list[Vehicle],
    ) -> tuple[int, int, Optional[float], bool]:
        same_agents: list[Any] = []
        partner_agents: list[Any] = []

        if action_type == "task":
            if isinstance(agent, UAV):
                same_agents = [u for u in neighbor_uavs if u.target_type == "task" and u.target == action_id]
                partner_agents = [w for w in neighbor_workers if w.target_type == "task" and w.target == action_id]
            else:
                same_agents = [w for w in neighbor_workers if w.target_type == "task" and w.target == action_id]
                partner_agents = [u for u in neighbor_uavs if u.target_type == "task" and u.target == action_id]
        elif action_type == "charge":
            if isinstance(agent, UAV):
                same_agents = [u for u in neighbor_uavs if u.target_type == "charge" and u.target == action_id]
                partner_agents = [v for v in neighbor_vehicles if v.target_type == "charge" and v.target == action_id]
            else:
                same_agents = [v for v in neighbor_vehicles if v.target_type == "charge" and v.target == action_id]
                partner_agents = [u for u in neighbor_uavs if u.target_type == "charge" and u.target == action_id]

        best_gap: Optional[float] = None
        any_overlap = False
        for partner in partner_agents:
            p_arrival = partner.arrival_time
            p_deadline = partner.wait_deadline
            if p_arrival == float("inf") or p_deadline == float("inf"):
                point = self.tasks[action_id] if action_type == "task" else self.charges[action_id]
                p_arrival = self._arrival_time(partner, point.x, point.y)
                p_deadline = self._wait_deadline_for(partner, action_type, action_id, p_arrival)
            gap = abs(arrival - p_arrival)
            best_gap = gap if best_gap is None else min(best_gap, gap)
            if max(arrival, p_arrival) <= min(wait_deadline, p_deadline):
                any_overlap = True

        return len(same_agents), len(partner_agents), best_gap, any_overlap

    def _build_prompt(
        self,
        agent,
        candidate_features: list[dict[str, Any]],
        neighbor_uavs: list[UAV],
        neighbor_workers: list[Worker],
        neighbor_vehicles: list[Vehicle],
    ) -> str:
        data = {
            "task": "Choose exactly one feasible candidate action for one activated asynchronous agent. Return JSON only.",
            "rules": [
                "Only choose one action from candidate_actions.",
                "Only choose an exact key from candidate_action_keys.",
                "Do not assign or modify other agents.",
                "Prefer actions likely to complete tasks, keep UAVs alive, overlap waiting intervals, avoid same-type congestion, and reduce travel distance.",
                "Return a compact JSON object only.",
                "The ranked_actions list must contain exactly one action.",
                "Do not output explanations, markdown, or prose outside JSON.",
                "The first character must be { and the last character must be }."
            ],
            "current_time": round(self.sys_time, 4),
            "event_index": self.event_k,
            "activated_agent": self._agent_summary(agent),
            "candidate_action_keys": [item["key"] for item in candidate_features],
            "candidate_actions": candidate_features,
            "output_schema": {
                "ranked_actions": [
                    {"key": "task:0", "type": "task", "id": 0}
                ]
            },
            "example_output": {
                "ranked_actions": [
                    {"key": "task:55", "type": "task", "id": 55}
                ]
            },
        }
        return json.dumps(data, ensure_ascii=False, separators=(",", ":"))

    def _agent_summary(self, agent) -> dict[str, Any]:
        if isinstance(agent, UAV):
            agent_type = "uav"
        elif isinstance(agent, Worker):
            agent_type = "worker"
        else:
            agent_type = "vehicle"
        summary = {
            "type": agent_type,
            "id": agent.id,
            "x": round(agent.x, 4),
            "y": round(agent.y, 4),
            "mode": agent.mode.value,
            "target_type": agent.target_type,
            "target": agent.target,
            "arrival_time": None if agent.arrival_time == float("inf") else round(agent.arrival_time, 4),
            "wait_deadline": None if agent.wait_deadline == float("inf") else round(agent.wait_deadline, 4),
            "t_on": round(agent.t_on, 4),
            "t_off": round(agent.t_off, 4),
        }
        if isinstance(agent, UAV):
            summary["power"] = round(agent.power, 4)
            summary["full_power"] = round(agent.full_power, 4)
        return summary

    def _first_valid_llm_action(
        self,
        response: dict[str, Any],
        candidates: list[tuple[str, int]],
    ) -> Optional[tuple[str, int]]:
        candidate_set = {(atype, int(aid)) for atype, aid in candidates}
        candidate_by_key = {f"{atype}:{int(aid)}": (atype, int(aid)) for atype, aid in candidates}
        ranked = response.get("ranked_actions")
        if not isinstance(ranked, list):
            return None
        for item in ranked:
            if not isinstance(item, dict):
                continue
            action_key = item.get("key")
            if isinstance(action_key, str) and action_key in candidate_by_key:
                return candidate_by_key[action_key]
            action_type = item.get("type")
            action_id = item.get("id")
            try:
                key = (str(action_type), int(action_id))
            except (TypeError, ValueError):
                continue
            if key in candidate_set:
                return key
        return None

    def _nearest_candidate(self, agent, candidates: list[tuple[str, int]]) -> Optional[tuple[str, int]]:
        best_action: Optional[tuple[str, int]] = None
        best_dist = float("inf")
        for action_type, action_id in candidates:
            point = self.tasks[action_id] if action_type == "task" else self.charges[action_id]
            distance = dis(agent.x, agent.y, point.x, point.y)
            if distance < best_dist:
                best_dist = distance
                best_action = (action_type, action_id)
        return best_action

    def _wait_deadline_for(self, agent, action_type: str, action_id: int, arrival_time: float) -> float:
        if isinstance(agent, UAV):
            if action_type == "task":
                return arrival_time + self._max_wait_uav_task(agent, self.tasks[action_id])
            return arrival_time + self._max_wait_uav_charge(agent, self.charges[action_id])
        if isinstance(agent, Worker):
            return arrival_time + self._max_wait_worker(agent, self.tasks[action_id])
        return arrival_time + self._max_wait_vehicle(agent, self.charges[action_id])

    def _apply_action(self, agent, action_type: str, action_id: int) -> None:
        agent.target = action_id
        agent.target_type = action_type
        agent.mode = Mode.MOVE
        point = self.tasks[action_id] if action_type == "task" else self.charges[action_id]
        agent.arrival_time = self._arrival_time(agent, point.x, point.y)
        agent.wait_deadline = self._wait_deadline_for(agent, action_type, action_id, agent.arrival_time)
        self._finish_decision(agent)

    def _finish_idle_decision(self, agent) -> None:
        agent.mode = Mode.IDLE
        agent.target = None
        agent.target_type = None
        agent.arrival_time = float("inf")
        agent.wait_deadline = float("inf")
        self._finish_decision(agent)

    def _finish_decision(self, agent) -> None:
        agent.tau = self.event_k
        self.total_decisions += 1
        self._broadcast_state(agent)


def resolve_data_dir(path: str) -> Path:
    base = Path(path).resolve()
    missing = [name for name in REQUIRED_FILES if not (base / name).exists()]
    if missing:
        raise FileNotFoundError(
            f"未找到有效数据集文件夹: {base}\n"
            f"该文件夹内必须包含: {', '.join(REQUIRED_FILES)}\n"
            f"当前缺少: {', '.join(missing)}"
        )
    return base


def run_one_dataset(args: argparse.Namespace) -> dict[str, Any]:
    base = resolve_data_dir(args.data_dir)
    llm_client = LLMClient(
        api_key=args.api_key,
        model=args.model,
        base_url=args.base_url,
        timeout=args.timeout,
        max_retries=args.max_retries,
    )
    scheduler_obj = scheduler(
        uav_file=str(base / "uavMap.csv"),
        worker_file=str(base / "workerMap.csv"),
        vehicle_file=str(base / "carMap.csv"),
        task_file=str(base / "taskMap.csv"),
        charge_file=str(base / "chargeMap.csv"),
        radius=args.radius,
        hover_power=args.hover_power,
        limit_time=args.limit_time,
        seed=args.seed,
        activation_scale=args.activation_scale,
        llm_client=llm_client,
        max_candidates=args.max_candidates,
        debug_every=args.debug_every,
        print_candidates=args.print_candidates,
    )
    completed, total = scheduler_obj.run_event_driven(verbose=args.verbose)
    completion_rate = completed / total if total else 0.0
    result: dict[str, Any] = {
        "dataset": base.name,
        "completed": completed,
        "total": total,
        "completion_rate": completion_rate,
        "completion_rate_percent": completion_rate * 100.0,
        "decision_count": scheduler_obj.total_decisions,
        "event_count": scheduler_obj.event_k,
        "failed_waits": scheduler_obj.failed_waits,
        "seed": args.seed,
    }
    result.update(scheduler_obj.llm_stats())
    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Async-LLM baseline for asynchronous multi-agent scheduling.")
    parser.add_argument("--data-dir", default=str(Path(__file__).resolve().parent / "data"))
    parser.add_argument("--api-key", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--radius", type=float, default=8.0)
    parser.add_argument("--limit-time", type=float, default=180.0)
    parser.add_argument("--hover-power", type=float, default=0.5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--activation-scale", type=float, default=0.05)
    parser.add_argument("--timeout", type=float, default=30.0)
    parser.add_argument("--max-retries", type=int, default=2)
    parser.add_argument("--max-candidates", type=int, default=20)
    parser.add_argument("--stats-json", default=None)
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--debug-every", type=int, default=1, help="Print progress every N LLM calls.")
    parser.add_argument("--print-candidates", action="store_true", help="Print candidate actions for each LLM decision.")
    return parser


def print_result(result: dict[str, Any]) -> None:
    print("Async-LLM result")
    print(f"dataset: {result['dataset']}")
    print(f"completed: {result['completed']}")
    print(f"total: {result['total']}")
    print(f"completion_rate: {result['completion_rate']:.4f}")
    print(f"completion_rate_percent: {result['completion_rate_percent']:.2f}%")
    print(f"decision_count: {result['decision_count']}")
    print(f"event_count: {result['event_count']}")
    print(f"failed_waits: {result['failed_waits']}")
    print()
    print("LLM statistics")
    print(f"llm_calls: {result['llm_calls']}")
    print(f"llm_failures: {result['llm_failures']}")
    print(f"llm_invalid_outputs: {result['llm_invalid_outputs']}")
    print(f"llm_fallbacks: {result['llm_fallbacks']}")
    print(f"llm_avg_latency: {result['llm_avg_latency']:.2f}")


def main() -> None:
    args = build_parser().parse_args()
    if args.api_key == "DEFAULT_API_KEY":
        args.api_key = DEFAULT_API_KEY
    result = run_one_dataset(args)
    print_result(result)
    if args.stats_json:
        out_path = Path(args.stats_json)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"\nstats_json: {out_path.resolve()}")


if __name__ == "__main__":
    main()
