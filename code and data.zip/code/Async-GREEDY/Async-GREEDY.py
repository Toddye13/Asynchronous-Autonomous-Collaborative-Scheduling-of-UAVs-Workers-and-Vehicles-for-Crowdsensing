from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from algorithm import Mode, UAV, Vehicle, Worker, dis, scheduler as async_scheduler


class scheduler(async_scheduler):
    def _agent_start_time(self, agent) -> float:
        return max(self.sys_time, agent.t_on)

    def _task_plan(self, agent, task) -> tuple[float, float] | None:
        start = self._agent_start_time(agent)
        distance = dis(agent.x, agent.y, task.x, task.y)
        arrival = start + distance / agent.speed
        if arrival > agent.t_off:
            return None

        if isinstance(agent, UAV):
            d_return, _ = self._nearest_charge(task.x, task.y)
            if distance + task.cost_power + d_return > agent.power:
                return None
            if start == self.sys_time:
                deadline = arrival + self._max_wait_uav_task(agent, task)
            else:
                deadline = agent.t_off
        else:
            deadline = agent.t_off
        return arrival, deadline

    def _charge_plan(self, agent, charge) -> tuple[float, float] | None:
        start = self._agent_start_time(agent)
        distance = dis(agent.x, agent.y, charge.x, charge.y)
        if isinstance(agent, UAV) and distance > agent.power:
            return None

        arrival = start + distance / agent.speed
        if arrival > agent.t_off:
            return None

        if isinstance(agent, UAV):
            if start == self.sys_time:
                deadline = arrival + self._max_wait_uav_charge(agent, charge)
            else:
                deadline = agent.t_off
        else:
            deadline = agent.t_off
        return arrival, deadline

    def _intervals_overlap(
        self,
        arrival: float,
        deadline: float,
        partner_arrival: float,
        partner_deadline: float,
    ) -> bool:
        return max(arrival, partner_arrival) <= min(deadline, partner_deadline)

    def _task_partner_plans(self, agent, task) -> list[tuple[float, float]]:
        partners = self.workers if isinstance(agent, UAV) else self.uavs
        plans: list[tuple[float, float]] = []
        for partner in partners:
            if self.sys_time > partner.t_off:
                continue

            if (
                partner.mode in (Mode.MOVE, Mode.WAIT, Mode.EXEC)
                and partner.target_type == "task"
                and partner.target == task.id
            ):
                arrival = self.sys_time if partner.mode == Mode.WAIT else partner.arrival_time
                deadline = partner.wait_deadline if partner.wait_deadline != float("inf") else partner.t_off
                plans.append((arrival, deadline))
                continue

            if partner.mode not in (Mode.IDLE, Mode.OFFLINE):
                continue
            if dis(partner.x, partner.y, task.x, task.y) > partner.radius:
                continue
            plan = self._task_plan(partner, task)
            if plan is not None:
                plans.append(plan)
        return plans

    def _charge_partner_plans(self, agent, charge) -> list[tuple[float, float]]:
        partners = self.vehicles if isinstance(agent, UAV) else self.uavs
        plans: list[tuple[float, float]] = []
        for partner in partners:
            if self.sys_time > partner.t_off:
                continue

            if (
                partner.mode in (Mode.MOVE, Mode.WAIT, Mode.EXEC)
                and partner.target_type == "charge"
                and partner.target == charge.id
            ):
                arrival = self.sys_time if partner.mode == Mode.WAIT else partner.arrival_time
                deadline = partner.wait_deadline if partner.wait_deadline != float("inf") else partner.t_off
                plans.append((arrival, deadline))
                continue

            if partner.mode not in (Mode.IDLE, Mode.OFFLINE):
                continue
            if dis(partner.x, partner.y, charge.x, charge.y) > partner.radius:
                continue
            plan = self._charge_plan(partner, charge)
            if plan is not None:
                plans.append(plan)
        return plans

    def _has_task_partner(self, agent, task) -> bool:
        plan = self._task_plan(agent, task)
        if plan is None:
            return False
        arrival, deadline = plan
        return any(
            self._intervals_overlap(arrival, deadline, partner_arrival, partner_deadline)
            for partner_arrival, partner_deadline in self._task_partner_plans(agent, task)
        )

    def _has_charge_partner(self, agent, charge) -> bool:
        plan = self._charge_plan(agent, charge)
        if plan is None:
            return False
        arrival, deadline = plan
        return any(
            self._intervals_overlap(arrival, deadline, partner_arrival, partner_deadline)
            for partner_arrival, partner_deadline in self._charge_partner_plans(agent, charge)
        )

    def _uav_greedy_score(self, uav: UAV, action_type: str, action_id: int) -> float:
        point = self.tasks[action_id] if action_type == "task" else self.charges[action_id]
        return -dis(uav.x, uav.y, point.x, point.y)

    def _worker_greedy_score(self, worker: Worker, task_id: int) -> float:
        task = self.tasks[task_id]
        return -dis(worker.x, worker.y, task.x, task.y)

    def _vehicle_greedy_score(self, vehicle: Vehicle, charge_id: int) -> float:
        charge = self.charges[charge_id]
        return -dis(vehicle.x, vehicle.y, charge.x, charge.y)

    def _decide_uav(self, uav: UAV):
        if self._is_locked(uav):
            return

        uav.mode = Mode.IDLE
        uav.target = None
        uav.target_type = None

        candidates: list[tuple[str, int]] = []
        for task in self.tasks:
            if task.completed:
                continue
            if dis(uav.x, uav.y, task.x, task.y) <= uav.radius and self._uav_task_feasible(uav, task):
                candidates.append(("task", task.id))

        for charge in self.charges:
            if dis(uav.x, uav.y, charge.x, charge.y) <= uav.radius and self._uav_charge_feasible(uav, charge):
                candidates.append(("charge", charge.id))

        paired_candidates = [
            (action_type, action_id)
            for action_type, action_id in candidates
            if (
                action_type == "task"
                and self._has_task_partner(uav, self.tasks[action_id])
            )
            or (
                action_type == "charge"
                and self._has_charge_partner(uav, self.charges[action_id])
            )
        ]
        if paired_candidates:
            candidates = paired_candidates

        if not candidates:
            uav.tau = self.event_k
            self.total_decisions += 1
            self._broadcast_state(uav)
            return

        best_score = float("-inf")
        best_action: tuple[str, int] | None = None
        best_dist = float("inf")

        for action_type, action_id in candidates:
            score = self._uav_greedy_score(uav, action_type, action_id)
            point = self.tasks[action_id] if action_type == "task" else self.charges[action_id]
            distance = dis(uav.x, uav.y, point.x, point.y)
            if score > best_score or (score == best_score and distance < best_dist):
                best_score = score
                best_action = (action_type, action_id)
                best_dist = distance

        if best_action is not None:
            action_type, action_id = best_action
            uav.target = action_id
            uav.target_type = action_type
            uav.mode = Mode.MOVE

            point = self.tasks[action_id] if action_type == "task" else self.charges[action_id]
            uav.arrival_time = self._arrival_time(uav, point.x, point.y)
            if action_type == "task":
                uav.wait_deadline = uav.arrival_time + self._max_wait_uav_task(uav, self.tasks[action_id])
            else:
                uav.wait_deadline = uav.arrival_time + self._max_wait_uav_charge(uav, self.charges[action_id])

        uav.tau = self.event_k
        self.total_decisions += 1
        self._broadcast_state(uav)

    def _decide_worker(self, worker: Worker):
        if self._is_locked(worker):
            return

        worker.mode = Mode.IDLE
        worker.target = None
        worker.target_type = None

        candidates: list[int] = []
        for task in self.tasks:
            if task.completed:
                continue
            if dis(worker.x, worker.y, task.x, task.y) <= worker.radius and self._worker_task_feasible(worker, task):
                candidates.append(task.id)

        paired_candidates = [
            task_id for task_id in candidates
            if self._has_task_partner(worker, self.tasks[task_id])
        ]
        if paired_candidates:
            candidates = paired_candidates

        if not candidates:
            worker.tau = self.event_k
            self.total_decisions += 1
            self._broadcast_state(worker)
            return

        best_score = float("-inf")
        best_task_id: int | None = None
        best_dist = float("inf")

        for task_id in candidates:
            score = self._worker_greedy_score(worker, task_id)
            point = self.tasks[task_id]
            distance = dis(worker.x, worker.y, point.x, point.y)
            if score > best_score or (score == best_score and distance < best_dist):
                best_score = score
                best_task_id = task_id
                best_dist = distance

        if best_task_id is not None:
            worker.target = best_task_id
            worker.target_type = "task"
            worker.mode = Mode.MOVE
            point = self.tasks[best_task_id]
            worker.arrival_time = self._arrival_time(worker, point.x, point.y)
            worker.wait_deadline = worker.arrival_time + self._max_wait_worker(worker, point)

        worker.tau = self.event_k
        self.total_decisions += 1
        self._broadcast_state(worker)

    def _decide_vehicle(self, vehicle: Vehicle):
        if self._is_locked(vehicle):
            return

        vehicle.mode = Mode.IDLE
        vehicle.target = None
        vehicle.target_type = None

        candidates: list[int] = []
        for charge in self.charges:
            if dis(vehicle.x, vehicle.y, charge.x, charge.y) <= vehicle.radius and self._vehicle_charge_feasible(vehicle, charge):
                candidates.append(charge.id)

        paired_candidates = [
            charge_id for charge_id in candidates
            if self._has_charge_partner(vehicle, self.charges[charge_id])
        ]
        if paired_candidates:
            candidates = paired_candidates

        if not candidates:
            vehicle.tau = self.event_k
            self.total_decisions += 1
            self._broadcast_state(vehicle)
            return

        best_score = float("-inf")
        best_charge_id: int | None = None
        best_dist = float("inf")

        for charge_id in candidates:
            score = self._vehicle_greedy_score(vehicle, charge_id)
            point = self.charges[charge_id]
            distance = dis(vehicle.x, vehicle.y, point.x, point.y)
            if score > best_score or (score == best_score and distance < best_dist):
                best_score = score
                best_charge_id = charge_id
                best_dist = distance

        if best_charge_id is not None:
            vehicle.target = best_charge_id
            vehicle.target_type = "charge"
            vehicle.mode = Mode.MOVE
            point = self.charges[best_charge_id]
            vehicle.arrival_time = self._arrival_time(vehicle, point.x, point.y)
            vehicle.wait_deadline = vehicle.arrival_time + self._max_wait_vehicle(vehicle, point)

        vehicle.tau = self.event_k
        self.total_decisions += 1
        self._broadcast_state(vehicle)

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Greedy baseline for asynchronous multi-agent scheduling.")
    parser.add_argument(
        "--data-dir",
        default=str(Path(__file__).resolve().parent / "data" / "HighpowerDatasets" / "BicycleOrder"),
        help="Dataset folder containing uavMap.csv, workerMap.csv, carMap.csv, taskMap.csv, and chargeMap.csv.",
    )
    parser.add_argument("--radius", type=float, default=8.0)
    parser.add_argument("--limit-time", type=float, default=120.0)
    parser.add_argument("--hover-power", type=float, default=0.5)
    parser.add_argument("--seed", type=int, default=482222)
    parser.add_argument("--activation-scale", type=float, default=0.05)
    parser.add_argument("--quiet", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    base = Path(args.data_dir)
    scheduler_obj = scheduler(
        uav_file=str(base / 'uavMap.csv'),
        worker_file=str(base / 'workerMap.csv'),
        vehicle_file=str(base / 'carMap.csv'),
        task_file=str(base / 'taskMap.csv'),
        charge_file=str(base / 'chargeMap.csv'),
        radius=args.radius,
        hover_power=args.hover_power,
        limit_time=args.limit_time,
        seed=args.seed,
        activation_scale=args.activation_scale,
    )

    completed, total = scheduler_obj.run_event_driven(verbose=not args.quiet)
    completion_rate = completed / total if total else 0.0
    print(
        f"Greedy result: {base.name} completed {completed}/{total} "
        f"({completion_rate * 100.0:.2f}%), decisions={scheduler_obj.total_decisions}, "
        f"events={scheduler_obj.event_k}, failed_waits={scheduler_obj.failed_waits}"
    )


if __name__ == '__main__':
    main()
